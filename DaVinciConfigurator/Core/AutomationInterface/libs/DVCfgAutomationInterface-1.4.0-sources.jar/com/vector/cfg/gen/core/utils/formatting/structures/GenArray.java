package com.vector.cfg.gen.core.utils.formatting.structures;

import java.util.List;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.formatting.EFormatType;
import com.vector.cfg.gen.core.utils.formatting.IGenElement;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatProvider;
import com.vector.cfg.gen.core.utils.formatting.formatter.TableFormatter;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The Format class for Array and Structs
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenArray extends AbstractGenStructure<GenArray> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenArray.class);

    @PublishedField
    public static final GenArray EMPTY_ARRAY = create().setImmutable();

    @PublishedMethod
    protected GenArray() {
        super();
    }

    /**
     * Creates a new GenArray and returns the new instance.
     *
     * @return The new GenArray
     */
    @PublishedMethod
    public static GenArray create() {
        final GenArray genArray = createInternal();

        return genArray;

    }

    /**
     * Creates a new GenArray, appends the collection elements to the array and returns the new instance.
     *
     * @return The new GenArray
     */
    @PublishedMethod
    public static GenArray create(Iterable<? super Object> collection) {
        final GenArray genArray = createInternal();

        genArray.append(collection);

        return genArray;

    }

    /**
     * Creates a new GenArray, appends the list of objects to the array and returns the new instance.
     *
     * @return The new GenArray
     */
    @PublishedMethod
    public static GenArray create(Object... objects) {
        final GenArray genArray = createInternal();

        genArray.append(objects);

        return genArray;

    }

    /**
     * Creates a new GenArray, appends the object to the array and returns the new instance.
     *
     * @return The new GenArray
     */
    @PublishedMethod
    public static GenArray create(Object obj) {
        final GenArray genArray = createInternal();

        genArray.append(obj);

        return genArray;

    }

    private static GenArray createInternal() {
        return new GenArray();
    }

    /**
     * Creates a new inner array. Appends it to the current array, and returns the <b>inner</b> array.
     *
     * @return The new inner GenArray
     */
    @PublishedMethod
    @Override
    public GenArray createInner() {
        ensureObjectIsMutable();
        final GenArray inner = GenArray.create();
        this.append(inner);

        return inner;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String generate(IGenFormatProvider formatProvider) {

        if (formatProvider.getFormatter() instanceof TableFormatter) {

            ((TableFormatter) formatProvider.getFormatter()).setColumnLenghts(this);
        }

        return super.generate(formatProvider);
    }

    /**
     * Generates the String with the special table format and the passed columnHeader.
     *
     * <p>
     * See {@link EFormatType#TABLE_FORMAT} for more details.
     * </p>
     * <p>
     * Example:<br/>
     * <code>  List{@literal <String>} columnHeader = new ArrayList<>();<br>
     *  columnHeader.add("Column1");<br>
     *  columnHeader.add("Column2");<br>
     *  columnHeader.add("Column3");<br>
     *  <br>
     *  yourArray.generate(EFormatType.TABLE_FORMAT, columnHeader);</code>
     * </p>
     *
     * @param tableFormatter The TableFormatter
     * @param columnHeader The columnHeader as ArrayList<String>()
     * @return The generated String
     */
    @PublishedMethod
    public String generate(TableFormatter tableFormatter, List<String> columnHeader) {

        ((TableFormatter) tableFormatter.getFormatter()).setColumnHeader(columnHeader, this);

        return this.generate(tableFormatter);
    }

    @PublishedMethod
    public List<IGenElement> getContent() {
        return ImmutableList.copyOf(arrayList);
    }
}
