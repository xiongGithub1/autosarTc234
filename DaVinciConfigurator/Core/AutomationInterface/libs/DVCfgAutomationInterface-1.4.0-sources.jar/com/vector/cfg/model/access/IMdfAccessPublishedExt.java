package com.vector.cfg.model.access;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;

/**
 * This is the externally published API of the MDF access service.
 *
 * <p>
 * This ProjectService is threadsafe
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public interface IMdfAccessPublishedExt {

    /**
     * Creates a new MDF object of the specified type (meta class).
     *
     * @param metaClass the meta class
     * @return the created MDF object
     */
    @PublishedMethod
    <T extends MIObject> T createMDFObject(Class<T> metaClass);

}
