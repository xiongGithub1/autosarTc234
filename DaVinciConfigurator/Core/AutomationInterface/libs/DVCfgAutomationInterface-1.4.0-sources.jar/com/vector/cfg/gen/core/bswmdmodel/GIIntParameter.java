package com.vector.cfg.gen.core.bswmdmodel;

import java.math.BigInteger;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasIllegalValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasNoValueException;
import com.vector.cfg.gen.core.utils.formatting.primitives.IntGenElement;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucIntegerDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;

/**
 * Base interface of integer bswmd model parameter.
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see MIParameterValue
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
//CHECKSTYLE:OFF Class Naming problem
public interface GIIntParameter extends GIParameter<BigInteger> {
    // CHECKSTYLE:ON

    /**
     * Gets the big integer value of the {@link GIIntParameter} object.
     *
     * @return the {@link BigInteger} value
     *
     * @exception BswmdModelParameterHasNoValueException
     * <ul>
     * <li>if the value of the parameter is null</li>
     * </ul>
     * @exception BswmdModelParameterHasIllegalValueException
     * <ul>
     * <li>if the value of the parameter is illegal</li>
     * </ul>
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    BigInteger getBigIntegerValue();

    /**
     * Returns the parameters value as LongValue.
     *
     * @return The value object
     *
     * @exception BswmdModelParameterHasNoValueException
     * <ul>
     * <li>if the value of the parameter is null</li>
     * </ul>
     * @exception BswmdModelParameterHasIllegalValueException
     * <ul>
     * <li>if the value of the parameter is illegal</li>
     * </ul>
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    Long getValue();

    /**
     * Returns the parameters value, or the parameter defaultValue, if the parameter does not exist or has no value.
     *
     * <p>
     * <code>null</code> as defaultValue is permitted!
     * </p>
     *
     * @return The value object, or the defaultValue.
     */
    @PublishedMethod
    Long getValueOrDefault(Long defaultValue);

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IntGenElement formatValue();

    /**
     * Convenience method to set the value of the {@link GIIntParameter}.
     * <p>
     * This method checks if the specified parameters configuration object is available and sets the new value. If the object is missing it is implicitly created in the MDF
     * model.
     * </p>
     *
     * @param newValue
     */
    @PublishedMethod
    void setValueMdf(long newValue);

    /**
     * Convenience method to set the value of the {@link GIIntParameter}.
     *
     * See {@link GIIntParameter#setValueMdf(long)} for more details.
     *
     * @param newValue
     */
    @PublishedMethod
    void setValue(long newValue);

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucIntegerDefinition getEcucDefinition();

}
