package com.vector.cfg.gen.core.moduleinterface;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.util.text.format.IFormattable;
import com.vector.cfg.util.text.mixedtext.IMixedText;

/**
 * A GeneratorResult represents a result, which is shown in the GUI of the Cfg. A Result could be a ERROR, WARNING, IMPROVEMENT or INFO.
 *
 * <p>
 * Please use <code>com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder</code> to create instances of {@link IGeneratorResult}s.
 * </p>
 *
 * <div class="extdoc" id="Common">
 *
 * An {@link IGeneratorResult} is also an {@link IValidationResult} so we will to the terms interchangeably. You should always use {@link IGeneratorResult}s, because they
 * provide a broader API for the generator use case, such as API for the Definition model <!--LaTeX: (See \vref{sec:BswmdModel})-->
 *
 * The figure <!--LaTeX:\vref{fig:IGeneratorResultClasses}--> show the class hierarchy of {@link IGeneratorResult}s.
 *
 * <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZ8AAAD+CAIAAABqX5+IAAAs30lEQVR42u2dCVQT5/r/PaKireJG3dllcdeqaNWKO/Za61r3tS51aWuvbb1QbaEq1esSBBSByA4hCUsggOAColVQVOLOJuKGoqhAbau9nt/5/5/4hiEkIUErQvD7Od/DGSZvJsmbmU+ed2YyafT/AACgIdIIXQAAgN0AAAB2AwAA2A0AAGA3AACA3QAAsNs/pLS09BioI8rKyrAeA1BbdqNtrBGoI9LS0rAeA1C7duNtd01JFL+MiOUolwSKkOUIJT6iIgJ5pCoJP6xI2OE4LqGHKLFKkYQmS0IqElyRIHliKpNEiQ6sSIA8UQEH5fFXTqI8BxIjufDlEVP8FBH5JVTGl0u8yCdeSNnPRRrBxVseAcu+iuylxLGEc/GKpYRRPBUJpXhINGSPPCEU983Oa2E3AN6G3chrL8pvv8wtecpu/U+em/KUUgpZ/qY8uVGRAsrzxyzX5XlEyX+mSN6zEi65f1EeUnIUeZDz54Psilz7s1ieP4qvynOfcoXlKeXe5Ypckqfo0u/yXFTk7gVKuTyy8jtcssootynnFbl1vvTWuYqcLb2pyJObmU8KKWe4PL5xuiIZ8hRkPJInXZHrpyglLPknK/LbQ0oe5YQiuZTjDxRJe5CjSHHOMXmyKakxwTzYDQDYrcHajcfjpaeny2SyvLy8oqKi8vJyrNYAwG4NwW6urq5SqTQlJSUzM5MEV1JSgtUagLdnt79KrovFB+Ysmmnb26aZYTO2O9zE0mTq7MkiEf+PB3mw22vbzdnZWSAQSCQSEhxVcFS+YbUG4C3Zzdd3V1ezrha2lnPXzt8atF2YGRV9USrOkuwQ8BatX2rT17araVef/Ttgt9ezm5OTU1BQEAmOKjgaohYWFmK1BqDW7fZ7cd7kaZ90tei2yduVjFZdXHy3mHY3mzh5XNm9q7Dbq9rNxcWF7BYcHCwWi6l8o8EpVmsAatduT4vzHMZ+3Hdov8DjYVrUxhKeIR40cvDQ4YPLiq7CbrAbAPXablOnTyK1kbZ0qo2FxqokuEmfTYDdYDcA6q/dgv09ulmY1KRqU6ngzLqbBfruht1gNwDqo92ePS4wNdexr03bPjizbk+Lc+rQbqW3ztdnu927lgq7AVA3dkuOC7e0s1Q3lzAzavbquR27dTJoYtDN0mTdr+uHjPnIpq+tSjPbfnZxIn9lu9HCs04mdu3SScVuFmYmJw6JNdqN7sLsRhPqdqOZWuzWu6cNsxs1e1W7KX8DtHlzw2H2/TOPit6I3WiBzG697KxgNwDqxm4rli+Yu3a+irNE52JIZBq/B67SctH6pfPnT1exG9VuQwcPSIgK5OyWEi/o08uuutqNs5vG2k273ejW167d6L5c7XY/98TG774cNKD3m7UbTcBuANSN3fr07bk1aLuKs+asnU9tWrdrTSPWKFlcWLqQ6jiNdtsh4Flamavbzcfz17kzP+PstnDONI8dLqS2tCRRvz49mjZt8oFxO77Xtupqt8LLJxxG2LdobnjAaxtnt9SEsH697Zo2kd/X12MrUxtDuXa7Ljs6asQQajZy2OCCCynMbnTr5h/XmXbrTPMjg/ao242GpaQwupXZ7XrWoXEOH9G/Yz4ekn8+mdktgr+T5hgYNO5haxkb5sXURgvh7CaXmpLduKcHuwFQB3ajgSc7ZVc5nU27UJuffX5RnmlmbaY+MhVnSeQ6U7Pb7/evdexg/LAwi9T26NaFNm2MHt++QHaztbZKigmkwk3g72Fk1Ko6uy1fPDvA+79Uo61ZPp+zm621ZYKYT7VbGH+3UauWKrUbZ7cl86bv3/0LVW0+7psXzZnK2e3b1Ysf3TgdGeRBhtJoN68dG+0/7MPstnT+9MvpcVS4hfn+d+WSWcxudMd9O3+i2k0cuNvMpItOu6F2A6Au7aZejlEaN26scb7GaLTbXyW569Z8sXfXZrIb/V29fIH6UQW51KqxG1VnpDYamd7LSdc4Mn0pNc12a9Pa6EnhWbLbg+sZJEHObiXXT7ORKU2r73cjc01ydLiSLmV2a9+2DTcy7fBBe2a38aOGzZg8ntR2LyeNG5nCbgDoU+2mcRBa3Ylv1dntYsYh+4H9yG5DBw84/1sCU9udnAwX53WfT/0XFWJa7EZDV/X9bjevHP9pw1czp0y0tbbQYjf5RMV+N3IWZzduv5uy3VjhJgzg9bS1un0llTtmqiw+Gooyu+WeTXQYNoiW2fL991LjAmA3AOq13Qb0762+362NcVv55XoiPXXabYeA1727hUa7/fUwd+Rwe4nAd9iQgdwZIYMG9P3lx2+jQr2zzx3VYjca1ZbelpHdivNOc3Yb2L+3i9PX4iDPK6eTtNiN6jVWu5UUnCEN1cRuFBqWTp88nrMbLaS6owpkMY/tzp1o3F3VbnevHIXdAKhHdluzcvGCrxeqOGvaFzOoTfuOxs5eP0XJ4mjOvnjfYROGdzHvqtJy6ffLliyYVZ3dgnx2W5iZ+Hlt5+zWonnzC+kHS+9cXLtioRa7rVm+wHPHz2S3dauXcHZr0dww60Tco8Kzq5fN5+xGldS9nJPKdlswe4owYI/6fjftdnt8I8Nh+OBw3x3cfreLJyWkNr7H5kH9ezG72ViZR/B3luT/JvTfRY/L7EYTwgM7SWFfLpmlbje6teD8QdgNgDqwW3JcuF1PG/WT3TSeEWI/eohKy74Deqmf78bZ7Y/ia3Y2VvSXs5s4ZB+NSY2MWu3+daMWu93JPjVhzAiq4Hz2bOXsJgz0oDEpVVU7tzhxdvvsX2MNmzVTOWY6cthg0sqoEfbKx0x12u3SqVgan97LOUF2yzufNGak/MArzUk/JGB2S47ys7O2oIEqzRfwdzC7kdrYWNXdbYO63T6dMLJZs6awGwB1YLdnjwusLM1cfbaon/K2aP1Sq57dDZoYUMxtLRasWyzOkii32cJ3s7QwrdvvKuCbWADAbprt9qL8VliAl1V389f4nqm1rVUI3x3fM4XdAKindqPMnz3toxH2r3SNEIcxw2dN+xTXCIHdAKjXdntanDdp4lgSXOgpYU2qtpFjho9xGI7ru8FuANR3u7Fr886bPc3a2nLnge1a1LY7YIedXfdZ0z/FtXlhNwD0w27sdxXC/L2sLM1797Zb+91Kj7A94sxoMlqkTLJX7PWt09qBA/taWZiF8D3wuwqwGwB6Zjf2m1hJkrA1KxYNHNCnSRMDdi6IlaXZFwtnx0cG4jexYDcA9NVu+D1T2A0A2A12g90AgN1gN9gNgLdgt93bXI4miiqTIDoij1CeeEpEZaQC5RxWJFyeOErYIUVCD8VWJpkioYQoJbgiQckx8iSxRFMCWQ5SogIq4s+SqJzIA87fraa/iZH8RDEXvwSKqEriRb4V8YkXKiIV7pdGVI3AuyL7WOLk2atIuDyxLGFeFfGUUEIpHpqyRxKiSEyIuzzBFN5m57WwGwBvw26gToDdAKhFu5WVlaVVwOPxXF1dnZ2dnZycXPSBGTPkFy9xdHR00U8CAwNhNwBqy27KpKenS6VSgUAQpCf0eYmdnV2QPkMdTt1OnV9YWIjVGoBasZtMJqMKQiKR0PYWXO/x9PR877336G+rVq22b98erJ9QV1OHU7dT5xcVFWG1BqBW7EYjo8zMTNrSqJQQ13vWrFkzePBgmhg/fvy8efPE+gl1NXU4dTt1fklJCVZrAGrFblQ70DZGRQSNklLqPba2tps3b6YJNze37t27p+gn1NXU4dTt1Pnl5eVYrQGoFbvR1kXlA21mhYWFefWbU6dO0bA0Ozub/du1a9e4uLg8PYS6mjqcup06//nz51itAagVu+kR27ZtW7BgAffvV1995eLignUCANhN7+ndu/exY8e4fzMyMszNzV+8eIHVAgDYTY/Jz8/v1KmTisvs7OzIcVgtAIDd9Jjvv//+22+/rclMAADspk9oLNM0FnQAANhNb9Cyi01lZxwAAHbTJ7QcHlU5kAoAgN30CSrcZDKZxpvu37/fsmVLDE4BgN30j/j4+P79+2tpMGjQIIlEgpUDANhNz1i1ahUNP7U0CAwMnDp1KlYOAGA3feLZs2fGxsbZ2dla2tDgtE2bNqWlpVg/AIDd9IbIyMhRo0bpbDZx4kQ+n4/1AwDYTW9YsmSJu7u7zmYREREkOKwfAMBu+kFJSckr/WQBrpUGAOym573QCP0AAOwGuwEAYDfYDQAAu8FuAADYDXYDAMBusBsAsBvsBgCA3WA3AADsBrsBAGA32A0AALvBbgAA2A12AwB2g90AALAb7AYAgN1gNwAA7Aa7AQBgN9gNAAC7wW4AwG6wGwAAdoPdAACwG+wGAIDdYDcAAOwGuwEAYDfYDQDYDXYDAMBusBsAAHaD3QAAsBvsBgCA3WA3AADsBrsBALvBbgAA2A12AwDAbrAbAAB2g90AALAb7AYAgN1gNwBgN9gNAAC7wW4AANgNdgMA1F+7lZaWHtNnyG56/fzLysqwKgNQK3ZjggB1RVpaGlZlAGrRbrztrimJ4pcRsRzlkkARUo7IE3EknovgiFQ94YcVCTscp8ihuNBDsVWSLAlRSnBFguSJqUwSJTqwIgHyRAUclMdfOYnyHEiM5MKXR0zxU0Tkl1AZXy7xIh95hJT9LFJKBBdvqYBlX0X2UuJYwrl4UWLDWDwVCfWQaMgeeUJY3Dc7r4XdAKh1u5HXXpTffplbL8rk+V/ZTUVKKYWUv+W58fcTLgV/Py54Ls91RR5R8p8pkvesRJG/SnL/esiSw/Lng2ylXPuzWJ4/iq/Kc59yheUp5d7lilySp+jS7/JcVOTuBUq5PLLyO1yyyii3KecVuXW+9Na5ipwtvanIk5uZ8hRSzrA8Ljz9+AaXjMcFGY/kSVfk+ilKCUv+yYr8RnmYx3JCkdzjDyqT9iCH5VgxJZslNSaYB7sBALs1WLvxeLz09HSZTJaXl1dUVFReXo41GwDYrSHYzdXVVSqVpqSkZGZmkuBKSkqwZgPwluxW/iAvUOA9c+E0617WTQ2bsX3hZpamn8+ZEh8V9MeDPNjtn9jN2dlZIBBIJBISHFVwVL5hzQag1u32rLRwp9fWzqZdLGwt566dvzVouzAzKvqiVJwl2SHgLVq/1LavnalZtyC+O+z22nZzcnIKCgoiwVEFR0PUwsJCrNkA1K7dHt67Mmby2K4W3TZ5u5LRqouL7xYza/Pp0/5Vdu8q7PYadnNxcSG7BQcHi8ViKt9ocIo1G4BatNvDe1ftHYb0Hdov8HiYFrWxhGeIqbHDyI/Kiq7CbrAbAPXXbs9Lb1LVRmojbelUGwuNVUlwM6dNgt1gNwDqr912ernRgLQmVZtKBdfdxjKE7w67wW4A1Ee7/V6S39m0i/Z9bdVlC9/N0sL0aXFOvbLbk5tn64/d7l1Lhd0AqBu7BUV4W9haqptLmBk1e/Xcjt06GTQx6GZpsu7X9UPGfGTT11alWb8BveNE/pzdaMmc3SQCv6ZNm9CcFs2bJ8UEvTW79e5pU0O7KX/9s3lzw2H2/TOPit6I3WiBzG697KxgNwDqxm4zF06fu3a+irNE52JIZBq/BK7Scs2GVUsXzlK3W5zwAEktTsinwk0UvLdly/dTEyPejt3oOdTcblztdj/3t43ffTloQO83azeagN0AqBu7Wfey3hq0XcVZc9bOpzat27WmEWuULC4sXUh1nEa78UR7bK0t1e1GVRvVbtzIVBi0d9sv/2F2K8o9PWHMx9Rg3Ojhd3MzmN3ojm4/f29q0pXmx4TvZ3a7k31ywpgRTZs0GTtq2O1rvzG7Ucstm/5tbtqNvJYiDenb244afGDczmfPFqY2BnktP+vIqBH2dOvIYYMLZEeZ3eimzT9+Y27aVcVuFFIYNWZ2u551aJzDR/TvmI+H5J9PZnaL4O+kOQYGjXvYWsaGeTG70UI4u8mlpmQ37snAbgDUgd0MDAzYKbvK6Wzahdr87POL8kwzazP1kak4SyI3mprdaKK6/W4rlszJlx2j2o1qujUrFnJ2W//VsvKiS6Q2Ehyz2/LFs3LPH6XaTRjosXr5fM5u/nu3ld4+T3az7W6RIPKj2i3Ub5dRq5YqtduSedO9d7tS7ebD+2XRnKmc3fgeW0hh6nbz2rHR/sM+zG5L50+/nB5HhVuY739XLpnF7EZq27fzJyrcxIG7zUy66LQbajcA6tJu6uUYpXHjxhrna4xOu3ElDLNb+3ZtuZFpxw7GnN3K7lxkI1OaZnZr364NNzKllpzdSm9nqY9M5Uuoarc2rY0eF2aS3R7kp5P7OLs9Kjitvt+NzDXJ0eFKupTZrX3bNtzItMMH7Zndxo8aNmPyeFLb/Zw0bmQKuwGgT7WbxkGoxkhqYDdWu3F2U3YKPTpnN26/G2e3qi0bc3bj9rsVXkr7acPaGZ85UhGnbjc2PmX73UhenN3U97sJA3g9ba1uX0nljpmqPDSzW+7ZRIdhg2hRLd9/LzUuAHYDoF7brUcfW/X9bm2M28qv1RPpqdNu/Oj91e13ixMe4OwWGyE/fsrsZmTUSv2ogka7GRm1VD+qoGy3gf17u/zna1Ggx+WMRHW7Ub3GareS66fJR1rs9nJYumn65PGc3ei+1R1VIH95bnfu1MFYxW53rxyF3QCoR3ZbsHS2+jHTaV/MoDbtOxo7e/0UJYujOfvifYdNGN7FvKtKyx9+/EbnMVOJwJemY8J9uf1uuVmpZLdg3132A/tpsdvyxbOyzx4muwXu3zH4w77qdmvR3PD88diSG2dWLZvH2Y1qq6Jrv5HdFsz6TBjgrr7fTaPdKA7DB4f77uD2u108KSG18T02D+rfi9nNxso8gr+zJP83kf8uehRmN5oQHthJ/vpyySx1u9GtBecPwm4A1IHdEiShlnaW6ie7aTwjxH70EOVm0suJgwf2q+58NxIcO9+N/lLtxh1VuJOTPm70CJrZq4dN1skELXa7dfXEuFHDSBC97KzPHY9Vt1tEwB4ak1KdtWPLfzi7ffavsYbNmrFjpiOHDaa7jxphr3zMtDq7XToVS+PTezknyG5555PGjBxC96U56YcEzG7JUX521hY0UKX5Av4OZjdSGxururttULfbpxNGNmvWFHYDoA7s9uxxgam5ifp3FUTnYhatX2rVs7tBEwOKua3FgnWLxVmSKsPSME8rC7P69l0FfBMLANhN8T3TEH8vEwuTV/2eafRZSc8eNvieKewGQP2124uyW7NnTRnw0YCaXyMk/lKi44RRs6Z9imuEwG4A1Gu7PS3Om+g4mgQXcjKiJlUbqW2Mw3Bc3w12A6C+243ye3Hu3FlTLazMXfdvrs5r0suJ/DBPGpDOmv4prs0LuwGgH3ZjPxkT5u9lZWHWo5fNyn8v2xG8k53oG3tR6hfts2HjN/aD+tOtIfw9+F0F2A0APbMb5a+S60mSsDUrFg0c0KdJEwN2LoiVpdkXC2fHiwPxm1iwGwD6ajf8ninsBgDsBrvBbgDAbrAb7AbAW7Db7m0uRxNFiiTIcyRBqEg8JaIigiPSKjksT7gicZSwQ4qEHopVJJkiYQmpSLBSgpJj5EliiaYEshykRAVUxJ8lUTmRBzZv/Jb+JkbyE8Vc/BIooiqJF/lWxCdeqIhUuF+eCOV4SwVc9lHi5NmrSLg8sSxhXhXxpEhCWTw0ZY8khMU9hhLMwtvsvBZ2A6DW7QbqCtgNgNqyW1lZWVoFPB7P1dXV2dnZycnJRR/o0KEDCWLYsGEuektgYCDsBkCt2E2Z9PR0qVQqEAiC9IFt27aR2ho3btyiRQtvb+8gfYb6nHqe+r+wsBBrNgBv3m4ymYzKB4lEQhtbcL2nT58+bHDXpk2befPmBest1NvU59Tz1P9FRUVYswF483ajYVFmZiZtZlRHiOs3ISEh7NceCENDQ2Nj44iICLF+Qr1NfU49T/1fUlKCNRuAN283KhxoA6MKgoZIKfWbyZMnk9fGjh3LBNeqVatNmzal6CfU29Tn1PPU/+Xl5VizAXjzdqNNi2oH2sYKCwvz6jfNmzc3MTExMjJitRsxcODAPP2Eepv6nHqe+v/58+dYswFo9M6+8p07d7KSLT4+nv4eOXKE/ZuRkYHVAgDYTY9p164dU5u8FxrJ+4EJrmXLllgtAIDd9JU7d+6QyNzd3RW90EjRD3w+n6ZxRgUAsJu+smXLFolEUtkLjSr7gSq4bdu2Yc0AAHbTSy5fvlylFxo10nIrAAB201dcXFzQCQDAbgAAALsBAADsBgAAsBsAAMBuAADYDQAAYLcGxZIlS9AJAMBuDbEXGqEfAIDdYDcAAOwGuwEAYDfYDQAAu8FuAADYDXYDAHZ7d8E1QgCA3QAAAHYDAADYDQAAYDcAAIDdAACwGwAAwG4NDZwRAgDs1kB74U2fzfvo0SP0KgCwWwO0W4cOHdCrAMBuDdBu+GoXALBbPbLbkydPpkyZ0qJFC1tb2/T0dO6mffv2WVpasgaffPJJ06ZNHR0daZo1OH369IABA2gm1WshISHsLgzWQOO9EhMTaY6BgUGfPn3S0tLwFgAAu9Wi3VavXn3kyBGaiI+P79GjB3eTUCh89uwZa3D37l2aEAgE69atYw2oZWpqKk1ER0e3bt1avXbTeC9SG1PhoUOHmDoBALBbbdnN2Nj4//7v/9Rv4mZSAzZBsuvUqZOWAamy3TTea9KkSfPmzSO1vXjxAv0PAOxWW7AzQmicqEVYykNOgmv86NGjrVu3zpkzh4o4jXar7l7jxo2jCq5Vq1YymQxvAQCwWy3Stm1b7XbjBp7K2Nvbu7q6xsXF3bx5U6PdNN6LQVVhQEBAly5d0PkAwG61yOrVq0+ePEkTqampyvvdlBvcvn2bJoRC4dChQ9nMFi1a5Obm/v333+vWreMaU1H29OlTLfei5ScmJtJEUlISNUbnAwC71SJPnjyZPHkyuaZXr17nzp1TtxsNJx0dHalBnz59srOz2Uyq2khVVKB5eXlxjWfMmGFoaKjlXqdPn6ZHoYEqzWeaAwDAbgAAALsBAGA3AACA3RoauEYIALBbA+0FfC0UANgNdgMAwG6wGwAAdoPdAACwG+wGAIDdYDcAYLd3GJwRAgDsBgAAsBsAAMBuAAAAuwEAAOwGAIDdAAAAdmto4IwQAGC3BtoLOJsXANgNdgMAwG6wGwAAdoPdAACwG+wGAIDdYDcAYLd3GJwRAgDsBgAAsBsAAMBuAAAAuwEAAOwGAIDdAAAAdmtoBAYGohMAgN0aYi/gbF4AGrzdSktLj717LF68+B181WVlZdgAwDtkN1rpG4F3g7S0NGwA4J2zG2+7a0qiuCIiLkeVk0ARshyRJ+JIvHIE8kg1JvxwZcIOx3EJpRyixKomWRJSNcEVCapMTJUkxQQmRSsnQJ6ogIPy+KsnUZEDiZFc+IqIWfwqI/JLqBJfLvEiH0WElP1cpJQI5XjLI2DZVzV7KXFcwpXjFUsJY/GsTKgHRaI5exQJYXGnbHZeC7uBd9RuJLUX5bcrckueMnn+V3azMqWUQpa/5bnx9xPlFFCeP2a5XplHlPxnlcl7VsIll/IX5SFLDpc/H2RXzbU/i+X5o/hqZe5TrnB5ev/y03vKuSRP0aXf5blYmbuUC5RyRWTld7hkUcoot1nOV+bWudIqOVt6U5EnNzMVKaSc4fK48PTjG8rJkKdAnkcF6ZW5TjlFKVHkZEm+cn57SMljOVGZ3OOUB5VJe5DD5VgxSzZLKiUmmAe7AdgNdmuwduPxeOnp6TKZLC8vr6ioqLy8XI/XY9BA2fbrNtgNdntlu7m6ukql0pSUlMzMTBJcSUmJXtvt2dNnSAMLva1GrYx+dfv1Ldmt/GFeoMB75sLp1r2smxo2Y341szT9fO6U+OjgPx/mw276YjdnZ2eBQCCRSEhwVMFR+Qa7IfXNbonSRBKcm5tb7drteenNnV5bO5t2sbC1nLt2/tag7cLMqOiLUnGWZIeAt2j9Utu+dqbm3YIPeMBuemE3JyenoKAgEhxVcDRELSwshN2Q+mY3+isXnJHRDz/8QKsojTCeP3/+hu328N7VMZPHdrXotsnblYxWXVx8t5hZm0+fNqn8/jXYrZ7bzcXFhewWHBwsFoupfKPBKeyG1EO7cYL7/rvv2S6UGgquRnZ7eP+qvcOQvkP7BR4P06I2lvAMMTV2GPkRCQ52g91gN+Sf240SFxNHQ9Tv1n9Xc8HpttvzsptUtZHaSFs61cZCY1US3OfTP4XdYDfYDXkjduMEt+6bdTUUnG677dzrRgPSmlRtKhVcd1vLEL4H7Aa7wW7IG7GbYojayuibr7+pieB02O33kuudTbto39dWXbbw3SwtzP54kFcf7Ebmqj92K7meDru9Hbupz/+HHiy6VaR9UTVfvvKi3mbq6nG5nqn5E9DYmWwfXE0Ep8NuQRHeFraW6uYSZkbNXj23Y7dOBk0MulmarPt1/ZAxH9n0tVVp1m9Ab6k4UNluscIDTZs2oYdo0bx5cmzoW7Nbn562NbSb8pmELZobDhvy4bk0yRuxGy2Q2a13D2tmN+6BmjZp0qenzRGJvxa7UTNmN5pQtxvNbEh2e/bs2Y2CG5RTp06lpqSGh4X7H/Dft3ffT5t+2vDDhkULF1EmjJ8wcuRIWxvbNq3bvDW7ffDBB7WxqLeZunpcrrtq/gSq62EmuG/XfatdcDrsNnPh9Llr56s4S3QuhkSm8cRilZZr/rNq6cLZnNqk4gCSmlTkT1WbOMS7Vcv305JEb8du9Nxqbjeudiu5cWbThrWDP+zzZu32ckJhN1a7Pcw/6fnfjd0tTWtSu+mX3e7du0eSunb1GkmK85TbVjfOU7M+nzXyJeQpMzOz5s2b03Ojv2amZhT7wfYjPx75+czPF85fuGLZio3OG7f8ssXPx48SFxN36OChC+cvFN8trvnm8Q+VpHz3N7iouh3uveXHrfkT0PlNhvT0dC2C02E3617WW4O2qzhrztr51KZ1u9Y0Yo2SxYWlC6mO02g3nmiPrbUVZzeq2qh240amJLj/bnZmaruff9Zx7EhqMG70iHt5Z5ndaIG/um4wM+kqv2OEH1NbUe6ZCWM/Zi3v5mYwtVFLt5+/tzDrRl47lijo17sHNfjAuJ2f569MbQyy241Lx0d/PJRqJYfh9jevHGd2o5u2bPq3uWk3FbtRntw6R42Z3W5ePjZ+9HD6d6zDR4WXUpnaxEEeNMfAoHFPu+4JIl+mNloIZ7eX05V2456Mst1Ymjc3ZHaTl2kVdntZsmmu3bJPSz8e+iHdy3vXJs5uuWcTxo4cQk9p9IjBuZnxzG50688/rDIz6fwP7fbkyRNS1fnz58lTIqGIPOXr4/uL6y8/Ov/4xdIvmKeG2A8xewnzVMeOHUlSZC6SFOep79d/z3kqJDCEJMU8lXM1p7SktFa3ZG6OJErStGlTAwOD3r16H046zGbev3PfcYIjzR8/bjxNV7excf+Gh4S3adOG2pNqa7L86hZ1p/DOmNFjqP0oh1EaB270ZCZPmtyiRQsba5u0lDRuIXt4eyzMLap75ieOnejXrx/NpHLJ389f/XG1v96aPITGl6nxM4BNqDwB7b2k881lp2pWJzgddqNHZafsKqezaRf51uLzi/JMM2sz9ZGpOEtCLTm7yaer2e+2cum8gksnqHaLDN2/duUizm7ffb3ij+JrpDayFbPbiiVz8y8co8JNHLxvzYqFnN0CvXdSXUZ2s7W2PBgVQLVb+AF3I6OWKrXb0gUzffZsoarNz8Nt8bzpnN38924rvZ2lbrd9u12HDOzH7LZs4czszCSaiDjAW/XFXGY38oiP+y9UtUWHepmbdtVpN421G2Xvzk2bf/z6ley2ZN5UH97PxTlpKxfN5Oy2ZO6UCyeiqGoL8XZbsWgmZ7f9uzbdu5qqbDeykvc+77179/J28zz2eLjz3OkvlVSUlStWckM/KysrUhUb/bVu3ZpU1bdvX/LUtKnTyFNLFy912uDk8pOL915v5qnjqcdJUm/cU2/cbrRRsQ0+Pjaebb2UlctXFuQW0ERwQPBXa77SWbt99+/v/iz/k9RGS6vJ8qtb1LKly/g+fLa1U5eqN6YnRsMxmoiOjLazteOWEBoUyvpZ4zOnlsmJyTQhDBe2Nmqt/rg1eb3aH0Ljy9RiN5VbdfaS9jc3LCxMi+B02E29HKM0btxY43yNqc5ulQp/abf27dpyI9OOHYw5u/1+7yobmdI0sxu15Eam1JKz2+9Fl9VHpi+lVsVubVobld2Rkd0e3Txn1KolZ7eXalPd70bm+nTi6OzMZGa39u3acCPTDh+0Z3abMGbEzCkTSW0l109zI9Oa202ZrZvWvZLdjNu3JbXRRMH5g5zd2rVtzY1MOxi34+z2Um1VRqZaoA98h5EOX3/19aaNm6Sx0sPJh+/evNswDrrRBzab+MTxk9mzZtNG9bT0KXdr+/bt2QRtz1R16rQbd1/1TVfj8qtbFBWAZEmaoL+chpRDT4w1UFkCN7Pmz1z5cWtyL+0PofFl1txuOntJ+5sbGBgoEAgOHjyYmZlZWFiociWI16ndNA5CNUZSvd2eVTiO2U1506IH5ezG7Xfj7KbSkrMbt9/t9rWTPzt9M3PqJ1TEqdvtpQcVO91IXpzd1Pe7RQZ79rLrXpRzkjtmWvWhGzO7FVxIGTXCnhbV8v33ThwMf+3aLSUugGz1SnajB1Xf76byJDm7qe9327hx465du7Zv305DVDc3N5rw8vJyecmqVauWLFkyceLEUaNGde/e3dzcvEkT+bEg2ghpun///g4ODjNmzFi8aPGyL5bRsJTKQJ/9PmEhYUeSj5xIO5F7LZdSH2o3Gsop/0sbKjeHBoBsMNiqZaszp86o7+jhPFiT/W7qm67G5ddkUVwZqFHKWpag/szpObj+7Pr5zM+piNMol1d9vRofQmM31tBuOntJu92Ud61cuXJF5UoQOuzWo4+t+n63NsZt5dfPifTUaTd+jI/KfjepKICzW5zIn+Ywu7U2aqV+VEGj3YyMWqkfVVC226ABfVyd10WG7L2aeUjdblSvsdrtya2sli3f12I3Niyd8ZkjZzf5fas5qvD4xpm9O3/u1PEDFbsV552sod0ozZo1VbFbUfYxLXbr8EG7e9nHaKJQlszZzajV++pHFTTa7TX2u5WWltInpEwmo/UkMjKSPjn5fP6WLVs2bdq0fPnyOXPmkA2HDh1q/hK2361Tp040bWdnR0J0dHQkIVI2/LCBxr9uW90O8A8wJ1Iuyi6+cSc6TnC8cP4C92/W2axRDqNUfOe737dz587sX4110+vZTePyq1sUPS4rXqg9befqjelzRecS1BsMGjho04+bIkWRuVdzNT7DV3q9WhqrvEzuXuWPy7XbTWcv6RyZ0krIxqdUvqlcCUKH3RYsna1+zHTaFzOoTfuOxs5eP0XJ4mjOvnjfYROGdzHvqtLyh43fVHfMVCLk0zT95fa75V9II7uF8N3tB/bXYrcVS+bmylJJbcG+u+0H9lO3W4vmhhdOJTy+nbVm+QLObqTR4vzTZLeFc6aJg73U97tptBtl1MdDIvzduf1uV08fpImAvb+SQ5nabLpbiIP20Jg0KtiTiilmN5qIDPJ4VJCxetlcdbvRrbevpKrYjef2n+FDPmR2owaigN0P8n5btXS2FrutXDxz15bvaWLt8rnK+91kaWLymh/v54H9er5Zu70G9+/fJyFmZ2fTqpWUlBT4km3bttGjOzk5UYXInEiQATkn0l/OicTs2bPJiV+u/JJzIiUpISkzI5OEWFxU7THTtJQ00hlt2zR97fI1KhNoEMTtk5JESdgZ8Fy5tHL5yvzsfJoIDQq1H2yvvkBqWVJcUhO7aVx+dYtavHAx2/1Ejavb75Z6JJUmkhOTlfe7KTdQf+ZUqF6SXSLFfLXmK+Udgtzj6ny9Oh9C48tkh1nIWV9/9bV6zyg/AZ29pN1uQqGQVqeQkJDo6Ojjx4+rXAlCh90SJGGWdpbqJ7tpPCPEfvQQ5WbSy4mDB/VXOd+Najd2vhv9jZNrTnFUoSg3c/zoETSzVw8b2akkLXa7k5MxrqJl1skEdbuJgrxoTGpk1HKX24+c3aZMGmfYrBk7ZuowXD6QHP3xUOVjptXZ7eqZpJ523R8WnCGp3biYOtbhI7ovzclMjWJ2OxIbZGdjSWNAmi8O3MPsFhnswcaqnts3qttt8sTRhs2aqpzvRmqTnYhhdiO1sbvv2eakxW55ZxPHjhxKFZzXdmfObjln4kePGEx372FjefJgSJ3b7bXPd+OcSERERNBKvH//fs6JxLhx42iMTBKkukbLSQbhIeEmJia05dDf/fv2c/NPHDvRs0dPGmHRTWwDYwOl8ePG05zevXorF31cpk6ZamhoWBO7aVx+dYu6U3iHLEwtyb/VHTOd9MkkakDLTD+RrnGIp/7MqWojfVDNxdvF4xorP67O16vzITS+TKYqKkKpw9V7RvkJ6Owl7XYTiURa1mEddnv2+IapuYn6dxVE52IWrV9q1bO7QRMDirmtxYJ1i8VZkirD0jBPq3rzXQV8EwvfxEIa3ve0/pHdKCH+XiYWJq/6PdPos5KePWzwPVPYDXZD6q/dXpTfmj1ryoCPBtT8GiHxlxIdJ4yahWuEwG6wG1LP7fb0Qd5ExzEkuJCTETWp2khtYxyG4/pusBvshtR3u8kFV5w3d9Y0Cytz1/2bq/Oa9HIiP8yLBqSzpk/GtXlhN9gN0Q+7sV+NCfP3srI069HLZuW/l+0I3slO9I29KPWL9tmw8Rv7Qf3p1lD8rgLsBrsheme3/5Xd/OvR9aTYsDUrFw8c0LdJEwN2QgNJ7YtFs+MjA/GbWLAb7Iboq93we6awG+yGwG6wG+z29uwG3kFgN9it4duNg14IvRx6UfTSROAd4JXttnuby9FEUZUkyHMkQViZeEqEUgRHpKo5rEh4ZeIoYYcqE3ootkqSKRKWEKUEV01Qcow8ScqJpgRyORgdcDBKOf4siSqJpBxQCj9RzMWPkkARqcc3vkp84oWKSIX7FYlQibdUoJx9XOIEeysTrkisIl6xYcrxlFBCWTyqzx5JCBf3GJZgFh5ls/Na2A28o3YD7wIN0m7p6elSqVQgEASBdwZ6u9k1LHV8i76srCytAh6P5+rq6uzs7OTk5AIaHIGBgQ3PbjKZjF6LRCKhNT4YvAPQG01vN73p9NbruAISPgbxuafXkKMzMzNpXacXJQbvAPRG09tNbzq7+HhN7YaPwXf5c09PoVdBazm9HPJ1CngHoDea3m560+mt13HlcXwM4nNPr6H1m14IrehUiuaBdwB6o+ntpjed3nodvxqDj0F87gHQMGiEj0F87mn83AOgIdsNAABgNwAAgN0AAAB2AwCA1+P/A/kRoXWdOzvsAAAAAElFTkSuQmCC" alt="IGeneratorResult and IValidationResult" id="fig:IGeneratorResultClasses "
 * data-latex-style="scale=0.7" />
 *
 * <pre>
 * <!--PlantUML: IGeneratorResultClasses
 * {@link IValidationResult} <|-_ {@link IGeneratorResult}
 * {@link IGeneratorResult} <.. GeneratorResultBuilder : creates
 * note right of GeneratorResultBuilder : Use this to create results
 *
 * -->
 * </pre>
 *
 * You must not implement the {@link IGeneratorResult} interface to make you own results!
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see GeneratorResultBuilder
 * @noimplement This interface is not intended to be implemented by clients. Please use GeneratorResultBuilder
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGeneratorResult extends IValidationResult, IFormattable {
    /**
     * Gets the exception which has caused this generator result, or null if no exception has caused this result.
     *
     * @return The exception or <code>null</code>.
     */
    @PublishedMethod
    Throwable getException();

    /**
     * Gets the Result Id (Origin,Id, etc.) of this Result. The ResultId is used to group certain messages together.
     *
     * @return The ValidationResultId
     */
    @PublishedMethod
    @Override
    IValidationResultId getId();

    /**
     * Gets the description of the Result.
     *
     * @return The Description
     */
    @PublishedMethod
    @Override
    IMixedText getDescription();

    /**
     * Gets the Severity of the Result.
     *
     * <p>
     * The severity "<b>Improvement</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The settings are correct and valid but may not be optimal with respect to embedded code generation. E.g. modifying this value may reduce memory consumption or CPU
     * load.</li>
     * <li>The detection of Improvement may be executed during generation or in a separate step that has to be triggered by the user (e.g. "Find Improvements").</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Info</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>Some settings have been adapted by a clearly defined rule (e.g. using of a default value). Applying this rule has not modified the behavior of the software.</li>
     * <li>General information for the user e.g. the finalization of the generation process.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Warning</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The configuration may be faulty or in some way incorrect but there are reasons why the user might require such a way of configuration.</li>
     * <li>The output files can be processed without problems (e.g. no compile errors...)</li>
     * <li>It may happen that the output files will lead to a non functioning system in case the warning is ignored by the user.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Error</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>Input data is not consistent e.g. conflicting settings</li>
     * <li>Using the output files lead to problems in the following processing steps or in an invalid runtime behavior of the ECU.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Fatal Error</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The detected internal fatal error is so severe that processing (e.g. generation or validation) cannot be continued.</li>
     * </ul>
     * Hint: Do not report Fatal Errors!
     * </p>
     *
     *
     * @return The Severity of the result
     */
    @PublishedMethod
    @Override
    EValidationSeverityType getSeverity();

    /**
     * Gets the erroneous Configuration entities involved in the result.
     *
     * @return Collection of CEs.
     */
    @PublishedMethod
    @Override
    Collection<IDescriptor> getErroneousCEs();

    /**
     * Gets the solving actions registered to this Result.
     *
     * @return Collection of Solving Actions
     */
    @PublishedMethod
    @Override
    Collection<ISolvingAction> getSolvingActions();

    /**
     * Gets auto solving Action.
     *
     * @return A auto Solving Action
     */
    @PublishedMethod
    @Override
    ISolvingAction getAutoSolvingAction();

}
