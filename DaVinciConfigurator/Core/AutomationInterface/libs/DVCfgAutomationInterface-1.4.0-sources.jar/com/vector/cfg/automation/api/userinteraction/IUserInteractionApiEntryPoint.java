package com.vector.cfg.automation.api.userinteraction;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IUserInteractionApiEntryPoint} provides API to display messages to the user.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IUserInteractionApiEntryPoint {

    /**
     * Returns the {@link IUserInputApi} for the currently running script task.
     *
     * @return the user interactions
     */
    @PublishedMethod
    IUserInteractionApi getUserInteractions();

    /**
     * Executes the passed code with the {@link IUserInputApi} for the currently running script task as delegate.
     *
     * @param <T> the generic type of the return value of the closure
     * @param code the client code to execute
     * @return the return value of the code closure
     */
    @PublishedMethod
    <T> T userInteractions(@VDelegatesToWithClosureParam(IUserInteractionApi.class) Closure<T> code);
}
