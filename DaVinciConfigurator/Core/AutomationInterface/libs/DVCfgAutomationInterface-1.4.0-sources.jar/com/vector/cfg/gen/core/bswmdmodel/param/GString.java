package com.vector.cfg.gen.core.bswmdmodel.param;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIStringParameter;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.BswmdModelInternalElementFactory;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractParam;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.gen.core.utils.formatting.primitives.StringGenElement;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucStringDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucStringParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIStringParamDef;

/**
 * String parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GString extends GAbstractParam<String> implements GIStringParameter {

    private String value;

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public GString(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MITextualValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MITextualValue getMdfObject() {
        return (MITextualValue) super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MITextualValue getMdfObjectUnsafe() {
        return (MITextualValue) super.getMdfObjectUnsafe();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @ReworkThisAtNextBreakingChange("Remove method - implemented in base type")
    public boolean hasValue() {
        return super.hasValue();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getValue() {
        return getValueMdf();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getValueOrDefault(String defaultValue) {
        return getValueOrDefaultMdf(defaultValue);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getValueMdf() {
        if (isValueChecked()) {
            return value;
        }
        try {
            switchView();

            final MITextualValue mdfObject = getMdfObject();
            final String valueLoc = mdfObject.getValue();
            getModelVerifier().assertParameterValueNotNull(this, valueLoc);

            value = valueLoc;
            setValueChecked();
            return value;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public StringGenElement formatValue() {
        return F.formatString(this);
    }

    /**
     * Checks if the parameter has a value node AND the string is not empty("").
     *
     * @return true if the value node exists and the string is not "".
     */
    @Override
    @PublishedMethod
    public boolean hasValueAndNotEmpty() {
        if (hasValue()) {
            return (!getValue().isEmpty());
        }
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(String valueOf) {

        BswmdModelInternalElementFactory.setValueMdf(this, () -> getGeneratorModelAccess().getMdfModelAccess().setAsString(getMdfObject(), valueOf));
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValue(String newValue) {
        this.setValueMdf(newValue);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIStringParamDef getDefinition() {
        return (MIStringParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucStringDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucStringParameter getEcuConfiguration() {

        final IEcucParameter cfg = super.getEcuConfiguration();
        return (IEcucStringParameter) cfg;
    }

}
