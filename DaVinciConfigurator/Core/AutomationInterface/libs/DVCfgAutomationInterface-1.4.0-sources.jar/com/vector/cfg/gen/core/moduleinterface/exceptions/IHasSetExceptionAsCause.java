package com.vector.cfg.gen.core.moduleinterface.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * Marks an object that it can hold a exception.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasSetExceptionAsCause {

    /**
     * Passes an Exception to the object.
     *
     * @param ex the {@link Throwable} to set as a cause of something.
     *
     * @exception IllegalArgumentException <ul>
     * <li>if ex is null</li>
     * </ul>
     *
     * @exception IllegalStateException <ul>
     * <li>if an other exception was already passed to the object.</li>
     * </ul>
     */
    @PublishedMethod
    void setException(Throwable ex);

}
