package com.vector.cfg.model.access.ecuconfiguration;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.core.project.EConfigurationPhase;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigurationVariant;

/**
 * This enum contains the configuration variant encoding required for post-build loadable.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@SuppressWarnings("deprecation") // Must use deprecated MDF model methods and types to hide AUTOSAR version differences
public enum EEcucConfigurationVariant {

    VARIANT_PRE_COMPILE,
    VARIANT_LINK_TIME,
    VARIANT_POST_BUILD_LOADABLE,
    PRECONFIGURED_CONFIGURATION,
    RECOMMENDED_CONFIGURATION;

    /**
     * This method translates the hidden MDF enum to this published enum. It returns <code>null</code> if the conversion is not supported.
     *
     * @param variant
     * @return
     */
    @KeepSecretFromPublishedApi
    public static EEcucConfigurationVariant fromMdf(MIConfigurationVariant variant) {
        switch (variant) {
        case VARIANT_PRE_COMPILE:
            return VARIANT_PRE_COMPILE;
        case VARIANT_LINK_TIME:
            return VARIANT_LINK_TIME;
        case VARIANT_POST_BUILD:
        case VARIANT_POST_BUILD_LOADABLE:
            return VARIANT_POST_BUILD_LOADABLE;
        case VARIANT_POST_BUILD_SELECTABLE:
            return null; // Not supported anymore in AUTOSAR 4.2.1
        case PRECONFIGURED_CONFIGURATION:
            return PRECONFIGURED_CONFIGURATION;
        case RECOMMENDED_CONFIGURATION:
            return RECOMMENDED_CONFIGURATION;
        default:
            return null;
        }
    }

    /**
     * This method translates this published enum to the hidden MDF enum. It never returns <code>null</code>.
     *
     * @param variant
     * @return
     */
    @KeepSecretFromPublishedApi
    public static MIConfigurationVariant toMdf(EEcucConfigurationVariant variant) {
        switch (variant) {
        case VARIANT_PRE_COMPILE:
            return MIConfigurationVariant.VARIANT_PRE_COMPILE;
        case VARIANT_LINK_TIME:
            return MIConfigurationVariant.VARIANT_LINK_TIME;
        case VARIANT_POST_BUILD_LOADABLE:
            return MIConfigurationVariant.VARIANT_POST_BUILD_LOADABLE;
        case PRECONFIGURED_CONFIGURATION:
            return MIConfigurationVariant.PRECONFIGURED_CONFIGURATION;
        case RECOMMENDED_CONFIGURATION:
            return MIConfigurationVariant.RECOMMENDED_CONFIGURATION;
        default:
            return null;
        }
    }

    /**
     * Compares this enum value with the specified configuration phase. If this enum is smaller (earlier) than this configuration phase it returns -1. It returns 0 if both are
     * equal and 1 if this enum is larger (later) that this configuration phase.
     * <p>
     * <h1>Example</h1> Comparing {@link EEcucConfigurationVariant#VARIANT_PRE_COMPILE} with {@link EConfigurationPhase#POST_BUILD} will return -1. Comparing
     * {@link EEcucConfigurationVariant#VARIANT_PRE_COMPILE} with {@link EConfigurationPhase#PRE_COMPILE} will return 0.
     * </p>
     * <p>
     * <b>Remark:</b> {@link #PRECONFIGURED_CONFIGURATION} and {@link #RECOMMENDED_CONFIGURATION} are will always return -1 and are therefore defined as smaller than each
     * specified configuration phase.
     * </p>
     *
     * @param configurationPhase
     * @return
     */
    @KeepSecretFromPublishedApi
    public int compareTo(EConfigurationPhase configurationPhase) {
        switch (this) {
        case VARIANT_PRE_COMPILE:
            if (configurationPhase == EConfigurationPhase.PRE_COMPILE) {
                return 0;
            }
            return -1;
        case VARIANT_LINK_TIME:
            if (configurationPhase == EConfigurationPhase.PRE_COMPILE) {
                return 1;
            } else if (configurationPhase == EConfigurationPhase.LINK_TIME) {
                return 0;
            }
            return -1;
        case VARIANT_POST_BUILD_LOADABLE:
            if (configurationPhase == EConfigurationPhase.POST_BUILD) {
                return 0;
            }
            return 1;
        default:
            return -1; // Other values are smaller
        }
    }

}
