/**
 * Automation scripting related objects for model abstractions.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
package com.vector.cfg.model.abstraction.api;