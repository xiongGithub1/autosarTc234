/**
 * Software Component Templates and Contract Phase Headers (Swct) generation API AutomationInterface scripting API for client side scripts. This package contains API to validate
 * and generate software component templates and headers.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.genusage.groovy.api.swct;