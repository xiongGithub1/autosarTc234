package com.vector.cfg.automation.api.domain;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.util.scripting.dynamic.DynamicTarget;
import com.vector.cfg.util.scripting.dynamic.IDynamicObjectAware;

/**
 * {@link IDomainApi} provides methods for accessing the different domain-specific APIs. <div class="extdoc" id="IDomainApi"><!--Label:IDomainApi-->{@link IDomainApi} provides
 * methods for accessing the different domain-specific APIs. Each domain's API is available via the domain's name. For an example see the communication domain API
 * <!--Ref:ICommunicationApiEntryPoint-->.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@DynamicTarget({
        "com.vector.cfg.dom.com.groovy.api.ICommunicationApiEntryPoint",
        "com.vector.cfg.dom.diagnostics.groovy.api.IDiagnosticsApiEntryPoint",
        "com.vector.cfg.dom.modemgt.groovy.api.IModeManagementApiEntryPoint",
        "com.vector.cfg.dom.runtimesys.groovy.api.IRuntimeSystemApiEntryPoint"
})
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDomainApi extends IDynamicObjectAware {

}
