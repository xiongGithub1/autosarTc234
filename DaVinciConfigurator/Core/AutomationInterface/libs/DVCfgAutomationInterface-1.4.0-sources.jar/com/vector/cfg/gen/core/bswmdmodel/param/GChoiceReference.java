package com.vector.cfg.gen.core.bswmdmodel.param;

import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractRefToContainer;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucContainerDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucChoiceRefDefinition;
import com.vector.cfg.model.access.ecuconfiguration.reference.IEcucChoiceReferenceParameter;
import com.vector.cfg.model.access.ecuconfiguration.reference.IEcucSimpleReferenceParameter;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrableARRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIChoiceReferenceParamDef;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * ChoiceReference parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GChoiceReference extends GAbstractRefToContainer {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GChoiceReference.class);

    private MIContainer value;

    /**
     * Constructor.
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GChoiceReference(DefRef defRef, MIReferenceValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, boolean onlyOneElement) {
        super(defRef, parameter, modelAccess, parent, onlyOneElement);

    }

    /**
     * Constructor.
     *
     * @param typename
     * @param parameter
     * @param modelAccess
     */
    @PublishedMethod
    public GChoiceReference(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MIReferenceValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);

    }

    @Override
    @PublishedMethod
    protected void initRef() {
        final MIReferenceValue mdfObjLoc = getMdfObject();
        if (mdfObjLoc != null) {
            final MIReferrableARRef valueLoc = mdfObjLoc.getValue();
            if (valueLoc != null) {
                setPath(valueLoc.getValue());
                setTarget(valueLoc.getRefTarget());
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MIReferenceValue getMdfObjectUnsafe() {
        return (MIReferenceValue) super.getMdfObjectUnsafe();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIContainer getRefTargetMdf() {
        if (isValueChecked()) {
            return value;
        }

        try {
            switchView();

            final MIReferrable target = super.getRefTargetMdf();

            getModelVerifier().assertReferenceTargetHasCorrectType(this, target, MIContainer.class);

            final MIContainer targetContainer = (MIContainer) target;
            getModelVerifier().assertReferenceTargetHasCorrectDefinition(this, targetContainer);

            value = targetContainer;
            setValueChecked();
            return value;

        } finally {
            restoreView();
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIReferenceValue getMdfObject() {
        return super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIChoiceReferenceParamDef getDefinition() {
        return (MIChoiceReferenceParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucChoiceRefDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucChoiceReferenceParameter getEcuConfiguration() {

        final IEcucSimpleReferenceParameter cfg = getGeneratorModelAccess().getEcuConfigurationAccess().cfg(getMdfObject());
        return (IEcucChoiceReferenceParameter) cfg;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public List<GIContainer> getPossibleRefTargets() {

        final List<GIContainer> possibleTargets = new ArrayList<>();

        final List<IEcucContainerDefinition> targetDefinitions = getGenModelAccessInternal().getEcucDefinitionAccess().def(getDefinition())
                .getTargetDefinitions();
        if (targetDefinitions != null && !targetDefinitions.isEmpty()) {
            for (final IEcucContainerDefinition targetDefinition : targetDefinitions) {
                getPossibleRefTargetsInternal(possibleTargets, targetDefinition);
            }
        }

        return ImmutableList.copyOf(possibleTargets);
    }
}
