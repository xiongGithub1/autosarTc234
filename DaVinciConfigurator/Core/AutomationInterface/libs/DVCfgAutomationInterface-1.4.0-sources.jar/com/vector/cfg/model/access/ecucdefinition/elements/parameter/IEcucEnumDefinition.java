package com.vector.cfg.model.access.ecucdefinition.elements.parameter;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEnumerationLiteralDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEnumerationParamDef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucEnumDefinition extends IEcucParameterDefinition {

    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    MIEnumerationParamDef getDef();

    /**
     * returns a list of enum literals ({@link MIEnumerationLiteralDef}). Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    List<MIEnumerationLiteralDef> getLiterals();

    /**
     * Returns <code>true</code> if the specified literal is valid for this enum.
     *
     * @param literal
     * @return
     */
    @PublishedMethod
    boolean isValidLiteral(String literal);

    /**
     * returns the optional default value. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<MIEnumerationLiteralDef> getDefault();
}
