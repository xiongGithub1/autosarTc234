package com.vector.cfg.model.access.ecuconfiguration.elements;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucParameterDefinition;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationClass;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;

/**
 * <div class="extdoc" id="Common"> <b>{@link IEcucParameter}</b> is the base interface of all parameter and reference wrappers. It provides the following
 * method(s): </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucParameter extends IEcucHasDefinition {

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    MIParameterValue getEcucObject();

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    IEcucParameterDefinition getEcucDefinition();

    /**
     * <div class="extdoc" id="getEffectiveMultiplicityConfigurationClass"> The {@link #getEffectiveMultiplicityConfigurationClass()} method walks up the model
     * tree to find the related module configuration. Then it uses the module implementation configuration variant to return the selected configuration class as
     * specified in the parameter definition.
     * <p>
     * This method never returns <code>null</code>. In case the detection of the configuration class fails (e.g. if the related module configuration cannot be
     * detected), this method returns {@link EEcucConfigurationClass#PRE_COMPILE} by default.
     * </p>
     * <p>
     * This is for post-build loadable only!
     * </p>
     * </div>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @return
     */
    @PublishedMethod
    EEcucConfigurationClass getEffectiveMultiplicityConfigurationClass();

    /**
     * <div class="extdoc" id="getEffectiveValueConfigurationClass"> The {@link #getEffectiveValueConfigurationClass()} method walks up the model tree to find
     * the related module configuration. Then it uses the module implementation configuration variant to return the selected configuration class as specified in
     * the parameter definition.
     * <p>
     * This method never returns <code>null</code>. In case the detection of the configuration class fails (e.g. if the related module configuration cannot be
     * detected), this method returns {@link EEcucConfigurationClass#PRE_COMPILE} by default.
     * </p>
     * <p>
     * This is for post-build loadable only!
     * </p>
     * </div>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @return
     */
    @PublishedMethod
    EEcucConfigurationClass getEffectiveValueConfigurationClass();

    /**
     * <div class="extdoc" id="supportsVariantMultiplicity"> The {@link #supportsVariantMultiplicity()} method returns <code>true</code> if the related module
     * configuration supports variance and this parameters definition support variant multiplicity. If <code>true</code> is returned this means that different
     * variants may contain different number of instances of this parameter.
     * <p>
     * If the parameter has no definition, this method returns <code>false</code>.
     * </p>
     * <p>
     * This is for post-build selectable only!
     * </p>
     * </div>
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @return
     */
    @PublishedMethod
    boolean supportsVariantMultiplicity();

    /**
     * <div class="extdoc" id="supportsVariantValue"> The {@link #supportsVariantValue()} method returns <code>true</code> if the related module configuration
     * supports variance and this parameters definition support variant values. If <code>true</code> is returned this means that different variants may contain
     * different values in instances of this parameter.
     * <p>
     * If the parameter has no definition, this method returns <code>false</code>.
     * </p>
     * <p>
     * This is for post-build selectable only!
     * </p>
     * </div>
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @return
     */
    @PublishedMethod
    boolean supportsVariantValue();

}
