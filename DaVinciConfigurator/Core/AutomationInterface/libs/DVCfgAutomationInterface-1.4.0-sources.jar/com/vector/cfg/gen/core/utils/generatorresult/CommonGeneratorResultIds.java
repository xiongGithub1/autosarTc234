package com.vector.cfg.gen.core.utils.generatorresult;

//CHECKSTYLE:OFF
import static com.vector.cfg.consistency.EValidationSeverityType.ERROR;
import static com.vector.cfg.consistency.EValidationSeverityType.FATAL_ERROR;
import static com.vector.cfg.consistency.EValidationSeverityType.WARNING;

import java.text.MessageFormat;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.IValidationSeverityResultId;
import com.vector.cfg.consistency.contribution.helper.validationresults.ValidationResultUtil;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasValidationOrigin;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

//CHECKSTYLE:ON
/**
 * Common GeneratorResults, which are used internally by the gen.core but can also used by generators.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class CommonGeneratorResultIds {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(CommonGeneratorResultIds.class);

    private static final int START_OFFSET_FRAMEWORK_IDS = ValidationResultUtil.START_OFFSET_FRAMEWORK_IDS;

    /*
     * Normally it is 94989, but we strip the range, that no one allocates elements before the first section is full.
     */
    private static final int MAX_GENERATOR_FRAMEWORK_ID = 90999;

    /*
     * 94990 - 94999 is used by SwcDescriptions
     */

    @PublishedMethod
    public static int getMaxGeneratorFrameworkId() {
        return MAX_GENERATOR_FRAMEWORK_ID;
    }

    private static String getMsn(IHasValidationOrigin genPackage) {
        return genPackage.getOrigin();
    }

    private static String getGenName(IHasValidationOrigin genPackage) {
        return genPackage.getGeneratorName();
    }

    private static IValidationSeverityResultId createId(IHasValidationOrigin genPackage, int id, EValidationSeverityType severity, String message) {

        final int idPlusStart = id + START_OFFSET_FRAMEWORK_IDS;
        if (idPlusStart < START_OFFSET_FRAMEWORK_IDS || idPlusStart > MAX_GENERATOR_FRAMEWORK_ID) {
            throw new IllegalArgumentException("Illegal id for CommonGeneratorResult found. Min id:" + START_OFFSET_FRAMEWORK_IDS + " Max id: " + MAX_GENERATOR_FRAMEWORK_ID);
        }

        return new ValidationSeverityResultId(getMsn(genPackage), idPlusStart, severity, message);
    }

    private CommonGeneratorResultIds() {

    }

    // CHECKSTYLE:OFF

    @PublishedMethod
    public static IValidationSeverityResultId getFatalGenericGeneratorFailureId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 1, FATAL_ERROR, MessageFormat.format("Fatal Generator ({0}) failure", getGenName(genPackage)));
    }

    @PublishedMethod
    public static IValidationSeverityResultId getTooManyErrorsToContinueId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 2, FATAL_ERROR, MessageFormat.format("Aborting generation process for ({0}) because of previously occured errors", getGenName(genPackage)));
    }

    @PublishedMethod
    public static IValidationSeverityResultId getGeneratorIOErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 3, FATAL_ERROR, MessageFormat.format("Generator ({0}) I/O error", getGenName(genPackage)));
    }

    @PublishedMethod
    public static IValidationSeverityResultId getErrorInOutputFileFatalError(IHasValidationOrigin genPackage) {
        return createId(genPackage, 4, FATAL_ERROR, "Error(s) occured during output file generation");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getGeneratorUnhandledExceptionFailureId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 5, ERROR, MessageFormat.format("Generator ({0}) failure, because of an exception", getGenName(genPackage)));
    }

    @PublishedMethod
    public static IValidationSeverityResultId getUOWErrorInCalculation(IHasValidationOrigin genPackage) {
        return createId(genPackage, 6, ERROR, "UnitOfWork error during calculation");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getPreviousUOWErrorInCalculationWarning(IHasValidationOrigin genPackage) {
        return createId(genPackage, 7, WARNING, "Previous UnitOfWork error during calculation");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getModelAccessFailureId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 8, ERROR, "Model access request failure");
    }

    /**
     * The Error id for Model variant/visibility failures
     *
     * @param genPackage the gen package.
     * @return the result id.
     */
    @PublishedMethod
    public static IValidationSeverityResultId getModelVariantVisibilityErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 9, ERROR, "Model variant/visibility failure");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getContainerFailureId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 10, ERROR, "Container failure");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getContainerNotExistsId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 11, ERROR, "Container does not exist");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getContainerWrongQuantityRequestedId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 12, ERROR, "Container wrong quantity requested");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getParameterFailureId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 20, ERROR, "Parameter failure");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getParameterNotExistsId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 21, ERROR, "Parameter does not exist");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getParameterHasNoValueId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 22, ERROR, "Parameter has no value");

    }

    @PublishedMethod
    public static IValidationSeverityResultId getParameterHasWrongType(IHasValidationOrigin genPackage) {
        return createId(genPackage, 23, ERROR, "Parameter has wrong type");

    }

    @PublishedMethod
    public static IValidationSeverityResultId getParameterHasIllegalValue(IHasValidationOrigin genPackage) {
        return createId(genPackage, 24, ERROR, "Parameter has an invalid value");

    }

    @PublishedMethod
    public static IValidationSeverityResultId getParameterWrongQuantityRequestedId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 25, ERROR, "Parameter wrong quantity requested");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getReferenceFailureId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 30, ERROR, "Reference failure");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getReferenceNotExistsId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 31, ERROR, "Reference does not exist");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getReferenceHasNoRefTargetId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 32, ERROR, "Reference has no target");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getReferenceHasWrongType(IHasValidationOrigin genPackage) {
        return createId(genPackage, 33, ERROR, "Reference has wrong type");

    }

    @PublishedMethod
    public static IValidationSeverityResultId getReferenceTargetHasWrongDefinition(IHasValidationOrigin genPackage) {
        return createId(genPackage, 34, ERROR, "Reference target has the wrong definition");

    }

    @PublishedMethod
    public static IValidationSeverityResultId getReferenceWrongQuantityRequestedId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 35, ERROR, "Reference wrong quantity requested");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getModuleConfigFailureId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 40, ERROR, "Module configuration failure");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getModuleConfigNotExistsId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 41, ERROR, "Module configuration does not exist");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getModuleConfigWrongQuantityRequestedId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 42, ERROR, "Module configuration wrong quantity requested");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getElementNotUniqueErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 100, ERROR, "Element is not unique");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getVersionCheckFailedErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 105, ERROR, "Version check failed");
    }

    /**
     * Gets the version check failed error id integer value.
     *
     * <p>
     * Attention: this number must match the number in the method {@link #getVersionCheckFailedErrorId(IHasValidationOrigin)}!
     * </p>
     *
     * @return the version check failed error id integer value
     */
    @KeepSecretFromPublishedApi
    public static int getVersionCheckFailedErrorIdIntegerValue() {
        return 105 + START_OFFSET_FRAMEWORK_IDS;
    }

    @PublishedMethod
    public static IValidationSeverityResultId getDefinitionRefUndefinedErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 110, ERROR, "Definition Ref is undefined");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getDefinitionRefModelTypeMismatchErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 111, ERROR, "Definition Ref and model type mismatch");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getDefinitionMissingForCEErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 115, ERROR, "Definition for configuration element missing");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getInvalidPathErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 200, ERROR, "Invalid Path specified");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getFileNotFoundErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 201, ERROR, "File not found");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getFileInvalidErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 202, ERROR, "File is invalid");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getUserConfigFileNotFoundId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 220, ERROR, "User config file was not found");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getMissingPreferenceSettingErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 250, ERROR, "Missing Preference setting");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getInvalidPreferenceSettingErrorId(IHasValidationOrigin genPackage) {
        return createId(genPackage, 251, ERROR, "Invalid Preference setting");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getGeneratedValueOutOufRange(IHasValidationOrigin genPackage) {
        return createId(genPackage, 500, ERROR, "A generated value is not in range of the specified datatype");
    }

    @PublishedMethod
    public static IValidationSeverityResultId getCRCCalculationError(IHasValidationOrigin genPackage) {
        return createId(genPackage, 551, ERROR, "CRC could not be calculated");
    }

    // CHECKSTYLE:ON
}
