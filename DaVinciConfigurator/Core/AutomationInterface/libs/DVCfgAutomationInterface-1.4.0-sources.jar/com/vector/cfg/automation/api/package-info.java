/**
 * {@link com.vector.cfg.automation.api.ScriptApi}: Automation entry points to different APIs, like creation current project.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.automation.api;