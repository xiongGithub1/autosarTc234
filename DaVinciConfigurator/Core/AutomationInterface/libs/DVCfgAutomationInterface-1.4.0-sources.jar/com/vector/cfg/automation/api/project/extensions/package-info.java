/**
 * Project extensions for the {@link com.vector.cfg.automation.scripting.api.project.IProject IProject} class and other model objects.
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.automation.api.project.extensions;