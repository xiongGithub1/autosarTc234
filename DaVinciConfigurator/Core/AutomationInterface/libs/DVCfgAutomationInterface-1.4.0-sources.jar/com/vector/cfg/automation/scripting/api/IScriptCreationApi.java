package com.vector.cfg.automation.scripting.api;

import java.util.function.Consumer;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.IApplicationScriptExecutionContext;
import com.vector.cfg.automation.scripting.base.INotExecutableReasonBuilder.IExecutableTaskEvaluator;
import com.vector.cfg.automation.scripting.base.INotExecutableReasonBuilder.INotExecutableReasonBuilderProvider;
import com.vector.cfg.automation.scripting.base.IProjectScriptExecutionContext;
import com.vector.cfg.automation.scripting.base.IScript;
import com.vector.cfg.automation.scripting.base.IScriptExecutionContext;
import com.vector.cfg.automation.scripting.base.IScriptTask;
import com.vector.cfg.automation.scripting.base.IScriptTaskCode;
import com.vector.cfg.automation.scripting.base.IScriptTaskType;
import com.vector.cfg.automation.scripting.base.IScriptTaskType.IApplicationScriptTaskType;
import com.vector.cfg.automation.scripting.base.IScriptTaskType.IProjectScriptTaskType;
import com.vector.cfg.automation.scripting.base.IScriptTaskUserData;
import com.vector.cfg.util.scripting.dynamic.DynamicTarget;
import com.vector.cfg.util.scripting.dynamic.IDynamicObjectAware;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;

/**
 * {@link IScriptCreationApi} is the main interface to create new {@link IScriptTask}s inside of an {@link IScript}. The class provides methods to create {@link IScriptTask}s
 * for all {@link IScriptTaskType}.
 *
 * <p>
 * Groovy: An instance of {@link IScriptCreationApi} is automatically activated in every groovy script, and set as an delegate.
 * </p>
 *
 * <p>
 * Java: Java client have to use the {@link IScriptFactory} to get an instance of a {@link IScriptCreationApi}
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IProjectScriptTaskType
 * @see IApplicationScriptTaskType
 * @see IScriptFactory
 */
@DynamicTarget({
        "com.vector.cfg.automation.scripting.base.IScriptExecutionContext",
        "com.vector.cfg.automation.api.ScriptTaskTypeApi"
})
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptCreationApi extends IDynamicObjectAware {

    /**
     * Returns this {@link IScriptCreationApi}.
     *
     * @return the creation API.
     */
    @PublishedMethod
    IScriptCreationApi getScriptCreationApi();

    /**
     * Sets the description of the script.
     *
     * <div class="extdoc" id="scriptDescription">
     * <h5>Script Description</h5> The script can have an optional description text. The description shall list what this script contains. The method
     * {@link #scriptDescription(String)} sets the description of the script.
     *
     * <p>
     * The description shall be a short overview. The {@link String} can be multiline.
     * </p>
     *
     * </div>
     *
     * @param scriptDescription the description text for the script
     */
    @PublishedMethod
    void scriptDescription(String scriptDescription);

    /**
     * Creates a new script task with the name taskName.
     *
     * <div class="extdoc" id="scriptTask"> To create a script task you have to call one of the <code>scriptTask()</code> methods. The last parameter of the
     * <code>scriptTask</code> methods can be used to set additional options of the task. Every script task needs one {@link IScriptTaskType}. <!--LaTeX: See chapter
     * \vref{sec:ScriptTaskTypes} for all available task types. -->
     *
     * <p>
     * The <code>code{ }</code> block is <b>required</b> for every {@link IScriptTask}. The block contains the code, which is executed when the task is executed.
     * </p>
     *
     * <h5>Script Task with default Type</h5>
     * <p>
     * The method <code>scriptTask()</code> will create an script task for the default {@link IScriptTaskType} <code>DV_PROJECT</code>.
     * </p>
     * </div>
     *
     * @param taskName the task name
     * @param task the task creation code. The {@link Closure} delegates to {@link IProjectScriptTaskBuilder}
     * @return the {@link IProjectScriptTaskBuilder} of the created task.
     * @see IProjectScriptTaskBuilder
     * @see IScriptTaskType
     */
    @PublishedMethod
    IScriptTaskBuilder scriptTask(String taskName, @VDelegatesToWithClosureParam(IProjectScriptTaskBuilder.class) Closure<?> task);

    /**
     * Creates a new script task with the name taskName.
     *
     * <div class="extdoc" id="scriptTaskAndType">
     * <h5>Script Task with Task Type</h5> You could also define the used {@link IScriptTaskType} at the <code>scriptTask()</code> methods.
     *
     * The methods
     * <ul>
     * <li>{@link #scriptTask(String, IApplicationScriptTaskType, Closure)}</li>
     * <li>{@link #scriptTask(String, IProjectScriptTaskType, Closure)}</li>
     * </ul>
     * will create an script task for passed {@link IScriptTaskType}. The two methods differentiate, if a project is required or not. <!--LaTeX: See chapter for all available
     * task types \vref{sec:ScriptTaskTypes} -->
     *
     * </div>
     *
     * @param taskName the task name
     * @param taskType the {@link IApplicationScriptTaskType}
     * @param task the task creation code. The {@link Closure} delegates to {@link IApplicationScriptTaskBuilder}
     * @return the {@link IApplicationScriptTaskBuilder} of the created task.
     * @see IApplicationScriptTaskBuilder
     * @see IApplicationScriptTaskType
     */
    @PublishedMethod
    IScriptTaskBuilder scriptTask(String taskName, IApplicationScriptTaskType taskType,
            @VDelegatesToWithClosureParam(IApplicationScriptTaskBuilder.class) Closure<?> task);

    /**
     * Creates a new script task with the name taskName. The method uses an {@link IProjectScriptTaskType}. See {@link #scriptTask(String, IApplicationScriptTaskType, Closure)}
     * for usage details.
     *
     * @param taskName the task name
     * @param taskType the {@link IProjectScriptTaskType}
     * @param task the task creation code. The {@link Closure} delegates to {@link IProjectScriptTaskBuilder}
     * @return the {@link IProjectScriptTaskBuilder} of the created task.
     * @see IProjectScriptTaskBuilder
     * @see IProjectScriptTaskType
     */
    @PublishedMethod
    IScriptTaskBuilder scriptTask(String taskName, IProjectScriptTaskType taskType,
            @VDelegatesToWithClosureParam(IProjectScriptTaskBuilder.class) Closure<?> task);

    /**
     * Creates a new script task with the name taskName. The method uses an {@link IApplicationScriptTaskType}. See
     * {@link #scriptTask(String, IApplicationScriptTaskType, Closure)} for usage details.
     *
     * <p>
     * This method is mainly for Java clients.
     * </p>
     *
     * @param taskName the task name
     * @param taskType the {@link IApplicationScriptTaskType}
     * @param task the task creation code. The {@link Consumer} passes the {@link IApplicationScriptTaskBuilder}
     * @return the {@link IApplicationScriptTaskBuilder} of the created task.
     * @see IApplicationScriptTaskBuilder
     * @see IApplicationScriptTaskType
     */
    @PublishedMethod
    IScriptTaskBuilder scriptTask(String taskName, IApplicationScriptTaskType taskType, Consumer<IApplicationScriptTaskBuilder> task);

    /**
     * Creates a new script task with the name taskName. The method uses an {@link IProjectScriptTaskType}. See {@link #scriptTask(String, IProjectScriptTaskType, Closure)} for
     * usage details.
     *
     * <p>
     * This method is mainly for Java clients.
     * </p>
     *
     * @param taskName the task name
     * @param taskType the {@link IProjectScriptTaskType}
     * @param task the task creation code. The {@link Consumer} passes the {@link IProjectScriptTaskBuilder}
     * @return the {@link IProjectScriptTaskBuilder} of the created task.
     * @see IProjectScriptTaskBuilder
     * @see IProjectScriptTaskType
     */
    @PublishedMethod
    IScriptTaskBuilder scriptTask(String taskName, IProjectScriptTaskType taskType, Consumer<IProjectScriptTaskBuilder> task);

    /**
     * Adds a unit test task to the script.
     * <p>
     * The added unit test (unitTestClass) could be one of:
     * <ul>
     * <li>JUnit test class</li>
     * <li>JUnit test suite</li>
     * <li>Spock Specification</li>
     * </ul>
     *
     * @param taskName the task name
     * @param unitTestClass the unit test class to execute
     */
    @PublishedMethod
    void unitTestTask(String taskName, Class<?> unitTestClass);

    /**
     * The Interface IScriptExecutionContextWithNotExecutableReasons combines {@link IScriptExecutionContext} and {@link INotExecutableReasonBuilderProvider}.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IScriptExecutionContextWithNotExecutableReasons extends IScriptExecutionContext, INotExecutableReasonBuilderProvider {

    }

    /**
     * The {@link IScriptTaskBuilder} provides the methods callable during creation of an {@link IScriptTask}.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IScriptTaskBuilder {

        /**
         * This enables the usage of features which require a DaVinci Configurator Pro.MD license option. The MD option is only required for the development of the script task.
         * So a user having a .PRO license is still be able to execute the script tasks.
         */
        @PublishedMethod
        void requiresMDDevelopmentLicense();

        /**
         * Sets the isExecutable {@link Closure}, which is called before the {@link IScriptTask} is executed.
         *
         * <div class="extdoc" id="isExecutableIf"> You can set an <code>isExecutableIf</code> handler, which is called before the {@link IScriptTask} is executed. The code can
         * evaluate, if the {@link IScriptTask} shall be executable. If the handler returns <code>true</code>, the code of the {@link IScriptTask} is executable, otherwise
         * <code>false</code>. See class {@link IExecutableTaskEvaluator} for details.
         *
         * <p>
         * The {@link Closure} isExecutable has to return a {@link boolean}. The passed arguments to the closure are the same as the <code>code{ }</code> block arguments.
         * </p>
         *
         * <p>
         * Inside of the {@link Closure} a property <code>notExecutableReasons</code> is available to set reasons why it is not executable. It is highly recommended to set
         * reasons, when the {@link Closure} returns <code>false</code>.
         * </p>
         *
         * </div>
         *
         * @param isExecutable the code which is executed to evaluate the execution state.
         * @return this builder
         * @see IExecutableTaskEvaluator
         */
        @PublishedMethod
        IScriptTaskBuilder isExecutableIf(@DelegatesTo(value = IScriptExecutionContextWithNotExecutableReasons.class, strategy = Closure.DELEGATE_FIRST) Closure<?> isExecutable);

        /**
         * Sets the {@link IExecutableTaskEvaluator}, which is called before the {@link IScriptTask} is executed.
         *
         * <p>
         * See {@link #isExecutableIf(Closure)} for usage details.
         * </p>
         *
         * <p>
         * This method is mainly for Java clients.
         * </p>
         *
         * @param isExecutable the {@link IExecutableTaskEvaluator} instance
         * @return this builder
         * @see IExecutableTaskEvaluator
         */
        @PublishedMethod
        IScriptTaskBuilder isExecutableIf(IExecutableTaskEvaluator isExecutable);

        /**
         * Sets the task description of the script task.
         *
         * <div class="extdoc" id="taskDescription">
         * <h5>Task Description</h5> A script task can have an optional description text. The description shall help the user of the script task to understand what the task
         * does. The method {@link #taskDescription(String)} sets the description of the script task.
         *
         * <p>
         * The description shall be a short overview. The {@link String} can be multiline.
         * </p>
         *
         * </div>
         *
         * @param description the description text for the script task
         * @return this builder
         */
        @PublishedMethod
        IScriptTaskBuilder taskDescription(String description);

        /**
         * Sets the task help text of the script tasks.
         *
         * <div class="extdoc" id="taskHelp">
         * <h5>Task Help</h5> A script task can also have an optional help text. The help text shall describe in detail what the task does and when it could be executed. The
         * method {@link #taskHelp(String)} sets the help of the script task.
         *
         * <p>
         * The help shall be elaborate text about what the task does and how to use it. The {@link String} can be multiline.
         * </p>
         * <p>
         * The help text is automatically expanded with the help for user defined script task arguments, see
         * {@link IScriptTaskBuilder#newUserDefinedArgument(String, Class, String)}.
         * </p>
         *
         * </div>
         *
         * @param helpText the help text for the script task
         * @return this builder
         */
        @PublishedMethod
        IScriptTaskBuilder taskHelp(String helpText);

        /**
         * Create a new {@link IScriptTaskUserDefinedArgument}, with the name argument name. The argument does not have a default value, so it is an required argument. To create
         * an optional argument use {@link #newUserDefinedArgument(String, Class, Object, String)}.
         *
         * <p>
         * See {@link #newUserDefinedArgument(String, Class, Object, String)} for usage details.
         * </p>
         *
         * @param <T> the generic type of the argument value type
         * @param argumentName the argument name
         * @param valueType the value type of the argument
         * @param help the help text display to the user in the script task help
         * @return this builder
         * @see IScriptTaskUserDefinedArgument
         */
        @PublishedMethod
        <T> IScriptTaskUserDefinedArgument<T> newUserDefinedArgument(String argumentName, Class<T> valueType, String help);

        /**
         * Create a new {@link IScriptTaskUserDefinedArgument}, with the name argument name. The argument does not have a default value, so it is an required argument. To create
         * an optional argument use {@link #newUserDefinedArgument(String, Class, Object, String, Consumer)}.
         *
         * <p>
         * See {@link #newUserDefinedArgument(String, Class, Object, String)} for usage details.
         * </p>
         *
         * <p>
         * The validator is called when checking if the value is correct. This will also be evaluated for user input.
         * </p>
         *
         * @param <T> the generic type of the argument value type
         * @param argumentName the argument name
         * @param valueType the value type of the argument
         * @param validator the validator has to throw an exception to indicate a wrong value.
         * @param help the help text display to the user in the script task help
         * @return this builder
         * @see IScriptTaskUserDefinedArgument
         */
        @PublishedMethod
        <T> IScriptTaskUserDefinedArgument<T> newUserDefinedArgument(String argumentName, Class<T> valueType, String help, Consumer<T> validator);

        /**
         * Create a new {@link IScriptTaskUserDefinedArgument}, with the name argument name. The argument has a default value, so it is an optional argument. To create an
         * required argument use {@link #newUserDefinedArgument(String, Class, String, Consumer)}.
         *
         * <p>
         * See {@link #newUserDefinedArgument(String, Class, Object, String)} for usage details.
         * </p>
         *
         * <p>
         * The validator is called when checking if the value is correct. This will also be evaluated for user input.
         * </p>
         *
         * <div class="extdoc" id="userDefinedArgumentValidator">You could also specify a validator for the argument to check for special conditions, like the file must exist.
         * This is helpful to provide a quick feedback to the user, if the task would be executable. Simply add the validator at the end of the
         * <code>newUserDefinedArgument()</code> call. The validator code is called when the input is checked.
         *
         * There are also default validators available, like:
         * <ul>
         * <li>Constraints.IS_EXISTING_FOLDER</li>
         * <li>Constraints.IS_EXISTING_FILE</li>
         * <li>Constraints.IS_VALID_AUTOSAR_SHORT_NAME</li>
         * </ul>
         *
         * Please see chapter <!--Ref:sec:Constraints--> for more available validators.
         *
         * </div>
         *
         *
         *
         * @param <T> the generic type of the argument value type
         * @param argumentName the argument name
         * @param valueType the value type of the argument
         * @param defaultValue the default value of the argument, if it is not set by the user.
         * @param validator the validator has to throw an exception to indicate a wrong value.
         * @param help the help text display to the user in the script task help
         * @return this builder
         * @see IScriptTaskUserDefinedArgument
         */
        @PublishedMethod
        <T> IScriptTaskUserDefinedArgument<T> newUserDefinedArgument(String argumentName, Class<T> valueType, @Nullable T defaultValue,
                String help, Consumer<T> validator);

        /**
         * Create a new {@link IScriptTaskUserDefinedArgument}, with the name argument name. The argument has a default value, so it is an optional argument. To create an
         * required argument use {@link #newUserDefinedArgument(String, Class, String)}.
         *
         * <div class="extdoc" id="userDefinedArgument"> A script task can create {@link IScriptTaskUserDefinedArgument}, which can be set by the user (e.g. from the
         * commandline) to pass user defined arguments to the script task execution. An argument can be optional or required. The arguments are type safe and checked before the
         * task is executed.
         *
         * <p>
         * Possible valueTypes are:
         * <ul>
         * <li><code>String</code></li>
         * <li><code>Boolean</code></li>
         * <li><code>Void</code>: For parameter where only the existence is relevant.</li>
         * <li><code>File</code>: The existence of the file is not checked by default. See argument validators.</li>
         * <li><code>Path</code>: Same as <code>File</code></li>
         * <li><code>Integer</code></li>
         * <li><code>Long</code></li>
         * <li><code>Double</code></li>
         * </ul>
         *
         * <p>
         * The help text is automatically expanded with the help for user defined script task arguments.
         * </p>
         *
         * </div>
         *
         * @param <T> the generic type of the argument value type
         * @param argumentName the argument name
         * @param valueType the value type of the argument
         * @param defaultValue the default value of the argument, if it is not set by the user.
         * @param help the help text display to the user in the script task help
         * @return this builder
         * @see IScriptTaskUserDefinedArgument
         */
        @PublishedMethod
        <T> IScriptTaskUserDefinedArgument<T> newUserDefinedArgument(String argumentName, Class<T> valueType, @Nullable T defaultValue, String help);

        /**
         * Gets the session data of the task which is currently under construction. See {@link IScriptExecutionContext#getSessionData()} for details.
         *
         * @return the session data of the script task.
         */
        @PublishedMethod
        IScriptTaskUserData getSessionData();
    }

    /**
     * The {@link IProjectScriptTaskBuilder} provides the methods callable during creation of an {@link IScriptTask} with {@link IScriptTaskType} is bound to a project.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IProjectScriptTaskBuilder extends IScriptTaskBuilder {

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        IProjectScriptTaskBuilder isExecutableIf(
                @DelegatesTo(value = IScriptExecutionContextWithNotExecutableReasons.class, strategy = Closure.DELEGATE_FIRST) Closure<?> isExecutable);

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        IProjectScriptTaskBuilder isExecutableIf(IExecutableTaskEvaluator isExecutable);

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        IProjectScriptTaskBuilder taskDescription(String description);

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        IProjectScriptTaskBuilder taskHelp(String helpText);

        /**
         * Sets the taskCode {@link Closure}, which is called when the {@link IScriptTask} is executed.
         *
         * <p>
         * The task code gets a delegate set before the execution call of type {@link IProjectScriptExecutionContext}.
         * </p>
         *
         * <p>
         * The passed arguments to the closure are defined by the {@link IScriptTaskType} of the {@link IScriptTask}. So the arguments can differ for eacj
         * {@link IScriptTaskType}.
         * </p>
         *
         * <p>
         * This method call is required, because every {@link IScriptTask} needs a code block.
         * </p>
         *
         * @param taskCode the task code
         * @return this builder
         * @see IApplicationScriptExecutionContext
         */
        @PublishedMethod
        IProjectScriptTaskBuilder code(@DelegatesTo(value = IProjectScriptExecutionContext.class, strategy = Closure.DELEGATE_FIRST) Closure<?> taskCode);

        /**
         * Sets the {@link IScriptTaskCode}, which is called when the {@link IScriptTask} is executed.
         *
         * <p>
         * See {@link #code(Closure)} for usage details.
         * </p>
         *
         * <p>
         * This method is mainly for Java clients.
         * </p>
         *
         * <p>
         * This method call is required, because every {@link IScriptTask} needs a code block.
         * </p>
         *
         * @param taskCode the task code
         * @return this builder
         * @see IProjectScriptExecutionContext
         */
        @PublishedMethod
        IProjectScriptTaskBuilder code(IScriptTaskCode<IProjectScriptExecutionContext> taskCode);

    }

    /**
     * The {@link IProjectScriptTaskBuilder} provides the methods callable during creation of an {@link IScriptTask} with {@link IScriptTaskType} is an application type.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IApplicationScriptTaskBuilder extends IScriptTaskBuilder {

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        IApplicationScriptTaskBuilder isExecutableIf(
                @DelegatesTo(value = IScriptExecutionContextWithNotExecutableReasons.class, strategy = Closure.DELEGATE_FIRST) Closure<?> isExecutable);

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        IApplicationScriptTaskBuilder isExecutableIf(IExecutableTaskEvaluator isExecutable);

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        IApplicationScriptTaskBuilder taskDescription(String description);

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        IApplicationScriptTaskBuilder taskHelp(String helpText);

        /**
         * Sets the taskCode {@link Closure}, which is called when the {@link IScriptTask} is executed.
         *
         * <p>
         * The task code gets a delegate set before the execution call of type {@link IApplicationScriptExecutionContext}.
         * </p>
         *
         * <p>
         * See {@link IProjectScriptTaskBuilder#code(Closure)} for usage details.
         * </p>
         *
         * <p>
         * This method call is required, because every {@link IScriptTask} needs a code block.
         * </p>
         *
         * @param taskCode the task code
         * @return this builder
         * @see IApplicationScriptExecutionContext
         */
        @PublishedMethod
        IApplicationScriptTaskBuilder code(@DelegatesTo(value = IApplicationScriptExecutionContext.class, strategy = Closure.DELEGATE_FIRST) Closure<?> taskCode);

        /**
         * Sets the {@link IScriptTaskCode}, which is called when the {@link IScriptTask} is executed.
         *
         * <p>
         * See {@link #code(Closure)} for usage details.
         * </p>
         *
         * <p>
         * This method is mainly for Java clients.
         * </p>
         *
         * <p>
         * This method call is required, because every {@link IScriptTask} needs a code block.
         * </p>
         *
         * @param taskCode the task code
         * @return this builder
         * @see IApplicationScriptExecutionContext
         */
        @PublishedMethod
        IApplicationScriptTaskBuilder code(IScriptTaskCode<IApplicationScriptExecutionContext> taskCode);

    }
}
