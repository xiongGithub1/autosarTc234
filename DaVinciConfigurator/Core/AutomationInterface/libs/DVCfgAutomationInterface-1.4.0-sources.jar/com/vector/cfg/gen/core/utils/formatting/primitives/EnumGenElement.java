package com.vector.cfg.gen.core.utils.formatting.primitives;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIEnumParameter;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractEnumeration;
import com.vector.cfg.gen.core.bswmdmodel.param.GEnumeration;
import com.vector.cfg.gen.core.bswmdmodel.untyped.GUntypedEnumeration;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractPrimitiveElement;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The format element for Java Enum objects
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class EnumGenElement extends AbstractPrimitiveElement<EnumGenElement> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(EnumGenElement.class);

    @SuppressWarnings("rawtypes")
    private final Enum enumObj;

    /*
     * This field is used, when we have no eral enum instance only the name.
     */
    private final String enumName;

    private boolean formatTypeWasSet = false;

    private EEnumFormatType formatType;

    private GAbstractEnumeration<?> bswmdModelObj;

    /**
     * Constructor for IntGenElement.
     *
     * @param intObj
     */
    <E extends Enum<E>> EnumGenElement(Enum<E> enumObj) {
        if (enumObj == null) {
            throw new IllegalArgumentException("enumObj is null");
        }
        this.enumObj = enumObj;
        this.enumName = enumObj.name();

        formatType = EEnumFormatType.AS_LITERAL;
    }

    /**
     * Constructor for StringGenElement.
     *
     * @param gString
     */
    EnumGenElement(GIEnumParameter gEnum) {
        if (gEnum == null) {
            throw new IllegalArgumentException("gEnum is null");
        }
        if (!(gEnum instanceof GAbstractEnumeration<?>)) {
            throw new IllegalArgumentException("Illegal Eneration bswmd model type!");
        }
        bswmdModelObj = (GAbstractEnumeration<?>) gEnum;

        if (!gEnum.existsMDF()) {
            reportBswmdParamterNotExistsError(gEnum);

            this.enumObj = EInvalid.INVALID_ENUM_VALUE;
            this.enumName = null;

        } else {
            if (gEnum instanceof GEnumeration<?>) {
                final GEnumeration<?> gEnumTyped = (GEnumeration<?>) gEnum;
                final Enum<?> value = gEnumTyped.getValue();
                this.enumObj = value;
                this.enumName = value.name();
            } else if (gEnum instanceof GUntypedEnumeration) {
                final GUntypedEnumeration gEnumUntyped = (GUntypedEnumeration) gEnum;
                final String value = gEnumUntyped.getValueMdf();

                this.enumObj = EInvalid.INVALID_ENUM_VALUE;
                this.enumName = value;
            } else {
                throw new IllegalArgumentException("Illegal Eneration bswmd model type!");
            }
        }

        formatType = EEnumFormatType.AS_LITERAL;
    }

    /**
     * Selects the Literal format for the Enum value. This means the LiteralValue is generated.
     *
     * @return A StringGenElement
     */
    @PublishedMethod
    public StringGenElement asLiteral() {
        ensureObjectIsMutable();
        if (formatTypeWasSet) {
            throw new IllegalStateException("The enum format type was already set! It is not allowed to change the format.");
        }

        if (enumObj == EInvalid.INVALID_ENUM_VALUE && enumName == null) {
            /*
             * Propagate the Error message that the parameter does not exist
             */
            if (bswmdModelObj != null) {
                bswmdModelObj.getValueMdf();
            } else {
                throw new IllegalStateException("Internal EnumGenElement state failure. A enum with value EInvalid.INVALID_ENUM_VALUE can not be converted to an integer value.");
            }

        }

        formatType = EEnumFormatType.AS_LITERAL;
        formatTypeWasSet = true;

        final StringGenElement genElement = new StringGenElement(enumName);

        copySettingToElement(genElement);
        return genElement;
    }

    /**
     * Formats the {@link EnumGenElement} as number. Note: the returned element is a {@link IntGenElement}.
     *
     * @return the new {@link IntGenElement}.
     */
    @PublishedMethod
    public IntGenElement asNumber() {
        ensureObjectIsMutable();
        if (formatTypeWasSet) {
            throw new IllegalStateException("The enum format type was already set! It is not allowed to change the format.");
        }

        if (enumObj == EInvalid.INVALID_ENUM_VALUE) {
            /*
             * Propagate the Error message that the parameter does not exist
             */
            if (bswmdModelObj != null) {

                bswmdModelObj.getValue();
            } else {
                throw new IllegalStateException("Internal EnumGenElement state failure. A enum with value EInvalid.INVALID_ENUM_VALUE can not be converted to an integer value.");
            }

        }

        formatType = EEnumFormatType.AS_NUMBER;
        formatTypeWasSet = true;

        final IntGenElement genElement = new IntGenElement(enumObj.ordinal());

        copySettingToElement(genElement);
        return genElement;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void generatePrimitiveInternal(StringBuilder builder, IGenFormatter formatter, int indent) {

        //Beware this method should not be called when asLiteral or asNumber were called before, because a new GenElement was created for the formatting
        if (formatTypeWasSet) {
            throw new IllegalStateException(
                    "It is not allowed to generate a EnumGenElement on which the methods asNumber or asLiteral were called, because these methods have created a new format element.");
        }

        formatInternal(builder, enumObj, formatType);

    }

    /**
     * Formats the passed enumObj by the passed {@link EEnumFormatType}.
     *
     * @param <E> the element type
     * @param enumObj the enum obj
     * @param formatType the format type
     * @return the string
     */
    @PublishedMethod
    public static <E extends Enum<E>> String format(Enum<E> enumObj, EEnumFormatType formatType) {
        final StringBuilder builder = new StringBuilder();

        formatInternal(builder, enumObj, formatType);

        return builder.toString();
    }

    @SuppressWarnings("rawtypes")
    private static void formatInternal(StringBuilder builder, Enum enumObj, EEnumFormatType formatType) {

        if (formatType.equals(EEnumFormatType.AS_NUMBER)) {
            builder.append(enumObj.ordinal());
        } else {
            builder.append(enumObj.name());
        }
    }

    /**
     * The format options for an {@link EnumGenElement}.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    public enum EEnumFormatType {
        AS_LITERAL,
        AS_NUMBER,;
    }

    /**
     * The Enum EInvalid.
     */
    public enum EInvalid {
        INVALID_ENUM_VALUE
    }

}
