package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.gen.core.bswmdmodel.GICList;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
//CHECKSTYLE:OFF Class Naming problem
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface GIInternalCList<VALUE extends GIModelObject> extends GICList<VALUE>, GIInternalList<VALUE> {
    //CHECKSTYLE:ON Class Naming problem

}
