/**
 * Generation exception of the AutomationInterface scripting API for client side scripts. This package contains exceptions raised by the generation API.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.genusage.groovy.exceptions;