package com.vector.cfg.consistency.contribution.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.consistency.ui.IValidationResultUI;
import com.vector.cfg.model.exceptions.ModelException;

/**
 * Interface for a custom exception handler for the {@link IErrorHandlingContext} class. You can add specialized {@link IValidationResultUI}s in an error
 * condition.
 *
 * <p>
 * This interface should be implemented by the client of {@link IErrorHandlingContext}
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface ICustomExceptionHandler {

    /**
     * The method implementation should insert special results in certain cases, to give the CfgUser more information about the current situation.
     *
     * <p>
     * The method is called, when the {@link ErrorHandlingContext} has caught a {@link ModelException}
     * </p>
     *
     * @param resultSink The current resultSink
     * @param ex The caught exception
     */
    @PublishedMethod
    void onModelException(IValidationResultSink resultSink, ModelException ex);

    /**
     * The method implementation should insert special results in certain cases, to give the CfgUser more information about the current situation.
     *
     * <p>
     * The method is called, when the {@link ErrorHandlingContext} has caught a {@link GeneratorPackageException}, a {@link ModelException} or any
     * {@link Exception}.
     * </p>
     *
     * <p>
     * The method is called after the calls to {@link #onGeneratorPackageException(IGeneratorResultSink, GeneratorPackageException)} or
     * {@link #onModelException(IGeneratorResultSink, ModelException)}.
     * </p>
     * <p>
     * <b>Attention:</b>Caught {@link Exception}s are rethrown as {@link RuntimeException}. Caught {@link RuntimeException}s are rethrown. To prevent this, you
     * can use {@link #suppressReThrowOfUnhandledExceptions()}
     * </p>
     *
     *
     * @param resultSink The current resultSink
     * @param ex The caught exception
     */
    @PublishedMethod
    void onException(IValidationResultSink resultSink, Exception ex);

    /**
     * The method implementation should insert special results in certain cases, to give the CfgUser more information about the current situation.
     *
     * <p>
     * The method is called, when the {@link ErrorHandlingContext} has caught an unhandled {@link Exception}.
     * </p>
     *
     * <p>
     * The method is not called on processed {@link GeneratorPackageException} or {@link ModelException}s. But the method is call for unhandled
     * {@link ModelException}s.
     * </p>
     * <p>
     * <b>Attention:</b>Caught {@link Exception}s are rethrown as {@link RuntimeException}. Caught {@link RuntimeException}s are rethrown. To prevent this, you
     * can use {@link #suppressReThrowOfUnhandledExceptions()}
     * </p>
     *
     *
     * @param resultSink The current resultSink
     * @param ex The caught exception
     */
    @PublishedMethod
    void onUnhandledException(IValidationResultSink resultSink, Exception ex);

    /**
     * Suppress any rethrowing of unhandled exceptions.
     *
     * @return true, if successful
     */
    @PublishedMethod
    boolean suppressReThrowOfUnhandledExceptions();
}
