package com.vector.cfg.consistency.contribution.helper.solvingactions.generic;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * This class is an {@link ISolvingAction} that sets a string or enum parameter when executed.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class SASetTextual extends SASetNumTextRef<MITextualValue> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SASetTextual.class);

    private final String targetValue;

    /**
     * Constructor for SASetTextual.
     *
     * @param textual the parameter to be adjusted
     * @param targetValue the target value
     */
    @PublishedMethod
    public SASetTextual(MITextualValue textual, String targetValue) {
        super(textual, MixedText.newBuilder().append(targetValue).flushResult());
        this.targetValue = targetValue;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void run() {
        getParam().setValue(targetValue);
    }
}
