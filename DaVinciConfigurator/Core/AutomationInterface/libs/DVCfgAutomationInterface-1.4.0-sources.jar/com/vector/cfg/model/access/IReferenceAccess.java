package com.vector.cfg.model.access;

import java.util.Collection;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.exceptions.MultipleVariantObjectsException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIARRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDefARRef;

/**
 * <div class="extdoc" id="Common">
 * <h2>IReferenceAccess</h2> <!--LaTeX:\label{sec:IReferenceAccess}-->
 *
 * The {@link IReferenceAccess} is a basic model service which provides methods to simplify reference handling.
 *
 * <ul>
 * <li>{@link #getRefTarget(MIARRef)}: Returns the target object, an AUTOSAR reference points to. This method works for all reference types and therefore returns an object of
 * type MIReferrable. This is the base type all reference target types must implement
 * <li>{@link #getReferenceTarget(MIReferenceValue)}: Returns the target object of a reference-value (ECUC parameter of type MIReferenceValue)
 * <li>{@link #sortReferences(Collection)}: Sorts a collection of AUTOSAR references to guarantee deterministic order for example during code generation (the sort criteria are
 * described in the JavaDoc documentation in the code).
 * <li>{@link #getAllReferencesPointingTo(MIReferrable)}: This is the reverse operation of {@link #getRefTarget(MIARRef)}
 * <li>{@link #getReferenceParametersPointingTo(MIReferrable)}: This is the reverse operation of {@link #getReferenceTarget(MIReferenceValue)}
 * </ul>
 *
 * </div>
 *
 * <div class="extdoc" id="AutosarReferences" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation"> All AUTOSAR reference objects in the MDF model have the base
 * interface {@link MIARRef}.
 *
 * Figure <!--LaTeX:\vref{fig:AutosarContainerDefRef}--> shows this type hierarchy for the definition reference of an ECUC container. <br/>
 * <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOgAAAFwCAYAAACy6zfiAAAABmJLR0QA/wD/AP+gvaeTAAAerUlEQVR4nO3dfWwU550H8K9JigFj47XXBvNi/IaBYDu8J4EkpJHapEoa0ghCSFRFinqt7ooq5VRd779rqrs/7v7oH3dKc0VVVfUqAklUJWoq9eUfCCGEd7B587sxNgZ7/W5jTFPm/pid2Xndnd0de3+z/n6E5dmZZ2cfr/3leeaZ2XlyFEVRQEQSHZiX6RoQkTsGlEgwBpRIMAaUSDAGlEiwhzNdAb80Njaiubk509WgDJs3bx527dqFcDic6ar4IidbTrPk5ORkugokxPe//3388pe/zHQ1/HAga1pQAPja1x7Gb3/1P9FHiumb/bHxofX/KEX751BYsa5wKaKYVioOZW37sTzP9nLWbZbXMO/SXE/XV7fVzekHd3p9h3KKYZvL8+wPFUt1Ffeiptd0/n3+w9vvYGJiwl71gMqqgO55+UXsefmF6KPYL1CxPHb8Q7f+0VifZ3iuYilnLOAtoIrlW7yAOj/PXjfLGqeAOoUgQUDd6+b8npmeY3me63ttqq75Z4oXUMef6W1kFQ4SEQnGgBIJxoASCZZVx6A0+4qrHteXB9tPZrAm2YkB9dmikrX68t3+66ZteUvX68uTd67qy4uXbTCVm+i7bNtv/vJ6fXm8t9G0rWDFo451Gb15wfS4sHyzY7nhG2cd1yeihXOw40vEH/2lVLGLK8DE7SuxZYdwejXWcxGj0S8AWLJqk2O5ke5z+hcAhFZvTfk1aWYxoDPgbr96RdOi0nX6uryl6zF551pK+9Naz/FbasuZv6IhzRomFqrYhlDFNhRVbFe/KrebthdXxrq2xm4u+YsBJZtQxTYAwHDXGQx1ncZQ12kAQFHlY3qZwc4vY8sdX4JmBo9BZ8jd/utYVLpOb0XTbz2bACgYv9WI/OUNKFjRgLHeS6ayBSs3mh5bj0E1heVbTI9TPQalmceABoRxkMjNWM9FPaRu4QTUY1AtpCM3zrleCKi1pJQ5DOgM0lrRu3euJ7gWNzGtBQWA/OXux6CjPRexZOVGLFm1yVNIC1dvcW1Bh7vOuF7qR7ODx6CC5ZfVAdDCGaOdZnE9vZJgFFeT7Ciu8RiUZgcDOsOs50KdGM+DLo6GMl1a65kwpDfsIR3uOqOus4ziDnWe8qVu5B27uD67O9ActyeoDhaZC+jnQS3dyPG+y5ZPpcSM9TbqZcd6LzmWi3Vx1W0j3edNjzVOXVwtpPG6uBy9nXlsQYkEY0CJBGNAiQRjQIkEY0CJBGNAiQRjQIkEY0CJBGNAiQRjQIkEY0CJBMuqa3Hf//BjvP/hx5muBpFvsiqg5StXYPvWjbb1LjOoJFzl6dnuD+KwTv3goWzCl7FNBhHned4/16l4q6R7Adv0MUl8pjTBvF5Os7j84U/HvO8/ALIqoDuf2Ibf/uq/o484N4tzvTzULcBzsyz707PIJjwGJRKMASUSjAElEowBJRKMASUSjAEVxq+bhhktWbUZhaucJ04i2RjQNC0sqTU9Ns5uZmSc2Ww2qffHPY+Rm+ddZzez0uZlMd7VT+P11pvh6h0p1ZfMsuo8KJnFbl4du6tfYflm/X64TkKrt+l39ANi5zSLKpK77Wak/YvUKk0mDCiA3FCVbd30YLu+vKC4xrRtKtIKAFgYVltPrRWdGmj29Hp5Sx8xPTZOP6hZXFan3nbTIH95gz7DWYFlhrOx6M2qUxFavTXh/CxDnaf1Gc60VnSw40sUVz0e/f6Eui46iW+4egci7V8gXLMDkbYTCNfs1Pc10Pq5vlyy5inba/W3fJbyz5Jt5nxAc0OVmB7uMF3AklsUC+yC4hrcG2xTH0QvXVkQXoOpSCumIi1YGK7F1EALtAJ3B5qxqGSt6YbVi5auM02epE/eG33NvGWPOIbUTf6KBtN9cQH1LvPGkLpN/eClFXUz1HkKRZWPYajzlOlKIjWkJ12v4gvX7ESk7YR+JVFJzZMYaP0cJWuexEDrcXVt9LmltfbAzmVzPqBkvnH18I0zCK22T5o01Hna9fn6DNsuIm0n0qrfXMaAemDt4iZyt78Zi0rXuk6eZO3ipsLaxfWTH8eg5A8G1ANrFzedOb7UmbbtXdxkWbu4iT75QcHE0ywWxuNPNwvDaxKW0VvPBJMneQ1novlBrZP3JsM4cZJT93a28PjTbs63oNPDncgNVcYeD3WYQnpvsM11FBcApgZakhrFnbxzzXROdPL2VceQTvRdNl20MH6rKTbbdm8j8hOM4o7evOA4UJRogCj+MaiiDxQB6U+epA0UafpbjjOkFnM+oABso7hWibq4xlFcI7fW09rFNY7gThhOrVhnN9NOsQD+dnGtp1icjkGNL2UcxXULqXYeNNL2Bazvi/E0i3UUl8zYxc1iWiuqUVvP83GeQdKwBYX9QoXpofak7swhmTGkEsNpvVCBFymYMaBw6uJmSTqjRm+et92FRQp7F1dgJTOIXVwiwRhQIsEYUCLBGFAiwRhQIsEYUCLBsuo0y4mTZ7D/zX+0rU8weYPrKk/PTun0jPXO8h7KJnwZDxMrpHAqI2hTP2SbrApod08vunt6M10NIt9kVUD3732Zc7NYHtvr5aFups1udXN+z0zPsTzP9b02Vdf8M9laSUM5p59p2XrOzUJEs4QBJRKMASUSjAElEowBJRKMASUSjAElEowBJRKMASUSjAElEowBJRKMASUSjAElEowBJRKMASUSjAElEowBJRKMASUSjAElEowBJRKMASUSjAElEowBJRKMASUSjAElEiyr7iz/0cef4qUXn4s+ss4p4jzHiPN8IYr9Buh6MYc7vTsWiXf3dsdnudxZ3qGcU71tP4LDneVdXjreneUd66nt0eFtc341xzfd9MDxzvJOjxL8PrNNVgX0b3/7ynHyJJpbFi9enOkq+CZrAnrp0iU0NzdnuhoZMz09je9+97soLi7Ge++9l+nqZMy8efOwa9euTFfDNzmKkmCONwqEI0eO4LXXXsOCBQvQ39+P/Pz8TFeJ0neAg0RZ4tChQ/jxj3+MsrIyfPLJJ5muDvmELWgWGBoaQllZGU6dOoUjR46gqakJn376aaarRek7kDXHoHPZ73//e1RVVWHjxo146KGHsGXLFkQiEYTD4UxXjdLELm4WeP/997F//34AQH19PdatW4cPP/www7UiPzCgAXfr1i0cPXoUr7/+ur5u//79OHToUAZrRX5hQAPu8OHD2Lp1K2pqavR1+/btw8mTJ3Hz5s0M1oz8wIAG3OHDh/Haa6+Z1lVVVWH79u04fPhwhmpFfmFAA6ytrQ3nzp3Dvn37bNtef/11dnOzAAMaYIcOHcIzzzyD5cuX27a9+uqraGpqwtWrVzNQM/ILAxpghw4dMg0OGZWWluLZZ5/FkSNHZrlW5CcGNKAuXLiAzs5OvPLKK65l2M0NPgY0oN5//308//zzCIVCrmVeeeUV9PT04PTp07NYM/ITAxpADx48wOHDh127t5qCggK8+OKLbEUDjAENoOPHj2NkZATf/va3E5bdt28fPvjgAzx48GAWakZ+47W4AXT27FmMj48jLy/P83NaWlqwbt26GawVzQR+miWA7t27h1u3btnW79u3Dy+99BLeeOMN0/p58+ahoqJilmpHPuKnWYJowYIFqKqqclwfDocdt1Ew8RiUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEiwHEVRFOvKBw8e4O2330ZfX18m6kQp6u7uRkFBAQoLCzNdFUrC7t278cYbbzhtOgDFweXLlxUA/OIXv2bhq6GhwSmGiqIoP3wYDh48eAAA+Mk//xD//m8/cSihmL7FFhXHYtb1sdWW8g77d3mmYZXistX2ZOeautQxtvvEdYytcapfnH0nqKP9Zbzt3/SOpPseKHpN3etp+7U7/R3IfA/sT4+/f/tW5/fA9C4o5vVGX9/9vTh/YzwGJRKNASUSjAElEowBJRLMcZCIZl/+8noAwPitpgzXJDWhim368lDX6QzWxJuSNU8BAAZaj2e4JvGJDWhuUbW+fG+w3bRtQXFNbFukVV0XXmMqMxVp0ZcXltTa9n93oNmXelotXrYBADBx+8qM7N8PS1Ztdlw/0n0upf1p4RzuOgPAPIpbVLFdXx7qPGV6XlHlY477G+z40vS4uPoJx3KR9i+SryyAkjVPApAfTkBwQJN1L9Kqh3Qq0gptOFsL59SAFlht/doZC2kqMtFyjtw8ry4oQGH5ZhSWb0k5pOkwBrK46nEUVz2OwY6TtnKR9pPQfn/h6h0IV+9IOaRBITqg04PtyC2uxoLiar0VXVBcg3uDbaZW1A+LStfZ1t3tv64v5y1dDwCYvHNNXwaAydtX9WWt9TQuT/TFWtLFZXWm/Y/3xUJp7OLmL2+ILjcif0WDXmas95Lp+QUrHrXVeaznor68ZOUmAMDozQtYsiq27GSk+7xjSAtXb7GVHb5xVl8OrY51bUMV2/RWFIi1nkOdp1FUuR1FlY/ZWlG/hWt22tYNtH6uL2utp7r8lPhWdM4OEhlbz0Wla9V1/df1L3W9PbR5S9dj8s41TN5Rg5m37BF9m7FbO3H7iunx4rI6TPRd1r8AIL+sPm4d85c3YLy3EeO9jQDMgdSWx3ouYaznoh7MgpUbbfvRwpmswnI1nCM3zmI4+gUAodVb9TLDN2KBNIYzE7RwRtpOYCD6BZhDaQyr9HACwltQQD3+XBBtRdXHbRmtz+Sdayk9TwtlMsZvNbpdgJMUt1ZzJumtZ9dpQFGPP4sqH3NsRYurHjc9Vru89h88bDkWzfbuLRCAgGYLa/fWLwUr7d1cvxUaWsxkGQeJ3Ax2fKmH1DpAZBRpP6mHNF44nbq5QRWIgGqtqJ+t56JZHCTSwmlsRf0K7FjPJXi4YjktIzfOprxPrQUFFNdRWyAWUnWAKF5Iv0g4QBRpO+HhWtxgmLPHoNnK6RjUi8Jy9dSLl1HcUIIW1dS9NdC6tolOr1i7vFZaMMPVOxLWFTAfgwZNIFpQQDsX6v5fofE86MLwGv086NRACxaW1NrOhRpbz7v9zVhUutY2KHS3/3rcTxo4mbh9BYuXbTCN4k70Xcbisjpfu7ljvZdQsOJRWxd3rOei5waj0HI+1BrOke5zKCzfYuviGkdx/RZrSZ9wPNWiMbWkbWpgI20nEK7ZaeviGgeGgsbxA9tNTU1oaGjgx83Aj5vx42bmAjPxcbOHc/PQ2NjoVMkD7OISCcaAEgnGgBIJxoASCcaAEgnGgBIJxoASCcaAEgnGgBIJxoASCRb3WtzrLW346OM/Omxxv7wp3kP76mQv9XMqmmAfibamfKmfx9eMe5mb2ya3C8rc9h+nPl4u9Uuwi2Qv9YuzI4e1Hn7JiS71S1SJdC/1i7srD1mIs8ux8UkU5ea5bo8b0E8+/TM++fTP8YoQUZqKwqWu2+IGdPeLz+G1vS87bGEL6vk12YKay9rWzu0W9Kf/9b9xXy9uQNfV1mDPyy84bLFXyvHNc/mhY6uTDajTH6hb3D3+caYcUKf3INmAxq+j/WW87d/0jqT7HqQQUH6aRV3hvEtzwZ+/939OldNxkIhIMAaUSDAGlEgwBpRIMAaUSLDA3DQsXcabhk0JmpPFC236B+vUD5R5S9c+oy/fuX7U9/2LC2huURWmh2KzmWl3lDdK9v64C0tqTZMnLSxZ61rWOB/LbMlfXu86eVL+CnX6BwVAwYqGhCHVbrs5apijRRObn+W8aYazke7zpnLalA/6dh/v4pfK/CzF1U9gsN39Dn+p0KYfNOpvSW4qiKVrd+FO81H1QTKny5MgLqBOYtMPqu+CNoFSqqYGmvX3c1HJWtztb8aMvcNp0OZm0Wi32vSjJdVCOnLzvOlHt81wpqgTKM3krTYT8TucGm1uFu00Z2ntU+hv+WxGXitVMxLQ+YUVtnX3hzv15dxQpWnb9FCHur6oKvpdbTWnLfOCxuM2P6jWtY1NQ+ite2u9R642J4s2eVLeUnXSJG12M+MkShrr5EmmbdoEStFZzdKZwLdg5UbTrGajPRexZOVGjPbE5mRZsmqTaZYzJ27TD1rvLG+9cbVx0qRQxTYMdZ22zAuq3sBau2G19l1rSZ3nZokp1qd7OGm6WbX1zvK2++EaJk8aaP3cMC+o831y+1uO20JaWvu0qcyd5mMA1NZT/f6Mun4GurfADAR0fmEF7o90qQ+iv9X5oYrY9lAlprWwRq/SUbu1HZge6jB3cT02agvCa3Av0moqvjC8BlMDLfqNq63zgyaidXW1K4m0YMaWr+q7y1v2CCZvXzVdQWOaijA6s5nR4rI6jPc1RacbtHdx85c3OE6e5GcrmorQ6q2G1lSJrrNPO2i8q3xRxXYMdZ7SJ1CydnFtgXSZHzRc/YQplMbpH8I1OxGJBlKrWUnNTgy0qWHUQpqM0tqn1bAariQqXbsLd5qP4U7zMXZxNdbjUBkznMnpEo85HG/qrWi01ZzNGc6sUz74xTiBb7KCenf5jATU2sVNJDZ5r/sEStYubrqc5gZNx0zNbpYNEs3F4tVMzGpm7eLOtowE1NrF9UqbWdsppNYurvtF0oktKl3n2MVNh9P8oG6XoPtltOcClqyc3dYzWcWV9tnMUg2stYtrXUqFtYs72/2mGb9QwXj86UYbHPJCC2kiC8O1Cct4lWw4jcefrmV8bFFTndHMSpssySqd+UGT5VdrCqjHoMnwMoqrDQ7NFt9b0PsjXaZR3PvDXaaQ3h/uxHyXUVxtWQus2yiutSW9F2l1HsVN8b+7u/3XTV1cddTWPaSTt6+aRnG1Gc70x9HZzYwm+i7rLag2UKQtq98bbadZACQ9QOTWemrnQQtXbTadB3UKqXEUd/jG2bijuIloA0Xa8mDnlyiujIXSOJlvMrSZzYzUUVz3PwLruVD1PKhiePyZ6yjubJmV2c3mhypMp1nmwudBFy/boJ5mSeOzkMaAarW2BZSfBw3050E5u1mAjd9q1C/zA5JvPSn4ZuVCBWPrma2sFyoYL1JIx3hvI6/FncNmJKDWCxUknTOcKdYLFfykXYs7F95HMmMXl0gwBpRIMAaUSDAGlEgwBpRIMAaUSDLFQWNjowJ1TJ9f/OLXDH/V19c7xVBRFOWHCad+qHvE/f49RkoqW+M/Kf1XcSye9IvGfzXFtib5faRZxFoo9bfVn/fG+VK/5PeSTlEl3saUquLXb9e89tiJ+LeSSTh5kh/X4rr+AWXxtbjmYm6/qvh1tL+Mt/2b3pF03wNFr6l7PW2/dqe/A5nvgf3p8fdv3+r8HpjeBcW83ujru7/nVDkdj0GJBGNAiQRjQIkEY0CJBGNAiQRjQIkEY0CJBGNAiQRjQIkEY0CJBGNAiQRjQIkEY0CJBGNAiQRjQIkEY0CJBGNAiQRjQIkEY0CJBGNAiQRjQIkEY0CJBGNAiQRjQIkEY0CJBIt7Z/n//Pm7aO/o8rQjTv2Q+akfJu9O4eGHH8L8+fNTrAanfnDf/8xM/XCtpQP19fWu+3AMaHl5OebPn4/79+/jo4//mHTFiMi7zZs3u25zDOiSJUswPT09YxUifymKgm984xv4+9//jqtXr+JnP/sZfvCDH2S6WuSDuF1cCoaDBw+iqakJV65cwdGjR/HWW2/hW9/6FsrLyzNdNUpTjuI+fRcFQHd3N+rq6vDrX/8ae/bsAQDs3bsXIyMj+Mtf/oKcnJwM15DScIABDTCtaxsKhfDhhx/q6wcGBlBXV8eubvAdYBc3wIxdW6OSkhK8++677OpmAbagAeXUtbViVzfw2MUNIkVR8M1vfhOFhYWmrq1VJBLBhg0b2NUNLnZxg+jgwYNobGzE5cuX45YLh8NJd3WNLa0f/3fn5OT4sp+5ii1owJw+fRpPP/00fve737l2ba327NmDSCSCo0ePxi1nDZMf4WJA03KA1+IGzOjoKKanp7Ft2zbPz9m0aROOHTuGr776yrWMU5AURUn52DUnJ4fHvT5gCxpAr776KoaGhvDXv/41YQi8DCYB7i1dui0gW9C0sAUNol/84hdoamrCwYMH45ZTFAVvvfUWnnvuOc/dYZKFg0QB5HXwx+08KQUHu7gBtnfvXgwPDzt2db12bTXs4orELm6Qvffee45dXa1r+/zzz7NrG3Ds4gaYW1eXXdvswS5uFjBe0tfd3Y36+nrPXVsjL+dBva7zso0S4qV+2UD79Mo777yDjz76CEVFRfjggw9S2leiK4mSCa0V/9SSxkv9soH26ZW9e/cCUAObqkQhctrudR0ljwHNEnv27EFdXR2+853vIBwOZ7o65BOO4maRwsJClJWVZboa5CMGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSDAGlEgwBpRIMAaUSLAcRVGUTFciWaOjoygtLcX9+/czXRUKgDfffBO/+c1vMl2NVBx4ONM1SEV3d7cezj0vv+BYxv6/jpKoQMKNircHCSh68cTPcijh+iTF2z4V24KHWniucPxCinUxifdNSVxecXj0hz8dw/nz572/jjCBDKjmX97+J/zHT/81+kixfLP+NSiWh9ZftmLIjjXM1rWKpYhieQlDSZfXSb+OlnqmUUcoiuUnNj/XHFBrSfvrmH8V9jqatjn8R6c41tFUE8fnOv18X+/4HoKMx6BEgjGgRIIxoESCMaBEggV6kIgSW7JqEwBg9GYwRzJLa5/Wl/ubj2WwJpkx5wI6P1SpL08PdZi25RZX68v3Btv05QXhNaZyU5EWfXlhSa3tNe72X0+7nlb5y+sBAOO9jb7v20/FVU84ro+0f5H0vrRw9rd85uk0SzaacwFNxb1Iqx7SqUgrtD8ULZxTA82mv59FpWtnJKSpGL15Ibo0u3/cg+0n9VMp4eodCFfvQKTtxKzWIRvMyYBOD3ciN1SJ3KIqvRXNLarG9GC7qRX1S97S9bZ1k7evAgAWL9sAAJjou4LFZXX69vG+y/qy1noCQP6KBgDAmKElLVjxqGnfoz0X9WVrF7ewfDMAYKT7HArLt+jlhm+cNe0jVLHNVuehztMAgKLKx6KPT6G48nEAwGDHl7bymkj7F2pIa3aaQlpS86St7EDrcQBAae1T+rrS2qfR3/yZ6/6zGQeJZoCx9dTCOXnnWvRLDWbeskdMz1lctgETfZcxEQ1mvjGst5piy72NtnCO9V7CWM9FjEWDuWTlxoR1LCzfgpHucxjpPgcACK3eqm8LrVbDOdx1BsNdZzDUpQVzu2kfWlBTUVKzEwAw0Pq5/gUAJWvUYPa3HNfL9rfMzXACc7QFBdTjz9yiKuQWVUUft2f0EGei7wpSqcBY76WUXk8LZjqGOk85XElEfpqzAc0W1u6tn5y6uX4rWWPv5lLMnA6o1oqqx6H+NQOLStfNyiCRFs6x3kv6BawFHrq3Xg13nQEQ/1rcdGldW8ML2C9BnsN4DEqeWY9BvQpX7wAAT6O42jEoqeZ0CwrYz4U6MZ4HXRheo58HnRpowcKSWiwsWWsqb2w9J+9cQ97S9baR3MnbV2H9DEk847eakL+83jSKO9Z7CQUrHvW9mzt84wxCq7fZurjqKK63OhdXm8+HRtq/MDWNA20nUFKz09bFHWg9zhbUYM4F9P5wZ9w/sXuD7bD+Ed6LtAKmtbGlqYEWxP0oF9SQxpgHVSZuX7E9ZaLvsuPHzcZvNdo+ZaUPEjl93Az286Aj3edNjwFg5MZZ23uidW8BaxdXHRxyM9hx0v3jZhYDbZ/H/VztXB691bCLSyQYA0okGANKJBgDSiQYA0okGANKJBgDSiQYA0okGANKJBgDSiQYA0okGANKJFggZzdrampCQ0NDpqtBAVFfX4/GRtl3Q3QRzNnNNGtrq1H/yDrHbfb/dawTIsXbs/NG9w9eJPN/nHVyoSTr4fqkRJ8dsT7fe52DPLvZsRNnnYoGRqADuvuF5zi7mQ91zOrZzXZzdjMimiEMKJFgDCiRYAwokWAMKJFgDCiRYAwokWAMKJFgDCiRYAwokWAMKJFgDCiRYAwokWAMKJFgDCiRYAwokWAMKJFgDCiRYAwokWAMKJFgDCiRYAwokWAMKJFgDCiRYAwokWAMKJFgDCiRYIGc3ezKlSuoq6vLdDUoIBoaGnDp0qVMVyMVwZzdbP369fjRj36Evr6+TFeFAmD37t2ZrkLKAtmCEs0RB3gMSiQYA0okGANKJBgDSiQYA0ok2P8DZbX+NDK63TwAAAAASUVORK5CYII=" alt="The ECUC container definition reference" id="fig:AutosarContainerDefRef " data-latex-style
 * ="scale=0.7" />
 *
 * <p>
 * In ARXML, such a reference can be specified as:
 *
 * <pre>
 * &lt;DEFINITION-REF DEST="ECUC-PARAM-CONF-CONTAINER-DEF"&gt;
 *     /MIRCOSAR/Com/ComGeneral
 * &lt;/DEFINITION-REF&gt;
 * </pre>
 *
 * <pre>
 * <!--UML: ClassDiag AutosarContainerDefRef{
 * [MIARRef:{@link MIARRef}|getValue():String],
 * [MIContainerDefARRef:{@link MIContainerDefARRef}|getRefTarget():MIContainerDef],
 * [MIContainerDef:{@link MIContainerDef}],
 * [MIContainerDefARRef]-^[MIARRef],
 * [MIContainerDef]-"    0..1"<>[MIContainerDefARRef],
 * }
 * -->
 * </pre>
 *
 * <ul>
 * <li>{@link MIARRef#getValue()} returns the AUTOSAR path of the object, the reference points to (as specified in the ARXML file). In the example above
 * <code>"/MIRCOSAR/Com/ComGeneral"</code> would be this value</li>
 * <li>{@link MIContainerDefARRef#getRefTarget()} on the other hand returns the referenced MDF object if it exists. This method is located in a specific, typesafe (according to
 * the type it points to) reference interface which extends {@link MIARRef}. So, if an object with the AUTOSAR path <code>"/MIRCOSAR/Com/ComGeneral"</code> exists in the model,
 * this method will return it
 * </ul>
 *
 * </p>
 * </div>
 *
 * <p>
 * This ProjectService is threadsafe
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IReferenceAccess {

    /**
     * This method returns the target object of the specified reference. It returns <code>null</code> in the following cases:
     * <ul>
     * <li>No such target exists
     * <li>The specified reference is <code>null</code>
     * <li>The specified reference is removed or invisible
     * </ul>
     *
     * @param ref
     * @return
     * @throws MultipleVariantObjectsException if more than one reference target exists which can never happen in the following cases:
     * <ul>
     * <li>In non-variant projects
     * <li>If the client code is being executed in a predefined variant view
     * </ul>
     */
    @PublishedMethod
    MIReferrable getRefTarget(final MIARRef ref);

    /**
     * This method returns all target objects of the specified reference. It returns an empty collection in the following cases:
     * <ul>
     * <li>No such target exists
     * <li>The specified reference is <code>null</code>
     * <li>The specified reference is removed or invisible
     * </ul>
     * This method never returns <code>null</code>.
     *
     * @param ref
     * @return
     */
    @PublishedMethod
    Collection<MIReferrable> getRefTargets(final MIARRef ref);

    /**
     * This method returns the target object of the specified reference parameter. It returns <code>null</code> in the following cases:
     * <ul>
     * <li>No such target exists
     * <li>If the parameter is <code>null</code>
     * <li>If the parameter is removed or invisible
     * </ul>
     *
     * @param parameter
     * @return
     * @throws MultipleVariantObjectsException if more than one reference target exists which can never happen in the following cases:
     * <ul>
     * <li>In non-variant projects
     * <li>If the client code is being executed in a predefined variant view
     * </ul>
     */
    @PublishedMethod
    MIReferrable getReferenceTarget(final MIReferenceValue parameter);

    /**
     * This method returns all target objects of the specified reference parameter. It returns an empty collection in the following cases:
     * <ul>
     * <li>If the reference parameter has no reference value
     * <li>If the parameters reference value has no target
     * <li>If the parameter is <code>null</code>
     * <li>If the parameter is removed or invisible
     * </ul>
     * This method never returns <code>null</code>.
     *
     * @param parameter
     * @return
     */
    @PublishedMethod
    Collection<MIReferrable> getReferenceTargets(final MIReferenceValue parameter);

    /**
     * This method sorts the specified collection of reference objects to guarantee deterministic order.
     * <p>
     * The criterion to be sorted by is the object link of the reference objects. If this link is equal, the reference values (AUTOSAR path) will be compared.
     * </p>
     *
     * @param references
     * @return
     * @throws NullPointerException if the specified collection is <code>null</code>
     */
    @PublishedMethod
    <T extends MIARRef> List<T> sortReferences(final Collection<T> references);

    /**
     * Returns all reference objects pointing to the specified object. It returns an empty collection if the object is invisible, removed or <code>null</code>.
     * <p>
     * <b>Remark:</b> Be aware that this method also returns objects located in the DerivedEcuC!
     * </p>
     *
     * @param referrable is the object, the searched references point to
     * @return
     */
    @PublishedMethod
    Collection<MIARRef> getAllReferencesPointingTo(final MIReferrable referrable);

    /**
     * Returns all reference objects pointing to the specified object. It returns an empty collection if the object is invisible, removed or <code>null</code>. The returned
     * references are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> Be aware that this method also returns objects located in the DerivedEcuC!
     * </p>
     *
     * @param referrable is the object, the searched references point to
     * @return
     */
    @PublishedMethod
    List<MIARRef> getAllReferencesPointingToSorted(final MIReferrable referrable);

    /**
     * Returns all reference parameters pointing to the specified target object. It returns an empty collection if the object is invisible, removed or <code>null</code>. The
     * returned parameters are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> This method doesn't return objects contained in the DerivedEcuC!
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIReferenceValue> getReferenceParametersPointingTo(final MIReferrable target);

    /**
     * Returns all reference parameters with the specified definition pointing to the specified target object. It returns an empty collection if the object is invisible, removed
     * or <code>null</code> or the specified definition is <code>null</code>. The returned parameters are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> This method doesn't return objects contained in the DerivedEcuC!
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @param definition is a parameter definition (absolute definition path or its last shortname)
     * @return
     */
    @PublishedMethod
    List<MIReferenceValue> getReferenceParametersPointingTo(final MIReferrable target, final String definition);

    /**
     * Returns all reference parameters with the specified definition pointing to the specified target object. It returns an empty collection if the object is invisible, removed
     * or <code>null</code> or the specified definition is <code>null</code>. The returned parameters are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> This method doesn't return objects contained in the DerivedEcuC!
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @param defRef is a parameter {@link DefRef}
     * @return
     */
    @PublishedMethod
    List<MIReferenceValue> getReferenceParametersPointingTo(final MIReferrable target, final DefRef defRef);

    /**
     * This method returns all model objects which are parent objects of references pointing to the specified target. It returns an empty collection if the object is invisible,
     * removed or <code>null</code>.
     * <p>
     * The returned list may also contain derived objects (located in the InitialEcuC).
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIObject> getObjectsPointingTo(final MIReferrable target);

    /**
     * This method returns all parameter objects located in the ActiveEcuC which are parent objects or references pointing to the specified target. It returns an empty
     * collection if the object is invisible, removed or <code>null</code>.
     * <p>
     * The returned objects can be of type {@link MIReferenceValue} and {@link MIInstanceReferenceValue}.
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIParameterValue> getActiveEcucParametersPointingTo(final MIReferrable target);

    /**
     * This method returns all objects located in the system description which are parent objects of references pointing to the specified target. It returns an empty collection
     * if the object is invisible, removed or <code>null</code>.
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIObject> getSystemDescriptionObjectsPointingTo(final MIReferrable target);

}
