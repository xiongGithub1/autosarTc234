package com.vector.cfg.dom.modemgt.groovy.bswm;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IBswMAutoConfigurationApi} allows for automatic creation of dedicated parts of the BswM configuration.
 * <div class="extdoc" id="IBswMAutoConfigurationApi"><!--Label:IBswMAutoConfigurationApi-->The {@link IBswMAutoConfigurationApi} allows for semi-automatic creation of dedicated
 * parts of the BswM configuration. The BswM auto configuration takes an input consisting of "features" and "parameters" to be provided via the
 * {@link IBswMAutoConfigurationApi}. Each feature may have zero, one or more sub-features and zero, one or more parameters.
 * <p>
 * The corresponding BswM configuration content is derived based on the (de)activation of features and the values assigned to the parameters.
 * </p>
 * <p>
 * The available features and parameters depend strongly on the project's input data and general project setup. They can be addressed by {@link String} identifiers. These
 * identifiers are best obtained from the corresponding auto configuration assistant of the BSW management editor in the Cfg5 GUI.
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswMAutoConfigurationApi extends IBswMAutoConfigurationDomain {

    /**
     * {@link #activate(String)} activates the BswM auto configuration feature with the given identifier.
     * <div class="extdoc" id="activate"><!--Label:IBswMAutoConfigurationApi.activate-->
     * <h5>Activating BswM Auto Configuration Features</h5>{@link #activate(String)} activates the BswM auto configuration feature with the given identifier. All enabled
     * sub-features of the specified feature are also activated. Imagine the features displayed in a tree structure (like in Cfg5 GUI) where checking a tree node automatically
     * checks all children.</div>
     *
     * @throws IllegalArgumentException if there is no feature with the given identifier
     * @throws IllegalStateException if the feature with the given identifier is disabled
     */
    @PublishedMethod
    void activate(String featureId);

    /**
     * {@link #deactivate(String)} deactivates the BswM auto configuration feature with the given identifier.
     * <div class="extdoc" id="deactivate"><!--Label:IBswMAutoConfigurationApi.deactivate-->
     * <h5>Deactivating BswM Auto Configuration Features</h5>{@link #deactivate(String)} deactivates the BswM auto configuration feature with the given identifier. All enabled
     * sub-features of the specified feature are also deactivated. Imagine the features displayed in a tree structure (like in Cfg5 GUI) where unchecking a tree node
     * automatically unchecks all children.</div>
     *
     * @throws IllegalArgumentException if there is no feature with the given identifier
     * @throws IllegalStateException if the feature with the given identifier is disabled
     */
    @PublishedMethod
    void deactivate(String featureId);

    /**
     * {@link #set(String)} sets the parameter with the given identifier to the specified value. <div class="extdoc" id="set"><!--Label:IBswMAutoConfigurationApi.set-->
     * <h5>Assigning Values to BswM Auto Configuration Parameters</h5>{@link #set(String)} sets the parameter with the given identifier to the specified value. Supported value
     * types are {@code boolean}, {@link BigInteger}, {@link BigDecimal}, {@link String} and {@link MIReferrable} (reference parameters).</div>
     *
     * @throws IllegalArgumentException if there is no parameter with the given identifier
     * @throws IllegalStateException if the parameter with the given identifier is disabled
     */
    @PublishedMethod
    IBswMAutoConfigurationParameterSetter set(String parameterId);

    /**
     * Using {@link #overrides(Closure)} a callback can be registered for deciding how to handle manual adaptations of the auto-generated configuration content.
     * <div class="extdoc" id="overrides"><!--Label:IBswMAutoConfigurationApi.overrides-->
     * <h5>Manually Adapting the BswM Auto Configuration Content</h5>The BswM auto configuration mechanism is useful for creating large parts of the BswM configuration based on
     * certain built-in heuristics. Where these heuristics fail to fulfill detailed project specific requirements manual adaptations to the auto-generated configuration content
     * become necessary.
     * <p>
     * Per default manual adjustments are kept in the configuration. But subsequent BswM auto configuration runs may render previously applied adjustments obsolete or
     * dysfunctional. Using {@link #overrides(Closure)} a callback can be registered to be called for each detected adaptation. The callback can decide for each adjustment if it
     * is to remain in the configuration or if it is to be overwritten by the BswM auto configuration. For details on which information is provided to this callback please refer
     * to the javadoc provided with {@link IBswMAutoConfigurationOverride}.
     * </p>
     * </div>
     */
    @PublishedMethod
    void overrides(@VDelegatesToWithClosureParam(IBswMAutoConfigurationOverride.class) Closure<?> callback);

}
