package com.vector.cfg.automation.api.userinteraction;

import org.eclipse.core.runtime.SubMonitor;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.text.log.IUserInteractionMessageService;

import groovy.lang.Closure;

/**
 * {@link IUserInteractionApi} provides API to display messages to the user. Use the {@link IUserInteractionApiEntryPoint} to retrieve an instance of
 * {@link IUserInteractionApi}.
 *
 * <div class="extdoc" id="Common"> The UserInteraction API provides methods to display messages to the user directly. In UI mode the DaVinci Configurator will prompt a message
 * box an will block until the user has acknowledged the message. In console (non UI) mode, the message is logged to the console in a user logger.
 *
 * The user logger will display error, warnings and infos by default. The logger name will not be displayed.
 *
 * The user interaction is good to display information where the user has to respond to immediately. Please use the feature sparingly, because users do not like to acknowledge
 * multiple messages for a single script task execution.
 *
 * The code block <code>userInteractions{}</code> provides the API inside of the block. The following methods can be used:
 * <ul>
 * <li><code>errorToUser()</code></li>
 * <li><code>warnToUser()</code></li>
 * <li><code>infoToUser()</code></li>
 * <li><code>messageToUser(ELogLevel, Object)</code></li>
 * </ul>
 *
 * The severity (error, warning, info) will change the display (icons, text) of the message box. No other semantic is applied by the severity.
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IUserInteractionApi extends IUserInteractionMessageService {

    /**
     * Updates the progress information for the user with the message, during the code is running.
     *
     * <div class="extdoc" id="progress"> If you perform long running operations in a script task, you should display some progress to the user, otherwise the user may cancel
     * the whole execution. The progress API will display the progress of the currently running script task by the information provided by the script code.
     *
     * The method {@link #progress(String, Closure)} displays the passed message in progress information dialog and executed the code block. So the message is displayed until
     * the code block has finished.</div>
     *
     *
     * <div class="extdoc" id="progress_nesting"> You could also nest multiple <code>progress()</code> calls. When a progress block is left, the parent progress text will be
     * displayed again. </div>
     *
     *
     * @param <T> the return type of the code
     * @param message the message to display to the user
     * @param code the code to execute
     * @return the returned value of the code block
     */
    @PublishedMethod
    <T> T progress(String message, Closure<T> code);

    /**
     * Updates the progress information for the user with the message, during the code is running.
     *
     * <div class="extdoc" id="progress_totalwork"> The method {@link #progress(String, int, Closure)} updates the progress information for the user with the message, during the
     * code is running with work ticks.
     * <p>
     * It also indicates progress in the progress bar, but you have to set the total amount of work. The total work will be taken from the parent and sets the remaining work for
     * the code block.
     * </p>
     * <p>
     * The root script task always starts with totalWork of <code>1000</code> ticks, so you have to consume <code>1000</code> ticks to fill the progress bar.
     * </p>
     * </div> <div class="extdoc" id="Eclipse_progress">
     * <h5>Eclipse API</h5>
     * <p>
     * You can also use the underlying Eclipse API to fine grain control the progress bar and information data. To do this use the {@link #getProgressMonitor()} method to
     * retrieve the Eclipse {@link SubMonitor}. See also the Eclipse API {@link SubMonitor#setWorkRemaining(int)} to scale your own work to different values (also more than
     * <code>1000</code> ticks).
     * </p>
     * </div>
     *
     * @param <T> the return type of the code
     * @param message the message to display to the user
     * @param totalWork the total work
     * @param code the code to execute
     * @return the returned value of the code block
     */
    @PublishedMethod
    <T> T progress(String message, int totalWork, Closure<T> code);

    /**
     * Sets the a given number of work unit of the last {@link #progress(String, int, Closure)} call.
     *
     * @param work the work
     */
    @PublishedMethod
    void worked(int work);

    /**
     * Returns the underlying Eclipse {@link SubMonitor} for fine grained progress control.
     *
     * @return the progress monitor
     */
    @PublishedMethod
    SubMonitor getProgressMonitor();
}