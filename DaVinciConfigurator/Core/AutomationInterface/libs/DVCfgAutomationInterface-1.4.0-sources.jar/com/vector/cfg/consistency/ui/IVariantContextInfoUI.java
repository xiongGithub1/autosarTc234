package com.vector.cfg.consistency.ui;

import java.util.Collection;
import java.util.Set;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.helper.validationresults.AbstractResultBuilder;
import com.vector.cfg.model.view.config.variant.IInvariantView;
import com.vector.cfg.model.view.config.variant.IPredefinedVariantView;

/**
 * An {@link IVariantContextInfoUI} shows the assignment to {@link IPredefinedVariantView}s e.g. of an {@link IValidationResultUI}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
public interface IVariantContextInfoUI {
    /**
     * A result is general if it is assigned to all or no predefined variant.
     *
     * @return whether the context of this VR is "general"
     */
    @PublishedMethod
    boolean isGeneralVariantContext();

    /**
     * if {@link IVariantContextInfoUI#isGeneralVariantContext()} returns true, the result of this method should not be used. Otherwise it returns the predefined variant views
     * in which this result is effective.
     *
     * @return returns the variant contexts of this result. See {@link AbstractResultBuilder#inVariant(Collection)}
     *
     */
    @PublishedMethod
    Set<IPredefinedVariantView> getPredefinedVariantContexts();

    /**
     * Returns a Set of {@link IInvariantView}, which were associated with the {@link IValidationResult}.
     *
     * <p>
     * The Set could also be empty, if no invariant data is contained.
     * </p>
     *
     * @return the invariant views as {@link Set}.
     */
    @PublishedMethod
    Set<IInvariantView> getInvariantViews();
}
