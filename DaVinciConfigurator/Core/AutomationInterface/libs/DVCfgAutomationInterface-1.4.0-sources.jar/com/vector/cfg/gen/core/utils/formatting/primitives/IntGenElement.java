package com.vector.cfg.gen.core.utils.formatting.primitives;

import java.math.BigInteger;
import java.text.MessageFormat;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIIntParameter;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.utils.formatting.IGenElement;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractPrimitiveElement;
import com.vector.cfg.gen.core.utils.frameworkinternal.GeneratorUtilFrameworkHelper;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;

/**
 * The format element for Integer/Long objects
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class IntGenElement extends AbstractPrimitiveElement<IntGenElement> {

    private static final BigInteger MIN_UINT8 = BigInteger.valueOf(0);

    private static final BigInteger MAX_UINT8 = BigInteger.valueOf(255);

    private static final BigInteger MIN_SINT8 = BigInteger.valueOf(Byte.MIN_VALUE);

    private static final BigInteger MAX_SINT8 = BigInteger.valueOf(Byte.MAX_VALUE);

    private static final BigInteger MIN_UINT16 = BigInteger.valueOf(0);

    private static final BigInteger MAX_UINT16 = BigInteger.valueOf(65535);

    private static final BigInteger MIN_SINT16 = BigInteger.valueOf(Short.MIN_VALUE);

    private static final BigInteger MAX_SINT16 = BigInteger.valueOf(Short.MAX_VALUE);

    private static final BigInteger MIN_UINT32 = BigInteger.valueOf(0);

    private static final BigInteger MAX_UINT32 = BigInteger.valueOf(4294967295L);

    private static final BigInteger MIN_SINT32 = BigInteger.valueOf(Integer.MIN_VALUE);

    private static final BigInteger MAX_SINT32 = BigInteger.valueOf(Integer.MAX_VALUE);

    private static final BigInteger MIN_SINT64 = BigInteger.valueOf(Long.MIN_VALUE);

    private static final BigInteger MAX_SINT64 = BigInteger.valueOf(Long.MAX_VALUE);

    private static final BigInteger MIN_UINT64 = BigInteger.valueOf(0);

    private static final BigInteger MAX_UINT64 = new BigInteger("18446744073709551615");

    private BigInteger numberObj;

    private GIIntParameter bswmdModelObj;

    private EDestinationDataType destinationType;

    private final boolean destinationTypeWasSet = false;

    private boolean asHex;

    private boolean asXXWasSet = false;

    private boolean withoutIntSuffix;

    private IntGenElement() {
        destinationType = EDestinationDataType.UINT_32;
        asHex = true;
        withoutIntSuffix = false;

    }

    /**
     * Constructor for IntGenElement.
     *
     * @param intObj
     */
    IntGenElement(int intObj) {
        this();
        this.numberObj = BigInteger.valueOf(new Long(intObj));

    }

    /**
     * Constructor for IntGenElement.
     *
     * @param intObj
     */
    IntGenElement(Integer intObj) {
        this();
        if (intObj == null) {
            throw new IllegalArgumentException("intObj is null");
        }
        this.numberObj = BigInteger.valueOf(new Long(intObj));
    }

    /**
     * Constructor for IntGenElement.
     *
     * @param obj
     */
    IntGenElement(Long longObj) {
        this();
        if (longObj == null) {
            throw new IllegalArgumentException("longObj is null");
        }
        this.numberObj = BigInteger.valueOf(longObj);
    }

    /**
     * Constructor for IntGenElement.
     *
     * @param longObj
     */
    IntGenElement(long longObj) {
        this();
        this.numberObj = BigInteger.valueOf(new Long(longObj));
    }

    /**
     * Constructor for IntGenElement.
     *
     * @param longObj
     */
    IntGenElement(BigInteger bigIntObj) {
        this();
        if (bigIntObj == null) {
            throw new IllegalArgumentException("bigIntObj is null");
        }
        this.numberObj = bigIntObj;
    }

    /**
     * Constructor for IntGenElement.
     *
     * @param gInteger
     */
    IntGenElement(GIIntParameter gInteger) {
        this();
        if (gInteger == null) {
            throw new IllegalArgumentException("gInteger is null");
        }

        bswmdModelObj = gInteger;

        if (!bswmdModelObj.existsMDF()) {
            reportBswmdParamterNotExistsError(bswmdModelObj);

            this.numberObj = BigInteger.ZERO;
        } else {
            this.numberObj = gInteger.getBigIntegerValue();
        }
    }

    /**
     * Selects the HEX format for the Integer value. This means the number will be generated as a hex value with a leading 0x&lt;value&gt; .
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if a Hex/Decimal format was already assigned</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement asHex() {
        ensureObjectIsMutable();
        if (asXXWasSet) {
            throw new IllegalStateException("AsHex or asDecimal was already set! It is not allowed to change the Hex/Decimal format.");
        }
        asHex = true;
        asXXWasSet = true;
        return this;
    }

    /**
     * Selects the Decimal format for the Integer value. This means the number will be generated as a decimal number.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if a Hex/Decimal format was already assigned</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement asDecimal() {
        ensureObjectIsMutable();
        if (asXXWasSet) {
            throw new IllegalStateException("asDecimal or asHex was already set! It is not allowed to change the Hex/Decimal format.");
        }
        asHex = false;
        asXXWasSet = true;
        return this;
    }

    /**
     * This call suppresses the generation of an Integer Suffix like U,UL. Normally the format object will append the Integer suffix depending on the type of the object.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if a WithoutIntSuffix already assigned</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement withoutIntSuffix() {
        ensureObjectIsMutable();
        if (withoutIntSuffix) {
            throw new IllegalStateException("WithoutIntSuffix was already set! It is not allowed to change the IntSuffix behavior.");
        }
        withoutIntSuffix = true;
        return this;

    }

    /**
     * Converts the Integer object to a signed integer with datatype width byteLength.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @param byteLength the length of the destination datatype in bytes. Permitted values are 1, 2, 4, 8.
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the destination datatype was already set.</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the byteLength does not correspond to a destination datatype.</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement toSint(long byteLength) {
        ensureObjectIsMutable();
        if (destinationTypeWasSet) {
            throw new IllegalStateException(MessageFormat.format("The destination datatype was already set to {0}. It is not allowed to change the datatype.", destinationType));
        }

        switch (Long.valueOf(byteLength).intValue()) {
        case 1:
            destinationType = EDestinationDataType.SINT_8;
            break;
        case 2:
            destinationType = EDestinationDataType.SINT_16;
            break;
        case 4:
            destinationType = EDestinationDataType.SINT_32;
            break;
        case 8:
            destinationType = EDestinationDataType.SINT_64;
            break;
        default:
            throw new IllegalArgumentException("The byteLength " + byteLength + " is no supported datatype lentgh. Only 1, 2, 4, 8 are permitted values ");

        }

        return this;
    }

    /**
     * Converts the Integer object to a unsigned integer with datatype width byteLength.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @param byteLength the length of the destination datatype in bytes. Permitted values are 1, 2, 4, 8.
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the destination datatype was already set.</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the byteLength does not correspond to a destination datatype.</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement toUint(long byteLength) {
        ensureObjectIsMutable();
        if (destinationTypeWasSet) {
            throw new IllegalStateException(MessageFormat.format("The destination datatype was already set to {0}. It is not allowed to change the datatype.", destinationType));
        }

        switch (Long.valueOf(byteLength).intValue()) {
        case 1:
            destinationType = EDestinationDataType.UINT_8;
            break;
        case 2:
            destinationType = EDestinationDataType.UINT_16;
            break;
        case 4:
            destinationType = EDestinationDataType.UINT_32;
            break;
        case 8:
            destinationType = EDestinationDataType.UINT_64;
            break;
        default:
            throw new IllegalArgumentException("The byteLength " + byteLength + " is no supported datatype lentgh. Only 1, 2, 4, 8 are permitted values ");

        }

        return this;
    }

    /**
     * Converts the Integer object to a signed byte (sint8 in AUTOSAR) integer.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the destination datatype was already set.</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement toSint8() {
        ensureObjectIsMutable();
        if (destinationTypeWasSet) {
            throw new IllegalStateException(MessageFormat.format("The destination datatype was already set to {0}. It is not allowed to change the datatype.", destinationType));
        }

        destinationType = EDestinationDataType.SINT_8;
        return this;
    }

    /**
     * Converts the Integer object to a unsigned byte (uint8 in AUTOSAR) integer.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the destination datatype was already set.</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement toUint8() {
        ensureObjectIsMutable();
        if (destinationTypeWasSet) {
            throw new IllegalStateException(MessageFormat.format("The destination datatype was already set to {0}. It is not allowed to change the datatype.", destinationType));
        }

        destinationType = EDestinationDataType.UINT_8;
        return this;
    }

    /**
     * Converts the Integer object to a signed short,16-bit (sint16 in AUTOSAR) integer.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the destination datatype was already set.</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement toSint16() {
        ensureObjectIsMutable();
        if (destinationTypeWasSet) {
            throw new IllegalStateException(MessageFormat.format("The destination datatype was already set to {0}. It is not allowed to change the datatype.", destinationType));
        }

        destinationType = EDestinationDataType.SINT_16;
        return this;
    }

    /**
     * Converts the Integer object to a unsigned short,16-bit (uint16 in AUTOSAR) integer.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the destination datatype was already set.</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement toUint16() {
        ensureObjectIsMutable();
        if (destinationTypeWasSet) {
            throw new IllegalStateException(MessageFormat.format("The destination datatype was already set to {0}. It is not allowed to change the datatype.", destinationType));
        }

        destinationType = EDestinationDataType.UINT_16;
        return this;
    }

    /**
     * Converts the Integer object to a signed int, 32-bit (sint32 in AUTOSAR) integer.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the destination datatype was already set.</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement toSint32() {
        ensureObjectIsMutable();
        if (destinationTypeWasSet) {
            throw new IllegalStateException(MessageFormat.format("The destination datatype was already set to {0}. It is not allowed to change the datatype.", destinationType));
        }

        destinationType = EDestinationDataType.SINT_32;
        return this;
    }

    /**
     * Converts the Integer object to a unsigned int, 32-bit (uint32 in AUTOSAR) integer.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the destination datatype was already set.</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement toUint32() {
        ensureObjectIsMutable();
        if (destinationTypeWasSet) {
            throw new IllegalStateException(MessageFormat.format("The destination datatype was already set to {0}. It is not allowed to change the datatype.", destinationType));
        }

        destinationType = EDestinationDataType.UINT_32;
        return this;
    }

    /**
     * Converts the Integer object to a signed long, 64-bit (sint64 in AUTOSAR) integer.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the destination datatype was already set.</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement toSint64() {
        ensureObjectIsMutable();
        if (destinationTypeWasSet) {
            throw new IllegalStateException(MessageFormat.format("The destination datatype was already set to {0}. It is not allowed to change the datatype.", destinationType));
        }

        destinationType = EDestinationDataType.SINT_64;
        return this;
    }

    /**
     * Converts the Integer object to a unsigned long, 64-bit (uint64 in AUTOSAR) integer.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the destination datatype was already set.</li>
     * </ul>
     */
    @PublishedMethod
    public IntGenElement toUint64() {
        ensureObjectIsMutable();
        if (destinationTypeWasSet) {
            throw new IllegalStateException(MessageFormat.format("The destination datatype was already set to {0}. It is not allowed to change the datatype.", destinationType));
        }

        destinationType = EDestinationDataType.UINT_64;
        return this;
    }

    private void formatInternal(StringBuilder builder) {

        checkRange();

        if (asHex) {
            final BigInteger truncatedValue = truncate(numberObj, destinationType);

            builder.append("0x");
            final String hexString;
            if (destinationType == EDestinationDataType.UINT_64) {
                hexString = String.format("%" + destinationType.getHexDigitCount() + "X", truncatedValue).trim();
            } else {
                hexString = Long.toHexString(truncatedValue.longValue()).toUpperCase();
            }
            // Append leading zeros
            if (hexString.length() < destinationType.getHexDigitCount()) {
                for (int x = 0; x < (destinationType.getHexDigitCount() - hexString.length()); x++) {
                    builder.append("0");
                }
            }
            builder.append(hexString);

        } else {

            if (isUnsigned(destinationType)) {

                builder.append(numberObj);
            } else {

                switch (destinationType) {
                case SINT_8:
                    builder.append(numberObj.byteValue());
                    break;
                case SINT_16:
                    builder.append(numberObj.shortValue());
                    break;
                case SINT_32:
                    builder.append(numberObj.intValue());
                    break;
                case SINT_64:
                    builder.append(numberObj);
                    break;
                default:
                    throw new IllegalArgumentException("Illegal DestinationDataType found for signed operation path!");
                }

            }

        }

        if (!withoutIntSuffix) {
            // Append Value Suffix
            builder.append(destinationType.getIntSuffix());
        }

    }

    /**
     * @param bswmdModelObj
     * @param destinationType2
     * @param numberObjdestinationType
     */
    private void checkRange() {

        boolean reportError = false;

        switch (destinationType) {
        case UINT_8:
            if (numberObj.compareTo(MIN_UINT8) < 0 || numberObj.compareTo(MAX_UINT8) > 0) {
                reportError = true;
            }
            break;
        case SINT_8:
            if (numberObj.compareTo(MIN_SINT8) < 0 || numberObj.compareTo(MAX_SINT8) > 0) {
                reportError = true;
            }
            break;
        case UINT_16:
            if (numberObj.compareTo(MIN_UINT16) < 0 || numberObj.compareTo(MAX_UINT16) > 0) {
                reportError = true;
            }
            break;
        case SINT_16:
            if (numberObj.compareTo(MIN_SINT16) < 0 || numberObj.compareTo(MAX_SINT16) > 0) {
                reportError = true;
            }
            break;
        case UINT_32:
            if (numberObj.compareTo(MIN_UINT32) < 0 || numberObj.compareTo(MAX_UINT32) > 0) {
                reportError = true;
            }
            break;
        case SINT_32:
            if (numberObj.compareTo(MIN_SINT32) < 0 || numberObj.compareTo(MAX_SINT32) > 0) {
                reportError = true;
            }
            break;
        case UINT_64:
            if (numberObj.compareTo(MIN_UINT64) < 0 || numberObj.compareTo(MAX_UINT64) > 0) {
                reportError = true;
            }
            break;
        case SINT_64:
            if (numberObj.compareTo(MIN_SINT64) < 0 || numberObj.compareTo(MAX_SINT64) > 0) {
                reportError = true;
            }
            break;
        default:
            throw new IllegalArgumentException("Illegal DestinationDataType found!");
        }

        if (reportError) {

            final StringBuilder commentBuilder = new StringBuilder();
            if (getPrefixComment() != null) {
                commentBuilder.append(getPrefixComment());
                commentBuilder.append(" ");
            }
            if (getPostfixComment() != null) {
                commentBuilder.append(getPostfixComment());
            }

            /*
             * Report an error
             */
            final IGeneratorPackage pack = GeneratorUtilFrameworkHelper.getCurrentGeneratorPackage();
            if (pack == null) {
                throw new NumberFormatException(
                        MessageFormat
                                .format("These is no generatorPackage available to report the out of Range Error. The value {0} with comment ({1}) is not in the range of the specified datatype {2}.",
                                        numberObj.toString(), commentBuilder.toString(), destinationType));

            }

            final GeneratorResultBuilder builder;

            if (bswmdModelObj != null) {
                /*
                 * If a bswmdModelOBject is available create a IGeneratorResult warning
                 */
                builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getGeneratedValueOutOufRange(pack),
                        "The value {0} of the parameter {1} is not in the range of the specified datatype {2}.", numberObj.toString(), bswmdModelObj, destinationType);

                builder.addErrorObject(bswmdModelObj);
                builder.assignException(new RuntimeException("StackTrace of invalid IntGenElement"));

            } else {
                /*
                 * We have no bswmdModel context info so create a generic message
                 */
                builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getGeneratedValueOutOufRange(pack),
                        "The value {0} with comment ({1}) is not in the range of the specified datatype {2}.", numberObj.toString(), commentBuilder.toString(), destinationType);

                builder.assignException(new RuntimeException("StackTrace of invalid IntGenElement"));
            }

            comment(MessageFormat.format("ERROR: The value {0} is not in the range of the specified datatype {2}.", numberObj.toString(), commentBuilder.toString(),
                    destinationType));

            pack.getGenerationProcessor().getResultSink().reportGeneratorResult(builder.buildResult());

        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void generatePrimitiveInternal(StringBuilder builder, IGenFormatter formatter, int indent) {
        formatInternal(builder);
    }

    /**
     * @param numberObj2
     * @return
     */
    private static BigInteger truncate(BigInteger numberObj, EDestinationDataType destinationType) {

        final BigInteger truncatedNumber;

        switch (destinationType) {
        case UINT_8:
        case SINT_8:
            truncatedNumber = numberObj.and(MAX_UINT8);
            break;
        case UINT_16:
        case SINT_16:
            truncatedNumber = numberObj.and(MAX_UINT16);
            break;
        case UINT_32:
        case SINT_32:
            truncatedNumber = numberObj.and(MAX_UINT32);
            break;
        case UINT_64:
        case SINT_64:
            truncatedNumber = numberObj.and(MAX_UINT64);
            break;
        default:
            throw new IllegalArgumentException("Illegal DestinationDataType found for truncate operation!");
        }

        return truncatedNumber;
    }

    private static boolean isUnsigned(EDestinationDataType type) {

        if (type == EDestinationDataType.UINT_8 || type == EDestinationDataType.UINT_16 || type == EDestinationDataType.UINT_32 || type == EDestinationDataType.UINT_64) {
            return true;
        }

        return false;

    }

    public enum EDestinationDataType {
        UINT_8(2, "U"),
        SINT_8(2, ""),
        UINT_16(4, "U"),
        SINT_16(4, ""),
        UINT_32(8, "UL"),
        SINT_32(8, "L"),
        UINT_64(16, "ULL"),
        SINT_64(16, "LL")

        ;

        private String intSuffix;

        private final int hexDigitCount;

        /**
         * Constructor for IntGenElement.DestinationDataType.
         *
         */
        EDestinationDataType(int hexDigitCount, String intSuffix) {
            this.hexDigitCount = hexDigitCount;
            this.setIntSuffix(intSuffix);
        }

        public int getHexDigitCount() {
            return hexDigitCount;
        }

        public void setIntSuffix(String intSuffix) {
            this.intSuffix = intSuffix;
        }

        public String getIntSuffix() {
            return intSuffix;
        }
    }
}
