package com.vector.cfg.automation.scripting.base;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link INotExecutableReasonBuilder} is used to set information for the user, why a certain {@link IScriptTask} is currently not executable.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IScriptTask
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface INotExecutableReasonBuilder {

    /**
     * Adds a reason, why the {@link IScriptTask} is not executable.
     *
     * <p>
     * The reason is display the the user, when the {@link IScriptTask} shall be called, but is not executable
     * </p>
     *
     * @param message the reason to show the user, why the task is not executable
     */
    @PublishedMethod
    void addReason(String message);

    /**
     * The Interface {@link IExecutableTaskEvaluator} provides a java {@link FunctionalInterface} to evaluate if an IScriptTask is executable.
     *
     * @see {@link INotExecutableReasonBuilder}
     */
    @PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    @FunctionalInterface
    public interface IExecutableTaskEvaluator {

        /**
         * Returns <code>true</code>, if the {@link IScriptTask} from the {@link IScriptExecutionContext} shall be executable, for the passed args. If not, the
         * {@link INotExecutableReasonBuilder} shall be called, with reasons, why the task is not executable.
         *
         * @param scriptExecutionContext the scriptTask execution to check, if executable
         * @param notExecutableReasons the {@link INotExecutableReasonBuilder} to set reasons, why not executable
         * @param args the args which will be passed to the {@link IScriptTask}. The types are defined in the {@link IScriptTaskType} of the task.
         * @return true, if the {@link IScriptTask} is executable
         */
        @PublishedMethod
        boolean isExecutable(IScriptExecutionContext scriptExecutionContext, INotExecutableReasonBuilder notExecutableReasons, Object... args);
    }

    /**
     * The Interface INotExecutableReasonBuilderProvider is used to set the {@link INotExecutableReasonBuilder} instance into the current running ScriptExecutionContext.
     * @noimplement This interface is not intended to be implemented by clients.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface INotExecutableReasonBuilderProvider {
        /**
         * Return the {@link INotExecutableReasonBuilder} .
         *
         * @return the reason builder
         */
        @PublishedMethod
        INotExecutableReasonBuilder notExecutableReasons();

        /**
         * Return the {@link INotExecutableReasonBuilder} .
         *
         * @return the reason builder
         */
        @PublishedMethod
        INotExecutableReasonBuilder getNotExecutableReasons();
    }
}
