package com.vector.cfg.gen.core.utils.exceptions;

import java.util.ArrayList;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IValidationSeverityResultId;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SACreateContainer;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SACreateParameter;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SetDefaultValue;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasValidationOrigin;
import com.vector.cfg.gen.core.moduleinterface.exceptions.IHasSetExceptionAsCause;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.cedescriptor.IDescriptorBuilder;
import com.vector.cfg.model.cedescriptor.IDescriptorFactoryUtil;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.elements.EElementType;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaDefinitionUndefinedException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaInvalidParentForDefinitionException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaInvalidRequestException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaNotExistsException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongQuantityException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IDefinitionUndefinedExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IInvalidParentForDefinitionExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IInvalidRequestExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.INotExistsExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IReverseRefExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IWrongQuantityExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.params.IParamHasIllegalValueExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.params.IParamHasNoValueExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.params.IParamWrongTypeExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.references.IRefHasNoRefTargetExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.references.IRefWrongTargetDefExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.references.IRefWrongTypeExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterHasIllegalValueException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterHasNoValueException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterWrongTypeException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceHasNoRefTargetException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceWrongTargetDefinitionException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceWrongTypeException;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManagerCoreInternal;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.exceptions.InterruptedRuntimeException;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Utility class to process and transform {@link McaException}s (exceptions from {@link IModelCheckedAccess}) into a {@link IGeneratorResult} and report them to the framework.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IGeneratorResultSink
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class ModelCheckedAccessExceptionProcessor {

    private static final ILogger logger = Logger.INSTANCE.createLogger(ModelCheckedAccessExceptionProcessor.class);

    private ModelCheckedAccessExceptionProcessor() {
    }

    /**
     * Adds a {@link McaException} to a {@link IValidationResultSink} by creating a corresponding {@link IGeneratorResult}.
     *
     * @param resultSink the {@link IGeneratorResultSink} to use
     * @param ex the exception to report
     * @param generatorPackageRef the {@link IGeneratorPackage} which is used as origin.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the resultSink is null</li>
     * <li>if the ex is null</li>
     * <li>if the generatorPackageRef is null</li>
     * <li>if the generatorPackage of generatorPackageRef is null</li>
     * </ul>
     */
    @PublishedMethod
    public static void addExceptionToResultSink(IValidationResultSink resultSink, McaException ex, IGeneratorPackageReferable generatorPackageRef) {
        if (resultSink == null) {
            throw new IllegalArgumentException("resultSink is null");
        }
        final List<IGeneratorResult> resultList = wrapExceptionIntoGeneratorResults(ex, generatorPackageRef);
        for (final IGeneratorResult result : resultList) {
            resultSink.reportValidationResult(result);
        }

    }

    /**
     * Wraps a {@link McaException} into many {@link IGeneratorResult}s .
     *
     * @param ex The {@link McaException} which shall be wrapped into {@link IGeneratorResult}s.
     * @param generatorPackageRef the {@link IGeneratorPackage} which is used as origin.
     * @return List of {@link IGeneratorResult}s
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the ex is null</li>
     * <li>if the generatorPackageRef is null</li>
     * <li>if the generatorPackage of generatorPackageRef is null</li>
     * </ul>
     */
    @PublishedMethod
    public static List<IGeneratorResult> wrapExceptionIntoGeneratorResults(McaException ex, IGeneratorPackageReferable generatorPackageRef) {

        if (ex == null) {
            throw new IllegalArgumentException("ex is null");
        }
        if (generatorPackageRef == null) {
            throw new IllegalArgumentException("generatorPackageRef is null");
        }
        final IGeneratorPackage generatorPackage = generatorPackageRef.getGeneratorPackage();
        if (generatorPackage == null) {
            throw new IllegalArgumentException("generatorPackage is null");
        }

        final IProjectContext projectContext = generatorPackage.getProjectContext();

        return wrapExceptionIntoGeneratorResults(projectContext, ex, generatorPackage);
    }

    /**
     * Wraps a {@link McaException} into many {@link IGeneratorResult}s .
     *
     * @param projectContext
     * @param ex The {@link McaException} which shall be wrapped into {@link IGeneratorResult}s.
     * @param origin the origin of the results
     *
     * @return List of {@link IGeneratorResult}s
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the projectContext is null</li>
     * <li>if the ex is null</li>
     * <li>if the origin is null</li>
     * </ul>
     */
    @KeepSecretFromPublishedApi
    static List<IGeneratorResult> wrapExceptionIntoGeneratorResults(IProjectContext projectContext, McaException ex, IHasValidationOrigin origin) {
        if (projectContext == null) {
            throw new IllegalArgumentException("projectContext is null");
        }
        if (ex == null) {
            throw new IllegalArgumentException("ex is null");
        }
        if (origin == null) {
            throw new IllegalArgumentException("origin is null");
        }

        final IModelViewManagerCoreInternal modelViewMgr = projectContext.getService(IModelViewManagerCoreInternal.class);
        final IModelView processingView = getProcessingView(modelViewMgr, ex);
        try (IModelViewExecutionContext exec = processingView.executeWithThisView()) {

            final List<IGeneratorResult> resultList = new ArrayList<>();
            processExceptionInModelViewOfMcaException(projectContext, ex, resultList, origin);
            return resultList;
        }
    }

    private static IModelView getProcessingView(IModelViewManagerCoreInternal modelViewMgr, McaException ex) {
        IModelView processingView = null;
        for (final IExData data : ex.getExceptionDataList()) {
            if (processingView == null) {
                processingView = data.getActiveModelViewDuringRequest();
            } else {
                if (processingView != data.getActiveModelViewDuringRequest()) {
                    return modelViewMgr.getUnfilteredView();
                }
            }
        }
        return processingView == null ? modelViewMgr.getUnfilteredView() : processingView;
    }

    private static void processExceptionInModelViewOfMcaException(IProjectContext projectContext, McaException ex, final List<IGeneratorResult> resultList,
            IHasValidationOrigin origin) {
        if (ex instanceof McaDefinitionUndefinedException) {

            processDefinitionUndefinedEx(projectContext, resultList, origin, (McaDefinitionUndefinedException) ex);

        } else if (ex instanceof McaNotExistsException) {

            processNotExistsEx(projectContext, resultList, origin, (McaNotExistsException) ex);

        } else if (ex instanceof McaParameterHasNoValueException) {

            processParamHasNoValueEx(projectContext, resultList, origin, (McaParameterHasNoValueException) ex);

        } else if (ex instanceof McaParameterHasIllegalValueException) {

            processParamHasIllegalValueEx(projectContext, resultList, origin, (McaParameterHasIllegalValueException) ex);

        } else if (ex instanceof McaParameterWrongTypeException) {

            processParamWrongTypeEx(projectContext, resultList, origin, (McaParameterWrongTypeException) ex);

        } else if (ex instanceof McaWrongQuantityException) {

            processWrongQuantityEx(projectContext, resultList, origin, (McaWrongQuantityException) ex);

        } else if (ex instanceof McaReferenceWrongTypeException) {

            processRefWrongTypeEx(projectContext, resultList, origin, (McaReferenceWrongTypeException) ex);

        } else if (ex instanceof McaReferenceHasNoRefTargetException) {

            processRefHasNoRefTarget(projectContext, resultList, origin, (McaReferenceHasNoRefTargetException) ex);

        } else if (ex instanceof McaReferenceWrongTargetDefinitionException) {

            processRefWrongTargetDefRef(projectContext, resultList, origin, (McaReferenceWrongTargetDefinitionException) ex);

        } else if (ex instanceof McaInvalidParentForDefinitionException) {

            processInvalidParentForDef(projectContext, resultList, origin, (McaInvalidParentForDefinitionException) ex);

        } else if (ex instanceof McaInvalidRequestException) {

            processInvalidRequest(projectContext, resultList, origin, (McaInvalidRequestException) ex);

        } else {

            processGenericMcaEx(projectContext, resultList, origin, ex);

        }
    }

    /**
     * @param genResult
     */
    static void assignExceptionToGeneratorResult(IGeneratorResult genResult, Throwable ex) {
        if (genResult instanceof IHasSetExceptionAsCause) {
            ((IHasSetExceptionAsCause) genResult).setException(ex);
        }

    }

    private static void addDefaultValueSolvingAction(GeneratorResultBuilder builder, MIParameterValue param) {
        final ISolvingAction act = SetDefaultValue.create(param);
        if (act != null) {
            builder.setPreferredSolvingAction(act);
        }
    }

    private static void reportResultIntoList(List<IGeneratorResult> resultList, McaException ex, final GeneratorResultBuilder builder) {
        assignActiveModelViewDuringMcaRequestToResult(ex, builder);
        final IGeneratorResult result = builder.buildResult();
        assignExceptionToGeneratorResult(result, ex);
        resultList.add(result);
    }

    /**
     * Assign active model view during mca request to result.
     *
     * @param ex the ex
     * @param builder the builder
     */
    private static void assignActiveModelViewDuringMcaRequestToResult(McaException ex, GeneratorResultBuilder builder) {
        for (final IExData data : ex.getExceptionDataList()) {
            builder.addModelViewContext(data.getActiveModelViewDuringRequest());
        }
    }

    private static void processNotExistsEx(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin, McaNotExistsException ex) {
        final INotExistsExData data = ex.getExceptionData();
        final EElementType type = data.getElementType();
        final IValidationSeverityResultId resultId;
        ISolvingAction action = null;

        MIObject parent = null;

        if (data.getParent() != null) {
            parent = data.getParent();
        } else {

            final List<? extends MIObject> searchForAnyParentByDefinition = searchForAnyParentByDefinition(projectContext, data);

            if (searchForAnyParentByDefinition != null && searchForAnyParentByDefinition.size() == 1) {
                // Exact one parent found
                parent = searchForAnyParentByDefinition.get(0);

                // Check if it is a immediate parent
                if (data.getDefRef().getParentDefRef() == null || !data.getDefRef().getParentDefRef().isDefinitionOf(parent)) {
                    // It is not the immediate parent => REMOVE parent
                    parent = null;
                }
            }

        }

        if (type == EElementType.CONTAINER) {
            // It is a Container
            resultId = CommonGeneratorResultIds.getContainerNotExistsId(origin);

            if (parent instanceof MIHasDefinition) {
                action = new SACreateContainer((MIHasContainer) parent, data.getDefRef());
            }
        } else if (type == EElementType.PARAMETER) {
            // It is a parameter
            resultId = CommonGeneratorResultIds.getParameterNotExistsId(origin);

            if (parent instanceof MIContainer) {
                action = new SACreateParameter((MIContainer) parent, data.getDefRef(), "Create Parameter " + data.getDefRef().getLastShortname());
            }
        } else if (type == EElementType.REFERENCE || type == EElementType.REVERSE_REFERENCE) {
            resultId = CommonGeneratorResultIds.getReferenceNotExistsId(origin);

            if (type != EElementType.REVERSE_REFERENCE) {
                if (parent instanceof MIContainer) {
                    action = new SACreateParameter((MIContainer) parent, data.getDefRef(), "Create Reference " + data.getDefRef().getLastShortname());
                }
            }
        } else if (type == EElementType.MODULE_CONFIGURATION) {

            resultId = CommonGeneratorResultIds.getModuleConfigNotExistsId(origin);

        } else {
            throw new IllegalStateException("Wrong element type");
        }

        final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(resultId, data.getUserMessage());

        addMdfObjects(projectContext, data, builder);

        if (type == EElementType.REVERSE_REFERENCE) {
            if (data instanceof IReverseRefExData) {
                /*
                 * Add the target element of the reverse lookup
                 */
                builder.addErrorObject(((IReverseRefExData) data).getTargetElement());
            }
        }

        if (action != null) {
            builder.setPreferredSolvingAction(action);
        }

        reportResultIntoList(resultList, ex, builder);

    }

    private static void processRefHasNoRefTarget(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin,
            McaReferenceHasNoRefTargetException ex) {

        for (final IRefHasNoRefTargetExData data : ex.getExceptionDataList()) {

            final GeneratorResultBuilder builder = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getReferenceHasNoRefTargetId(origin), data.getUserMessage());

            addMdfObjects(projectContext, data, builder);

            reportResultIntoList(resultList, ex, builder);
        }
    }

    private static void processRefWrongTypeEx(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin,
            McaReferenceWrongTypeException ex) {
        for (final IRefWrongTypeExData data : ex.getExceptionDataList()) {

            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getReferenceHasWrongType(origin), data.getUserMessage());

            addMdfObjects(projectContext, data, builder);

            reportResultIntoList(resultList, ex, builder);
        }
    }

    private static void processRefWrongTargetDefRef(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin,
            McaReferenceWrongTargetDefinitionException ex) {
        for (final IRefWrongTargetDefExData data : ex.getExceptionDataList()) {

            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getReferenceTargetHasWrongDefinition(origin),
                    data.getUserMessage());

            addMdfObjects(projectContext, data, builder);

            reportResultIntoList(resultList, ex, builder);
        }
    }

    private static void processGenericMcaEx(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin, McaException ex) {
        for (final IExData data : ex.getExceptionDataList()) {

            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModelAccessFailureId(origin), data.getUserMessage());

            addMdfObjects(projectContext, data, builder);

            reportResultIntoList(resultList, ex, builder);
        }

    }

    private static void processWrongQuantityEx(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin,
            McaWrongQuantityException ex) {

        final IWrongQuantityExData data = ex.getExceptionData();
        final EElementType type = data.getElementType();
        final IValidationSeverityResultId resultId;
        if (type == EElementType.CONTAINER) {
            // It is a Container
            resultId = CommonGeneratorResultIds.getContainerWrongQuantityRequestedId(origin);

        } else if (type == EElementType.PARAMETER) {
            // It is a parameter
            resultId = CommonGeneratorResultIds.getParameterWrongQuantityRequestedId(origin);
        } else if (type == EElementType.REFERENCE || type == EElementType.REVERSE_REFERENCE) {
            resultId = CommonGeneratorResultIds.getReferenceWrongQuantityRequestedId(origin);

        } else if (type == EElementType.MODULE_CONFIGURATION) {

            resultId = CommonGeneratorResultIds.getModuleConfigWrongQuantityRequestedId(origin);

        } else {
            throw new IllegalStateException("Wrong element type");
        }

        // It is a Container
        final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(resultId, data.getUserMessage());

        // Special handling for Wrong Quantity => Add all elements as error, which have wrong quantity
        final List<? extends MIHasDefinition> elementList = data.getElementList();
        if (!elementList.isEmpty()) {
            builder.addErrorMdfObjectList(elementList);
        }

        if (type == EElementType.REVERSE_REFERENCE) {
            if (data instanceof IReverseRefExData) {
                /*
                 * Add the target element of the reverse lookup
                 */
                builder.addErrorObject(((IReverseRefExData) data).getTargetElement());
            }
        }

        // Also add Parent Elements
        addMdfObjects(projectContext, data, builder);

        reportResultIntoList(resultList, ex, builder);

    }

    /**
     * @param results
     * @param generatorPackage
     * @param ex
     */
    private static void processParamWrongTypeEx(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin,
            McaParameterWrongTypeException ex) {
        for (final IParamWrongTypeExData data : ex.getExceptionDataList()) {

            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterHasWrongType(origin), data.getUserMessage());

            addMdfObjects(projectContext, data, builder);

            reportResultIntoList(resultList, ex, builder);
        }

    }

    /**
     * @param results
     * @param generatorPackage
     * @param ex
     */
    private static void processParamHasNoValueEx(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin,
            McaParameterHasNoValueException ex) {

        for (final IParamHasNoValueExData data : ex.getExceptionDataList()) {

            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterHasNoValueId(origin), data.getUserMessage());

            addMdfObjects(projectContext, data, builder);

            addDefaultValueSolvingAction(builder, data.getElement());

            reportResultIntoList(resultList, ex, builder);
        }
    }

    /**
     * @param resultSink
     * @param generatorPackage
     * @param ex
     */
    private static void processParamHasIllegalValueEx(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin,
            McaParameterHasIllegalValueException ex) {
        for (final IParamHasIllegalValueExData data : ex.getExceptionDataList()) {

            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterHasIllegalValue(origin), data.getUserMessage());

            addMdfObjects(projectContext, data, builder);

            addDefaultValueSolvingAction(builder, data.getElement());

            reportResultIntoList(resultList, ex, builder);
        }

    }

    /**
     * @param resultOrigin
     */
    private static void processDefinitionUndefinedEx(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin resultOrigin,
            McaDefinitionUndefinedException ex) {

        final IDefinitionUndefinedExData data = ex.getExceptionData();
        final IValidationSeverityResultId resultId;

        resultId = CommonGeneratorResultIds.getDefinitionRefUndefinedErrorId(resultOrigin);

        final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(resultId, data.getUserMessage());

        addMdfObjects(projectContext, data, builder);

        reportResultIntoList(resultList, ex, builder);

    }

    /**
     * @param resultList
     * @param generatorPackage
     * @param ex
     */
    private static void processInvalidRequest(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin,
            McaInvalidRequestException ex) {
        final IInvalidRequestExData data = ex.getExceptionData();
        final IValidationSeverityResultId resultId;

        resultId = CommonGeneratorResultIds.getModelAccessFailureId(origin);

        final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(resultId, data.getUserMessage());

        addMdfObjects(projectContext, data, builder);

        reportResultIntoList(resultList, ex, builder);

    }

    /**
     * @param resultList
     * @param generatorPackage
     * @param ex
     */
    private static void processInvalidParentForDef(IProjectContext projectContext, List<IGeneratorResult> resultList, IHasValidationOrigin origin,
            McaInvalidParentForDefinitionException ex) {
        final IInvalidParentForDefinitionExData data = ex.getExceptionData();
        final IValidationSeverityResultId resultId;

        resultId = CommonGeneratorResultIds.getModelAccessFailureId(origin);

        final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(resultId, data.getUserMessage());

        addMdfObjects(projectContext, data, builder);

        reportResultIntoList(resultList, ex, builder);

    }

    private static void addMdfObjects(IProjectContext projectContext, IExData data, final GeneratorResultBuilder builder) {

        try {
            if (data.getElement() != null) {
                builder.addErrorObject(data.getElement());

            } else {

                if (data.getParent() != null) {

                    final MIObject parent = data.getParent();

                    builder.addErrorMissingObject(parent, data.getDefRef());

                } else {
                    final List<? extends MIObject> parentList;

                    // Search for any parent element by Definition
                    parentList = searchForAnyParentByDefinition(projectContext, data);

                    if (parentList == null || parentList.isEmpty()) {
                        /*
                         * No Parent found => Use the ModuleConfiguration as parent
                         */
                        final IDescriptorFactoryUtil factoryUtil = projectContext.getService(IDescriptorFactoryUtil.class);

                        final IDescriptorBuilder descBuilder = factoryUtil.createBuilder(data.getDefRef(), null, null);
                        builder.addErrorDescriptor(descBuilder.create());

                        return;
                    }

                    for (final MIObject obj : parentList) {

                        builder.addErrorMissingObject(obj, data.getDefRef());
                    }

                }

            }

        } catch (final RuntimeException ex) {
            InterruptedRuntimeException.throwExceptionIfRootCauseWasInterruptedException(ex);
            logger.debug("Could not add MDFObjects to result of caught exception. Because thrown exception during addMdfObjects().", ex);
        }
    }

    /**
     * @param data
     * @return
     */
    private static List<? extends MIObject> searchForAnyParentByDefinition(IProjectContext projectContext, IExData data) {
        final IModelAccess modelAccess = projectContext.getService(IModelAccess.class);

        DefRef defRef = data.getDefRef();
        DefRef parentDefRef = null;
        if (defRef != null) {

            while (true) {

                try {
                    parentDefRef = defRef.getParentDefRef();
                } catch (final RuntimeException ex) {
                    InterruptedRuntimeException.throwExceptionIfRootCauseWasInterruptedException(ex);
                    logger.debug(ex);
                }

                if (parentDefRef == null || parentDefRef == defRef) {
                    break;
                }
                final List<MIHasDefinition> allWithDefinition = modelAccess.getAllWithDefinition(parentDefRef);
                if (!allWithDefinition.isEmpty()) {
                    return allWithDefinition;
                }

                defRef = parentDefRef;
            }
        }

        /*
         * Return null to indicate no Parent found
         */
        return null;
    }
}
