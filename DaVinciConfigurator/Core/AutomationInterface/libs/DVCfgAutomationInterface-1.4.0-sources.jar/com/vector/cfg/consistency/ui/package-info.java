/**
 * This package contains interfaces for the UI. This includes domain-objects of the consistency, e.g. {@link com.vector.cfg.consistency.ui.IValidationResultUI
 * IValidationResultUI} or {@link com.vector.cfg.consistency.ui.ISolvingActionUI ISolvingActionUI}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
package com.vector.cfg.consistency.ui;
