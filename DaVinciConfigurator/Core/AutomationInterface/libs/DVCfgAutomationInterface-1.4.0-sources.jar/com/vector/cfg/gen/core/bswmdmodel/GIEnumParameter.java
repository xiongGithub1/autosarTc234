package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasIllegalValueException;
import com.vector.cfg.gen.core.utils.formatting.primitives.EnumGenElement;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucEnumDefinition;
import com.vector.cfg.model.enums.IModelEnum;
import com.vector.cfg.model.enums.ModelEnumUtil;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.view.config.IModelView;

/**
 * Base interface of eumeration bswmd model parameter.
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 *
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF name schema
public interface GIEnumParameter extends GIParameter<String> {
    // CHECKSTYLE:ON

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    EnumGenElement formatValue();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucEnumDefinition getEcucDefinition();

    /**
     * Gets the value of the GEnumeration as a custom enum literal.
     *
     * <p>
     * If the Class destClass implements the {@link IModelEnum} interface. The literals are mapped via these information form the {@link IModelEnum} interface.
     * </p>
     *
     * @param <CUSTOM_ENUM> the enum class Generic
     * @param destClass the destination enum class
     * @return the literal mapped via the destClass Parameters
     * @see ModelEnumUtil
     * @See {@link IModelEnum}
     * @throws BswmdModelParameterHasIllegalValueException
     * <ul>
     * <li>If the values is not mappable to the custom enum</li>
     * </ul>
     */
    @PublishedMethod
    <CUSTOM_ENUM extends Enum<CUSTOM_ENUM>> CUSTOM_ENUM getAsCustomEnum(Class<CUSTOM_ENUM> destClass);

    /**
     * Returns the related configuration object in the MDF model.
     *
     * <p>
     * Attention: The returned {@link MIObject} could be invisible in the current active {@link IModelView}! You have to check the visibility in the client side code!
     * </p>
     *
     * @return
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    @Override
    MITextualValue getMdfObject();

    /**
     * Convenience method to set the numeric value of the {@link GIEnumParameter}.
     *
     * <p>
     * This method checks if the specified parameters configuration object is available and sets the new value. If the object is missing it is implicitly created in the MDF
     * model.
     * </p>
     *
     * @param newValue
     */
    @PublishedMethod
    void setValueMdf(GIEnumClass newValue);

    /**
     * Convenience method to set the value of the {@link GIEnumParameter}.
     *
     * See {@link GIEnumParameter#setValueMdf(GIEnumClass)} for more details.
     *
     * @param newValue
     */
    @PublishedMethod
    void setValue(GIEnumClass newValue);

    /**
     * {@link GIEnumClass} represent a Enumeration class of the BswmdModel. Every generated enum implements this interface. The {@link GIEnumClass} is used to generate enum like
     * interface for the BaseInterface use case.
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
    // CHECKSTYLE:OFF name schema
    public interface GIEnumClass {
        // CHECKSTYLE:ON

        /*
         * Method section
         */
        /**
         * Returns the name of this enum constant, exactly as declared in its enum declaration.
         *
         * <b>Most programmers should use the {@link #toString} method in preference to this one, as the toString method may return a more user-friendly name.</b> This method is
         * designed primarily for use in specialized situations where correctness depends on getting the exact name, which will not vary from release to release.
         *
         * @return the name of this enum constant
         */
        @PublishedMethod
        String name();

        /**
         * Returns the ordinal of this enumeration constant (its position in its enum declaration, where the initial constant is assigned an ordinal of zero).
         *
         * Most programmers will have no use for this method. It is designed for use by sophisticated enum-based data structures, such as {@link java.util.EnumSet} and
         * {@link java.util.EnumMap}.
         *
         * @return the ordinal of this enumeration constant
         */
        @PublishedMethod
        int ordinal();

        /**
         * Returns the name of this enum constant, as contained in the declaration. This method may be overridden, though it typically isn't necessary or desirable. An enum type
         * should override this method when a more "programmer-friendly" string form exists.
         *
         * @return the name of this enum constant
         */
        @Override
        String toString();

        /**
         * Returns true if the specified object is equal to this enum constant.
         *
         * @param other the object to be compared for equality with this object.
         * @return true if the specified object is equal to this enum constant.
         */
        @Override
        boolean equals(Object other);

        /**
         * Returns the name of the AUTOSAR enum type as string.
         *
         * @return the typename
         */
        @PublishedMethod
        String getTypename();

        /**
         * Returns the LongName of the AUTOSAR definition.
         *
         * @return the long name
         */
        @PublishedMethod
        String getLongName();

        /**
         * Returns a hash code for this enum constant.
         *
         * @return a hash code for this enum constant.
         */
        @Override
        @PublishedMethod
        int hashCode();

        /**
         * Returns <code>true</code>, if the passed {@link MITextualValue} has the value of <code>this</code> Enum literal, otherwise false.
         *
         *
         * @param mdfTextualValue The {@link MITextualValue}, which is a enumeration parameter.
         * @return true, if the parameter has the value, otherwise false.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the mdfTextualValue is null</li>
         * </ul>
         */
        @PublishedMethod
        boolean isValueOf(MITextualValue mdfTextualValue);

        /**
         * Returns <code>true</code>, if the passed {@link GIEnumParameter} has the values of <code>this</code> Enum literal, otherwise false.
         *
         *
         * @param enumParameter The {@link GIEnumParameter}, which is a enumeration parameter.
         * @return true, if the parameter has the value, otherwise false.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the mdfTextualValue is null</li>
         * </ul>
         */
        @PublishedMethod
        boolean isValueOf(GIParameter<String> enumParameter);

    }
}
