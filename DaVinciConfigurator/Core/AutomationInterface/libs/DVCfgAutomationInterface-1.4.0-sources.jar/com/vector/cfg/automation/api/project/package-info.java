/**
 * Project handling comprises creating new projects, opening existing projects or accessing the currently active project.
 * <div class="extdoc" id="ProjectHandling"><!--Label:ProjectHandling-->Project handling comprises creating new projects, opening existing projects or accessing the currently
 * active project.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.automation.api.project;