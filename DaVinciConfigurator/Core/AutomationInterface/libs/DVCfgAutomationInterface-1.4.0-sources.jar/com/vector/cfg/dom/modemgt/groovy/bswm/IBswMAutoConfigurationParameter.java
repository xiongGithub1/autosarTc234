package com.vector.cfg.dom.modemgt.groovy.bswm;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;

/**
 * {@link IBswMAutoConfigurationFeature} provides read-access to a BswM auto configuration parameter.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswMAutoConfigurationParameter extends IBswMAutoConfigurationElement {

    /**
     * {@link #getValue()} returns the BswM auto configuration parameter's value. Values can be {@link Boolean}s, {@link BigInteger}s, {@link BigDecimal}s, {@link String}s and
     * {@link MIReferrable}s.
     *
     * @return the BswM auto configuration parameter's value
     */
    @PublishedMethod
    Object getValue();

}
