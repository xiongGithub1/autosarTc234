package com.vector.cfg.model.access;

import static com.google.common.base.Preconditions.checkArgument;
import static com.vector.davinci.util.base.VUtil.uncheckedCast;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import com.google.common.base.Optional;
import com.google.common.base.Strings;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.exceptions.InvisibleVariantObjectException;
import com.vector.cfg.model.exceptions.MultipleVariantObjectsException;
import com.vector.cfg.model.internal.access.ModelInternalUtil;
import com.vector.cfg.model.internal.access.ObjectLinkFeatureData;
import com.vector.cfg.model.internal.access.ObjectLinkParameterData;
import com.vector.cfg.model.internal.access.ObjectLinkVarianceData;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.base.MIAUTOSAR;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManagerCoreInternal;
import com.vector.cfg.model.view.config.variant.IPredefinedVariantView;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.autosar.AutosarUtil;
import com.vector.cfg.util.testing.IMockProvider;

/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation">
 * <h2>AsrObjectLink</h2> <!--LaTeX: \label{sec:AsrObjectLink} --> This class implements an immutable identifier for AUTOSAR objects.
 * <p>
 * An {@link AsrObjectLink} can be created for each object in the MDF AUTOSAR model tree. The main use case of object links is to identify an object unambiguously at a specific
 * point in time for logging reasons. Additionally and under specific conditions it is also possible to find the related MDF object using its AsrObjectLink instance. But this
 * search-by-link cannot be guaranteed after model changes (details and restrictions below).
 * </p>
 *
 * <h3>Object links depend on the MDF object type</h3>
 * <ul>
 * <li><b>Referrables</b><br/>
 * The object link is actually identical with the AUTOSAR path</li>
 * <li><b>Ecuc objects with a definition</b> (module, container and parameter)<br/>
 * The object link additionally stores the DefRef</li>
 * <li><b>Ecuc parameters</b><br/>
 * The object link additionally stores the parameters index. This is the index of all parameters with the same definition below the same parent container instance in the
 * unfiltered model view</li>
 * <li><b>All other types - feature object link</b><br/>
 * The object link also describe paths to all other types in the model by the meta model feature name prefixed with an <code>@featureName</code>. If the feature is a
 * {@link List} the feature name is post fixed with the position of the {@link List}. The link can also contain variant information. Examples:
 * <ul>
 * <li><code>/ActiveEcuC/Can/CanConfigSet/@adminData</code></li>
 * <li><code>/ActiveEcuC/Can/CanConfigSet/@adminData/@docRevision[2]</code></li>
 * </ul>
 *
 * </li>
 * </ul>
 *
 * <h3>Restrictions of object links</h3>
 * <ul>
 * <li>They are immutable and will therefore become invalid when the model changes</li>
 * <li>So they don't guarantee that the related MDF object can be retrieved after the model has been changed. Search-by-link may even find another object or throw an exception
 * in this case</li>
 * </ul>
 *
 * <h3>Examples for object link strings</h3> The method {@link #getObjectLinkString()} returns for example the following strings:
 * <ul>
 * <li>For a container, module configuration or all other {@link MIReferrable} objects, the AUTOSAR path is returned: <br>
 * <code>/ActiveEcuC/Can/CanGeneral</code></li>
 * <li>For a parameter, the parents AUTOSAR path, the last shortname of its definition and a positional index in the list of parameters with the same definition is used:<br>
 * <code>/ActiveEcuC/Can/CanGeneral[2:SomeDefName]</code></li>
 * <li>In case of variant objects, all variants, this object is visible in, are added:<br>
 * <code>/ActiveEcuC/Can/CanConfigSet/CanHardwareObject[0:CanControllerRef]{VariantA, VariantB}</code></li>
 * <li>For all other elements a feature object link is created:<br>
 * <code>/ActiveEcuC/Can/CanConfigSet/@adminData/@docRevision[2]</code></li>
 * </ul>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@Immutable
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class AsrObjectLink implements IDebugable {

    private static final String PATH_SEP_STR = "/";

    private static final char PATH_SEP_CHAR = '/';

    private static final String REMOVED = "<REMOVED>";

    private static final String NO_SHORTNAME = "<NO-SHORTNAME>";

    private static final String NO_PARENT = ObjectLinkFeatureData.NO_PARENT;

    private static final String NO_ROOT = "<NO-ROOT>";

    private final String bestEffortPath;

    private final AsrPath asrPath;

    private final ObjectLinkParameterData parameterData;

    private final ObjectLinkVarianceData varianceData;

    private final boolean isParameterValueLink;

    private final boolean isReferrableLink;

    private final ObjectLinkFeatureData featureData;

    /**
     * Returns the object link of the specified object as an instance of {@link TypedAsrObjectLink}.
     *
     * <p>
     * The {@link AsrObjectLink#create(MIObject)} supports the {@link IMockProvider} interface. See IMockProvider for more details.
     * </p>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return
     * @throws IllegalArgumentException if the object is <code>null</code> or the link cannot be created for other reasons.
     */
    @PublishedMethod
    @ReworkThisAtNextBreakingChange("Return TypedAsrObjectLink instead of AsrObjectLink")
    // public static <T extends MIObject> TypedAsrObjectLink<T> create(final T obj) {
    public static AsrObjectLink create(MIObject obj) {
        if (obj == null) {
            throw new IllegalArgumentException("obj is null");
        }

        try {
            final AsrObjectLink link = createInternal(obj);
            if (link == null) {
                throw new IllegalArgumentException("cannot create object link");
            }
            return link;
        } catch (final IllegalStateException | InvisibleVariantObjectException | IllegalArgumentException ex) {
            throw new IllegalArgumentException("cannot create object link", ex);
        }
    }

    private static <T extends MIObject> AsrObjectLink createInternal(final T obj) {
        if (obj == null) {
            return null;
        }
        if (obj instanceof IMockProvider) {
            final AsrObjectLink linkMock = handleMockedMDFObjects((IMockProvider) obj);
            if (linkMock != null) {
                return linkMock;
            }
        }

        final boolean isParameterValueLink = obj instanceof MIParameterValue;
        final boolean isReferrableLink = obj instanceof MIReferrable;

        if (ModelAccessUtil.isRemovedOnly(obj)) {
            final Class<? extends MIObject> clazz = getMetaModelClass(obj);
            return new TypedAsrObjectLink<>(REMOVED, isParameterValueLink, isReferrableLink, clazz);
        }

        final IProjectContext projectContext = ModelAccessUtil.getProjectContext(obj);
        final IModelViewManagerCoreInternal mvm = projectContext.getService(IModelViewManagerCoreInternal.class);

        try (IModelViewExecutionContext ctx = mvm.executeUnfiltered()) {

            if (isReferrableLink) {
                return createReferrableObjectLink(mvm, (MIReferrable) obj);
            } else if (isParameterValueLink) {
                return createParameterObjectLink(projectContext, mvm, (MIParameterValue) obj);
            }

            return createFeatureObjectLink(mvm, obj);
        }

    }

    /**
     * Returns the object link of the specified object as an instance of {@link TypedAsrObjectLink} or <code>null</code> if the specified object reference is <code>null</code>
     * or if it is not an AUTOSAR object.
     *
     * <p>
     * The {@link AsrObjectLink#tryCreate(MIObject)} supports the {@link IMockProvider} interface. See IMockProvider for more details.
     * </p>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return
     */
    @PublishedMethod
    @ReworkThisAtNextBreakingChange("Return TypedAsrObjectLink instead of AsrObjectLink")
    // public static <T extends MIObject> TypedAsrObjectLink<T> tryCreate(T obj) {
    public static AsrObjectLink tryCreate(MIObject obj) {
        if (obj == null) {
            return null;
        }
        try {
            final AsrObjectLink link = createInternal(obj);
            return link;
        } catch (final IllegalStateException | InvisibleVariantObjectException | IllegalArgumentException ex) {
            return null;
        }
    }

    /**
     * Tries to create a {@link TypedAsrObjectLink} from the mocked {@link IMockProvider}.
     *
     * <p>
     * If the mdfObj does not support creation of a {@link TypedAsrObjectLink}, no {@link IllegalArgumentException} is thrown!
     * </p>
     *
     * @param mdfObj the MockObject
     * @return the {@link TypedAsrObjectLink} of the mocked obj, or null if no link was mocked.
     */
    private static AsrObjectLink handleMockedMDFObjects(final IMockProvider mdfObj) {
        AsrObjectLink link = mdfObj.get(TypedAsrObjectLink.class);
        if (link == null) {
            link = mdfObj.get(AsrObjectLink.class);
        }
        return link;
    }

    private static <T extends MIObject> Class<T> getMetaModelClass(MIObject obj) {
        return uncheckedCast(obj.mdfGetInterfaceClass());
    }

    /**
     * This is no parameter and no referrable. All other MDF types are created an a feature object link.
     *
     * @param mvm
     * @param obj
     * @return the object link
     */
    private static <T extends MIObject> TypedAsrObjectLink<T> createFeatureObjectLink(IModelViewManagerCoreInternal mvm, MIObject obj) {
        if (ModelInternalUtil.isMemberOfModelTreeOutsideAutosarModel(obj)) {
            return null;
        }
        final ObjectLinkFeatureData featureData = ObjectLinkFeatureData.valueOf(mvm, obj);
        final Class<T> clazz = getMetaModelClass(obj);
        final TypedAsrObjectLink<T> link = new TypedAsrObjectLink<>(featureData, clazz);
        return link;

    }

    private static <T extends MIObject> TypedAsrObjectLink<T> createParameterObjectLink(IProjectContext projectContext, IModelViewManagerCoreInternal mvm, MIParameterValue obj) {
        final ObjectLinkVarianceData variance = ObjectLinkVarianceData.valueOf(mvm, obj);
        final String path = getBestEffortPath(obj);
        final ObjectLinkParameterData parameterData = ObjectLinkParameterData.valueOf(projectContext, obj);
        final Class<T> clazz = getMetaModelClass(obj);
        final TypedAsrObjectLink<T> link = new TypedAsrObjectLink<>(path, parameterData, variance, clazz);
        return link;
    }

    private static <T extends MIObject> TypedAsrObjectLink<T> createReferrableObjectLink(IModelViewManagerCoreInternal mvm, MIReferrable obj) {
        final ObjectLinkVarianceData variance = ObjectLinkVarianceData.valueOf(mvm, obj);
        final String path = getBestEffortPath(obj);
        final Class<T> clazz = getMetaModelClass(obj);
        final TypedAsrObjectLink<T> link = new TypedAsrObjectLink<>(path, variance, clazz);
        return link;
    }

    private static String getBestEffortPath(MIObject obj) {
        if (obj instanceof MIReferrable) {
            return getBestEffortPathOfReferrable((MIReferrable) obj);
        }
        final MIObject parent = obj.miImmediateComposite();
        if (parent == null) {
            return NO_PARENT;
        }
        return getBestEffortPath(parent);
    }

    private static String getBestEffortPathOfReferrable(MIReferrable obj) {
        MIObject refObject = obj;
        final StringBuilder path = new StringBuilder();
        boolean reachedRootObj = false;
        do {
            if (refObject instanceof MIReferrable) {
                obj = (MIReferrable) refObject;
                final String name = obj.getName();
                if (name == null || name.isEmpty()) {
                    path.insert(0, NO_SHORTNAME);
                } else {
                    path.insert(0, name);
                }
                path.insert(0, PATH_SEP_CHAR);
            }
            if (refObject instanceof MIAUTOSAR) {
                reachedRootObj = true;
            } else {
                refObject = refObject.miImmediateComposite(); // get parent object
                if (refObject == null) {
                    // Object not contained in the model hierarchy
                    path.insert(0, NO_ROOT);
                    return path.toString();
                }
            }
        } while (!reachedRootObj);

        return path.toString();
    }

    /**
     * Parses the string and returns the link.
     *
     * @param linkAsString
     * @return
     * @throws IllegalArgumentException if the string is <code>null</code> or the link cannot be created (e.g. wrong string format).
     */
    @PublishedMethod
    public static AsrObjectLink create(String linkAsString) {
        if (linkAsString == null) {
            throw new IllegalArgumentException("linkAsString is null");
        }
        linkAsString = linkAsString.trim();
        if (linkAsString.isEmpty()) {
            throw new IllegalArgumentException("linkAsString is empty");
        }

        final AsrObjectLink link = tryCreate(linkAsString);
        if (link == null) {
            throw new IllegalArgumentException("cannot create object link");
        }

        return link;
    }

    /**
     * Parses the string and returns the link or <code>null</code> if the link cannot be created (e.g. wrong string format).
     *
     * @param linkAsString
     * @return
     */
    @PublishedMethod
    public static AsrObjectLink tryCreate(String linkAsString) {
        if (linkAsString == null) {
            return null;
        }
        linkAsString = linkAsString.trim();
        if (linkAsString.isEmpty()) {
            return null;
        }

        if (REMOVED.equals(linkAsString)) {
            return new AsrObjectLink(REMOVED);
        } else if (NO_PARENT.equals(linkAsString) || NO_ROOT.equals(linkAsString) || NO_SHORTNAME.equals(linkAsString)) {
            return null;
        }

        final ObjectLinkFeatureData featureData = ObjectLinkFeatureData.valueOf(linkAsString);
        if (!featureData.isValid()) {
            return null; // Format error
        }
        if (!featureData.isEmpty()) {
            return new AsrObjectLink(featureData);
        }

        final ObjectLinkParameterData paramData = ObjectLinkParameterData.valueOf(linkAsString);
        final ObjectLinkVarianceData varData = ObjectLinkVarianceData.valueOf(linkAsString);

        if (!paramData.isValid() || !varData.isValid()) {
            return null; // Format error
        }

        final boolean isParameterValueLink = ObjectLinkParameterData.containsParameterData(linkAsString);

        // Get the best effort prefix (usually the AUTOSAR path)
        String bestEffortPath = null;
        if (isParameterValueLink) {
            bestEffortPath = ObjectLinkParameterData.getContainerPath(linkAsString);
        } else {
            if (!varData.isEmpty()) {
                bestEffortPath = ObjectLinkVarianceData.getContainerPath(linkAsString);
            }
        }
        if (bestEffortPath == null) {
            bestEffortPath = linkAsString;
        }

        if (!isValidBestEffortPath(bestEffortPath)) {
            return null;
        }

        if (isParameterValueLink) {
            return new AsrObjectLink(bestEffortPath, paramData, varData);
        } else {
            return new AsrObjectLink(bestEffortPath, varData);
        }
    }

    private static boolean isValidBestEffortPath(String bestEffortPath) {
        if (bestEffortPath.equals(PATH_SEP_STR)) {
            return false; // Invalid absolute path
        }
        if (!bestEffortPath.startsWith(PATH_SEP_STR)) {
            final boolean startsWithSpecialCasePrefix = bestEffortPath.startsWith(REMOVED) ||
                    bestEffortPath.startsWith(NO_PARENT) ||
                    bestEffortPath.startsWith(NO_ROOT) ||
                    bestEffortPath.startsWith(NO_SHORTNAME);
            return startsWithSpecialCasePrefix;
        }

        return true;
    }

    /**
     * Constructor for special cases.
     *
     * @param bestEffortPath
     */
    AsrObjectLink(String bestEffortPath) {
        this(bestEffortPath, false, false);
    }

    /**
     * Constructor for special cases (e.g. removed objects).
     *
     * @param bestEffortPath
     */
    AsrObjectLink(String bestEffortPath, boolean isParameterValueLink, boolean isReferrableLink) {
        checkArgument(bestEffortPath != null, "bestEffortPath is null");

        this.bestEffortPath = bestEffortPath;
        if (isValidShortnamePath(bestEffortPath)) {
            this.asrPath = AsrPath.create(bestEffortPath);
        } else {
            this.asrPath = null;
        }
        this.parameterData = ObjectLinkParameterData.empty();
        this.varianceData = ObjectLinkVarianceData.empty();
        this.isParameterValueLink = isParameterValueLink;
        this.isReferrableLink = isReferrableLink;

        this.featureData = ObjectLinkFeatureData.empty();
    }

    /**
     * Constructor for {@link MIReferrable} links.
     *
     * @param bestEffortPath
     * @param variantNames
     */
    AsrObjectLink(String bestEffortPath, ObjectLinkVarianceData variantData) {
        checkArgument(bestEffortPath != null, "bestEffortPath is null");
        checkArgument(variantData != null, "variantData is null");

        this.bestEffortPath = bestEffortPath;
        if (isValidShortnamePath(bestEffortPath)) {
            this.asrPath = AsrPath.create(bestEffortPath);
        } else {
            this.asrPath = null;
        }
        this.parameterData = ObjectLinkParameterData.empty();
        this.varianceData = variantData;
        this.isParameterValueLink = false;
        this.isReferrableLink = true;

        this.featureData = ObjectLinkFeatureData.empty();
    }

    /**
     * Constructor for {@link MIParameterValue} links.
     *
     * @param bestEffortPath
     * @param parameterData
     * @param variantNames
     */
    AsrObjectLink(String bestEffortPath, ObjectLinkParameterData parameterData, ObjectLinkVarianceData variantData) {
        checkArgument(bestEffortPath != null, "bestEffortPath is null");
        checkArgument(parameterData != null, "parameterData is null");
        checkArgument(variantData != null, "variantData is null");
        if (parameterData.getIndex() != null) {
            checkArgument(parameterData.getDefinitionShortname() != null, "definitionShortname is null but index is not");
        }

        this.bestEffortPath = bestEffortPath;
        if (isValidShortnamePath(bestEffortPath)) {
            this.asrPath = AsrPath.create(bestEffortPath);
        } else {
            this.asrPath = null;
        }
        this.parameterData = parameterData;
        this.varianceData = variantData;
        this.isParameterValueLink = true;
        this.isReferrableLink = false;

        this.featureData = ObjectLinkFeatureData.empty();
    }

    /**
     * Constructor for types which are not parameters and not referrables.
     *
     * @param parentLink
     * @param isImmediateParent
     * @param otherObjType
     */
    AsrObjectLink(ObjectLinkFeatureData featureData) {
        checkArgument(featureData != null, "featureData is null");

        this.featureData = featureData;

        this.bestEffortPath = ""; // To avoid null
        this.asrPath = null;
        this.parameterData = ObjectLinkParameterData.empty();
        this.varianceData = featureData.getVarianceData();
        this.isParameterValueLink = false;
        this.isReferrableLink = false;
    }

    /**
     * Check these conditions.
     * <ul>
     * <li>Is an absolute AUTOSAR path</li>
     * <li>Does not contain {@link #NO_SHORTNAME}</li>
     * </ul>
     *
     * @param path
     * @return
     */
    private boolean isValidShortnamePath(String path) {
        if (path == null) {
            return false;
        }
        path = path.trim();
        if (path.isEmpty()) {
            return false;
        }
        if (path.charAt(0) != PATH_SEP_CHAR) {
            return false;
        }
        if (path.contains(NO_SHORTNAME)) {
            return false;
        }
        return true;
    }

    /**
     * Returns the AUTOSAR path of this object (if it is a referrable) or of its closest parent referrable (if not). Returns <code>null</code> if no such AUTOSAR path is
     * available.
     *
     * @return
     */
    @PublishedMethod
    public AsrPath getAsrPath() {
        if (!featureData.isEmpty() && featureData.hasParentLink()) {
            final AsrObjectLink parentLink = featureData.getParentLink();
            return parentLink.getAsrPath();
        }
        return asrPath;
    }

    /**
     * Returns the parent object link if available.
     *
     * @return
     */
    @PublishedMethod
    public Optional<AsrObjectLink> getParentLink() {
        if (!featureData.isEmpty()) {
            return Optional.fromNullable(featureData.getParentLink());
        }

        if (isParameterValueLink) {
            final AsrObjectLink link = tryCreate(bestEffortPath);
            return Optional.fromNullable(link);
        } else if (isReferrableLink) {
            final String parentLinkPath = getParentLinkPathForReferrable();
            final AsrObjectLink link = tryCreate(parentLinkPath);
            return Optional.fromNullable(link);
        }

        return Optional.absent();
    }

    private String getParentLinkPathForReferrable() {
        if (asrPath == null) {
            if (bestEffortPath != null && bestEffortPath.charAt(0) == PATH_SEP_CHAR) {
                final String parentPath = AutosarUtil.getPathWithoutLastShortname(bestEffortPath);
                if (!Strings.isNullOrEmpty(parentPath)) {
                    return parentPath;
                }
            }
        } else {
            final AsrPath parentAsrPath = asrPath.getParentAsrPath();
            if (parentAsrPath != null) {
                return parentAsrPath.getAutosarPathString();
            }
        }
        return null;
    }

    /**
     * Returns all variant names, the object is visible in. If the object is visible in all variants (the object is invariant), this collection is empty. It never returns
     * <code>null</code>.
     *
     * @return
     */
    @Nonnull
    @PublishedMethod
    public List<String> getVariantNames() {
        return varianceData.getVariantNames();
    }

    /**
     * Returns <code>true</code> if the related object is removed from the MDF model.
     *
     * @return
     */
    @PublishedMethod
    public boolean isRemoved() {
        return bestEffortPath == REMOVED;
    }

    /**
     * Returns <code>true</code> if the related MDF model object is visible in all variants.
     *
     * @return
     */
    @PublishedMethod
    public boolean isInvariant() {
        return !varianceData.hasVariants() && !varianceData.isNeverVisible();
    }

    /**
     * Returns <code>true</code> if the related MDF model object is an instance of {@link MIParameterValue}.
     *
     * @return
     */
    @PublishedMethod
    public boolean isParameterValueLink() {
        return isParameterValueLink;
    }

    /**
     * Returns <code>true</code> if the related MDF model object is an instance of {@link MIReferrable}.
     *
     * @return
     */
    @PublishedMethod
    public boolean isReferrableLink() {
        return isReferrableLink;
    }

    /**
     * If the related model object is an instance of {@link MIParameterValue}, this method returns the shortname of the parameters definition.
     *
     * @return
     */
    @PublishedMethod
    public Optional<String> getParameterDefinitionShortname() {
        if (parameterData.hasWrongDefinition()) {
            return Optional.absent();
        }
        return Optional.fromNullable(parameterData.getDefinitionShortname());
    }

    /**
     * If the related model object is an instance of {@link MIParameterValue}, this method returns the parameters index. This is the index of all parameters with the same
     * definition below the same parent container instance in the unfiltered model view.
     *
     * @return
     */
    @PublishedMethod
    public Optional<Integer> getParameterIndex() {
        return Optional.fromNullable(parameterData.getIndex());
    }

    /**
     * Returns an AUTOSAR object which matches this link. See {@link AsrObjectLink} for details about restrictions of retrieving objects by link.
     * <p>
     * <b>Remarks concerning variance:</b>
     * <ul>
     * <li>When the link contains a variance part ("{variantA}" for example) the object is being retrieved with this visibility. The returned object may therefore be invisible
     * for the caller</li>
     * <li>When the link contains no variance part the object is being retrieved within the callers model view</li>
     * </ul>
     * </p>
     *
     * @param projectContext
     * @return
     * @throws IllegalArgumentException if the project context is <code>null</code> or disposed
     * @throws MultipleVariantObjectsException if more than one object have been found
     */
    @PublishedMethod
    public Optional<MIObject> getAutosarObject(final IProjectContext projectContext) {
        if (projectContext == null) {
            throw new IllegalArgumentException("projectContext is null");
        }
        if (projectContext.isDisposed()) {
            throw new IllegalArgumentException("projectContext is disposed");
        }

        final IModelViewManagerCoreInternal mvm = projectContext.getService(IModelViewManagerCoreInternal.class);
        if (varianceData.hasVariants()) {
            final String firstName = varianceData.getVariantNames().get(0);
            final java.util.Optional<IPredefinedVariantView> variant = mvm.getPredefinedVariantView(firstName);
            if (variant.isPresent()) {
                try (IModelViewExecutionContext ctx = mvm.executeWithModelView(variant.get())) {
                    // Run in the links view
                    return getAutosarObjectInternal(projectContext, mvm);
                }
            }
        } else {
            // Run in the callers view
            return getAutosarObjectInternal(projectContext, mvm);
        }
        return Optional.absent();
    }

    private Optional<MIObject> getAutosarObjectInternal(IProjectContext projectContext, IModelViewManagerCoreInternal mvm) {
        if (!featureData.isEmpty()) {
            return getFeatureObject(projectContext, mvm);
        }

        if (asrPath != null) {
            if (isReferrableLink) {
                return getReferrableObject(projectContext, mvm);
            } else if (isParameterValueLink) {
                return getParameterObject(projectContext, mvm);
            }
        }
        return Optional.absent();
    }

    private Optional<MIObject> getFeatureObject(IProjectContext projectContext, IModelViewManagerCoreInternal mvm) {
        final AsrObjectLink parentLink = featureData.getParentLink();
        if (parentLink != null) {
            final Optional<MIObject> parentOpt = parentLink.getAutosarObject(projectContext);
            if (parentOpt.isPresent()) {
                final String featureName = featureData.getFeatureName();

                final MIObject parent = parentOpt.get();
                final Object childObj;
                try {
                    childObj = parent.mdfGetValue(featureName);
                } catch (final IllegalArgumentException ex) {
                    return Optional.absent();
                }
                if (childObj instanceof List && featureData.getIndex().isPresent()) {
                    final int idx = featureData.getIndex().get();
                    if (idx >= 0) {
                        final List<Object> childList = uncheckedCast(childObj);
                        if (childList.size() > idx) {
                            final Object obj = childList.get(idx);
                            if (obj instanceof MIObject) {
                                return Optional.of((MIObject) obj);
                            }
                        }
                    }
                }
                if (childObj instanceof MIObject && !featureData.getIndex().isPresent()) {
                    return Optional.of((MIObject) childObj);
                }
            }
        }
        return Optional.absent();
    }

    private Optional<MIObject> getParameterObject(IProjectContext projectContext, IModelViewManagerCoreInternal mvm) {
        final MIReferrable referrable = asrPath.getAutosarObject(projectContext);
        if (referrable == null) {
            return Optional.absent();
        }
        if (referrable instanceof MIContainer) {
            final Optional<MIObject> parameterOpt = getParameterObject(mvm, projectContext.getService(IModelAccess.class), (MIContainer) referrable);
            if (parameterOpt.isPresent()) {
                if (isInvariant() || isVisibleInAllMyVariants(mvm, parameterOpt.get())) {
                    return parameterOpt;
                }
            }
        }

        return Optional.absent();
    }

    private Optional<MIObject> getParameterObject(IModelViewManagerCoreInternal mvm, IModelAccess ma, MIContainer container) {
        if (Strings.isNullOrEmpty(parameterData.getDefinitionShortname())) {
            return Optional.absent(); // No defintion specified
        }
        int i = 0; // default
        if (parameterData.getIndex() != null) {
            i = parameterData.getIndex().intValue();
        }

        // Handle the index in the unfiltered view!
        try (IModelViewExecutionContext ctx = mvm.executeUnfiltered()) {
            final List<MIHasDefinition> children = ma.getChildrenByDefinition(container, parameterData.getDefinitionShortname());
            final List<MIParameterValue> parameters = ModelInternalUtil.filterChildrenOfType(container, children, MIParameterValue.class, false);

            if (parameters.size() <= i) {
                return Optional.absent();
            }
            return Optional.of(parameters.get(i));
        }
    }

    private Optional<MIObject> getReferrableObject(IProjectContext projectContext, IModelViewManagerCoreInternal mvm) {
        final MIReferrable referrable = asrPath.getAutosarObject(projectContext);
        if (referrable == null) {
            return Optional.absent();
        }
        if (isVisibleInAllMyVariants(mvm, referrable)) {
            return Optional.of(referrable);
        }
        return Optional.absent();
    }

    /**
     * Returns <code>true</code> if the set of variants, the specified object is visible in, is a superset of the variants specified in the link.
     *
     * @param mvm
     * @param obj
     * @return
     */
    private boolean isVisibleInAllMyVariants(IModelViewManagerCoreInternal mvm, MIObject obj) {
        if (mvm.isModelInvariant(obj)) {
            return true;
        }
        final ObjectLinkVarianceData variance = ObjectLinkVarianceData.valueOf(mvm, obj);
        final boolean isSuperset = variance.getVariantNames().containsAll(varianceData.getVariantNames());
        return isSuperset;
    }

    /**
     * Creates a string representation of the object link.
     * <p>
     * <b>Examples:</b>
     * <ul>
     * <li>For a container or module configuration object, the AUTOSAR path is returned - "/MICROSAR/A/B"</li>
     * <li>For a parameter, the parents AUTOSAR path, the last shortname of its definition and a positional index in the list of parameters with the same definition is used -
     * "/MICROSAR/A/B[2:SomeDefName]"</li>
     * </ul>
     * </p>
     *
     * <p>
     * For objects which are neither parameters nor referrables, the method returns the AUTOSAR path of the first referrable parent object on the root path plus some type
     * information of the object itself.
     * </p>
     *
     * <p>
     * If an object is not visible in all variants, the variant name is added to this link (sorted alphabetically).
     * </p>
     * <p>
     * <b>Examples:</b>
     * <ul>
     * <li>/ActiveEcuC/Can/CanConfigSet/CanHardwareObject[0:CanControllerRef]{VariantA}</li>
     * <li>/ActiveEcuC/Can/CanConfigSet/CanHardwareObject[0:CanControllerRef]{VariantA,VariantB}</li>
     * </ul>
     * </p>
     *
     * @return
     */
    @PublishedMethod
    public String getObjectLinkString() {
        return getObjectLinkStringInternal(true, true);
    }

    /**
     * Implements the same behavior like {@link #getObjectLinkString()} but omits the final variant part.
     *
     * @return
     */
    @PublishedMethod
    public String getObjectLinkStringWithoutVariant() {
        return getObjectLinkStringInternal(true, false);
    }

    /**
     * Implements the same behavior like {@link #getObjectLinkString()} but omits the parameter index if all of the following conditions apply.
     * <ul>
     * <li>The object is a parameter</li>
     * <li>This parameters upper-multiplicity is 1</li>
     * <li>There is actually exactly one parameter present</li>
     * </ul>
     *
     * The returned object link can still be used to retrieve the parameter by {@link #getAutosarObject(IProjectContext)} (index 0 is assumed).
     *
     * @return
     */
    @PublishedMethod
    public String getShortObjectLinkString() {
        return getObjectLinkStringInternal(false, true);
    }

    @KeepSecretFromPublishedApi
    public String getShortObjectLinkStringWithoutVariant() {
        return getObjectLinkStringInternal(false, false);
    }

    private String getObjectLinkStringInternal(boolean withOptional0Index, boolean withVariant) {
        if (!featureData.isEmpty()) {
            return getFeatureLinkStringInternal(withOptional0Index, withVariant);
        }

        if (isRemoved()) {
            return bestEffortPath;
        }

        final StringBuilder s = new StringBuilder(bestEffortPath);
        if (isParameterValueLink) {
            parameterData.append(s, withOptional0Index);
        }

        if (withVariant) {
            varianceData.append(s);
        }

        return s.toString();
    }

    private String getFeatureLinkStringInternal(boolean withOptional0Index, boolean withVariant) {
        final StringBuilder s = new StringBuilder();
        featureData.append(s, withOptional0Index, withVariant);
        return s.toString();
    }

    /**
     *
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return getObjectLinkString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toDebugString() {
        return AsrObjectLink.class.getSimpleName() + ": " + getObjectLinkString();
    }

    private static final int prime1231 = 1231;

    private static final int prime1237 = 1237;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asrPath == null) ? 0 : asrPath.hashCode());
        result = prime * result + ((bestEffortPath == null) ? 0 : bestEffortPath.hashCode());
        result = prime * result + (isParameterValueLink ? prime1231 : prime1237);
        result = prime * result + (isReferrableLink ? prime1231 : prime1237);
        result = prime * result + ((featureData == null) ? 0 : featureData.hashCode());
        result = prime * result + ((parameterData == null) ? 0 : parameterData.hashCode());
        result = prime * result + ((varianceData == null) ? 0 : varianceData.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof AsrObjectLink)) {
            return false;
        }
        final AsrObjectLink other = (AsrObjectLink) obj;
        if (asrPath == null) {
            if (other.asrPath != null) {
                return false;
            }
        } else if (!asrPath.equals(other.asrPath)) {
            return false;
        }
        if (bestEffortPath == null) {
            if (other.bestEffortPath != null) {
                return false;
            }
        } else if (!bestEffortPath.equals(other.bestEffortPath)) {
            return false;
        }
        if (isParameterValueLink != other.isParameterValueLink) {
            return false;
        }
        if (isReferrableLink != other.isReferrableLink) {
            return false;
        }
        if (featureData == null) {
            if (other.featureData != null) {
                return false;
            }
        } else if (!featureData.equals(other.featureData)) {
            return false;
        }
        if (parameterData == null) {
            if (other.parameterData != null) {
                return false;
            }
        } else if (!parameterData.equals(other.parameterData)) {
            return false;
        }
        if (varianceData == null) {
            if (other.varianceData != null) {
                return false;
            }
        } else if (!varianceData.equals(other.varianceData)) {
            return false;
        }
        return true;
    }

}
