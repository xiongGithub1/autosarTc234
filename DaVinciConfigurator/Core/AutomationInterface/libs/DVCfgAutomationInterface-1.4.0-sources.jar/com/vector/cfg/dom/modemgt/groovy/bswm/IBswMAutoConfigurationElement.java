package com.vector.cfg.dom.modemgt.groovy.bswm;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.dom.modemgt.groovy.api.IModeManagementApi;

import groovy.lang.Closure;

/**
 * {@link IBswMAutoConfigurationElement} provides read-access to common properties of BswM auto configuration elements ({@link IBswMAutoConfigurationFeature},
 * {@link IBswMAutoConfigurationParameter}, {@link IBswMAutoConfigurationDomain}).
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswMAutoConfigurationElement {

    /**
     * {@link #getIdentifier()} returns this element's id. This id is suitable to be used in calls to:
     * <ul>
     * <li>{@link IModeManagementApi#bswMAutoConfigDomain(String)} and {@link IModeManagementApi#bswMAutoConfigDomain(String, Closure)} for {@link IBswMAutoConfigurationDomain}s
     * </li>
     * <li>{@link IBswMAutoConfigurationDomain#feature(String)}, {@link IBswMAutoConfigurationApi#activate(String)} and {@link IBswMAutoConfigurationApi#deactivate(String)} for
     * {@link IBswMAutoConfigurationFeature}s</li>
     * <li>{@link IBswMAutoConfigurationDomain#parameter(String)} and {@link IBswMAutoConfigurationApi#set(String)} for {@link IBswMAutoConfigurationParameter}s</li>
     * </ul>
     *
     * @return this element's id
     */
    @PublishedMethod
    String getIdentifier();

    /**
     * {@link #isEnabled()} returns {@code true} if the {@link IBswMAutoConfigurationElement} is enabled. For {@link IBswMAutoConfigurationFeature}s this means that the feature
     * can be activated or deactivated. For {@link IBswMAutoConfigurationParameter}s this means that parameter's value can be modified. For {@link IBswMAutoConfigurationDomain}s
     * this means that the domain can be used for performing auto configuration.
     *
     * @return {@code true} if the BswM auto configuration element is enabled
     */
    @PublishedMethod
    boolean isEnabled();

}
