package com.vector.cfg.consistency;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasDescription {
    /**
     * Returns the description of a Solving Action.
     */
    @PublishedMethod
    String getDescription();
}
