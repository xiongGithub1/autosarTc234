package com.vector.cfg.dom.modemgt.groovy.bswm;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IBswMAutoConfigurationDomain} provides read-access to a BswM auto configuration domain.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswMAutoConfigurationDomain extends IBswMAutoConfigurationElement {

    /**
     * {@link #feature(String)} provides read-access (name, enabled state, activation state, sub-features, parameters) to the BswM auto configuration feature with the given
     * identifier.
     *
     * @throws IllegalArgumentException if there is no feature with the given identifier
     * @throws IllegalStateException if the feature with the given identifier is disabled
     */
    @PublishedMethod
    IBswMAutoConfigurationFeature feature(String featureId);

    /**
     * {@link #parameter(String)} provides read-access (name, enabled state, parameter value) to the BswM auto configuration parameter with the given identifier.
     *
     * @throws IllegalArgumentException if there is no feature with the given identifier
     * @throws IllegalStateException if the feature with the given identifier is disabled
     */
    @PublishedMethod
    IBswMAutoConfigurationParameter parameter(String parameterId);

    /**
     * {@link #getRootFeatures()} returns all of this BswM auto configuration domain's root features for inspection.
     *
     * @return all of this BswM auto configuration domain's root features
     */
    @PublishedMethod
    Collection<IBswMAutoConfigurationFeature> getRootFeatures();

}
