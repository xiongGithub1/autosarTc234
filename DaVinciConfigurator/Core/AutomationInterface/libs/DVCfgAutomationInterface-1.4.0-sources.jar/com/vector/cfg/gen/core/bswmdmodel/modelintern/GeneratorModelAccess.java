package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import static com.google.common.base.Preconditions.checkNotNull;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.google.common.collect.Lists;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SACreateContainer;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SACreateParameter;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SetDefaultValue;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SolvingActions;
import com.vector.cfg.consistency.contribution.helper.solvingactions.generic.SADeleteMDFObject;
import com.vector.cfg.consistency.contribution.helper.solvingactions.generic.SASetTextual;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIEnumParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIExceptionCreator;
import com.vector.cfg.gen.core.bswmdmodel.GIHasContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelFactory;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIParamOrRef;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIReference;
import com.vector.cfg.gen.core.bswmdmodel.IGeneratorModelAccess;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelAttributeNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelInvalidRequestException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasIllegalValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasNoValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelReferenceTargetException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelWrongQuantityException;
import com.vector.cfg.gen.core.bswmdmodel.param.GBoolean;
import com.vector.cfg.gen.core.bswmdmodel.param.GChoiceReference;
import com.vector.cfg.gen.core.bswmdmodel.param.GEnumeration;
import com.vector.cfg.gen.core.bswmdmodel.param.GFloat;
import com.vector.cfg.gen.core.bswmdmodel.param.GInstanceReference;
import com.vector.cfg.gen.core.bswmdmodel.param.GInteger;
import com.vector.cfg.gen.core.bswmdmodel.param.GLinkerSymbol;
import com.vector.cfg.gen.core.bswmdmodel.param.GReference;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasValidationOrigin;
import com.vector.cfg.gen.core.utils.exceptions.ModelExceptionProcessor;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucModuleConfiguration;
import com.vector.cfg.model.enums.ModelEnumUtil;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrableARRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIChoiceReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDefARRef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIReferenceParamDef;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.math.MBigDecimal;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.MixedText;
import com.vector.cfg.util.version.IVersion;

/**
 * The abstract base class for bswmd model access class overridden in every generated bswmd model.
 *
 * <p>
 * <b>Attention:</b> DO NOT USE THIS CLASS. THIS CLASS IS INTERNALLY USED!!!
 * </p>
 * <p>
 * Attention: Please use {@link IGeneratorModelAccess} interface in client code.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class GeneratorModelAccess extends AbstractBswmdModelAccess implements IGeneratorModelAccess, GIExceptionCreator, GIModelVerifier {

    /** The Constant logger. */
    private static final ILogger logger = Logger.INSTANCE.createLogger(GeneratorModelAccess.class);

    /**
     * The generator package. This could be null, if the GeneratorModelAccess was created without an IGeneratorPackage.
     */
    private final IGeneratorPackage generatorPackage;

    private final IHasValidationOrigin validationResultOrigin;

    /**
     * Constructor for models with {@link IGeneratorPackage}.
     *
     * @param factory the factory
     * @param generatorPackage the generator package
     */
    @PublishedMethod
    protected GeneratorModelAccess(GIModelFactory factory, IGeneratorPackage generatorPackage) {
        super(factory, factory.getProjectContext());
        this.generatorPackage = generatorPackage;
        this.validationResultOrigin = generatorPackage;
    }

    /**
     * Constructor for models without a {@link IGeneratorPackage}.
     *
     * @param factory the factory
     * @param validationResultOrigin the is insatcne is used, to create {@link IValidationResult}s when an access is incorrect.
     */
    @PublishedMethod
    protected GeneratorModelAccess(GIModelFactory factory, IHasValidationOrigin validationResultOrigin) {
        super(factory, factory.getProjectContext());
        this.validationResultOrigin = checkNotNull(validationResultOrigin);
        this.generatorPackage = null;

    }

    /**
     * Adds the default value solving action.
     *
     * @param builder the builder
     * @param param the param
     */
    private static void addDefaultValueSolvingAction(GeneratorResultBuilder builder, GIParamOrRef param) {
        final ISolvingAction act = SetDefaultValue.create(param.getMdfObject());
        if (act != null) {
            builder.setPreferredSolvingAction(act);
        }
    }

    /**
     * Gets the origin.
     *
     * @return the origin
     */
    private IHasValidationOrigin getOrigin() {
        return validationResultOrigin;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public GIExceptionCreator getExceptionCreator() {
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public GIModelVerifier getModelVerifier() {
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IHasValidationOrigin getValidationResultOrigin() {
        return getOrigin();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void assertArVersionOfBswImplementationIsDefined(GAbstractModuleConfiguration cfg, final IVersion version) {
        if (version == null) {
            /*
             * Report that the version is missing
             */
            final IGeneratorResult resut = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getModelAccessFailureId(getOrigin()),
                            "The BswImplementation Ar Version of the ModuleConfiguration {0} is missing. (ModuleConfig -> BswImplementation -> ArVersion)", cfg)
                    .addErrorObject(cfg).buildResult();
            throw new BswmdModelAttributeNotExistsException(resut, cfg, "The Ar Version missing. (ModuleConfig -> BswImplementation -> ArVersion)",
                    "getBswImplementationArVersion()");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void assertArSchemaVersionOfDefinitionIsDefined(GAbstractModuleConfiguration cfg, final IVersion version) {
        if (version == null) {
            /*
             * Report that the version is missing
             */
            final IGeneratorResult resut = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getModelAccessFailureId(getOrigin()),
                            "The AR schema Version of the ModuleDefiniton of ModuleConfiguration {0} is missing.", cfg)
                    .addErrorObject(cfg).buildResult();
            throw new BswmdModelAttributeNotExistsException(resut, cfg, "The Ar schema Version missing.", "getArDefinitionSchemaVersion()");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void assertSwVersionOfBswImplementationIsDefined(GAbstractModuleConfiguration cfg, final IVersion version) {
        if (version == null) {
            /*
             * Report that the version is missing
             */
            final IGeneratorResult resut = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getModelAccessFailureId(getOrigin()),
                            "The Sw Version of the ModuleConfiguration {0} is missing. (ModuleConfig -> BswImplementation -> SwVersion)", cfg)
                    .addErrorObject(cfg).buildResult();
            throw new BswmdModelAttributeNotExistsException(resut, cfg, "The Sw Version missing. (ModuleConfig -> BswImplementation -> SwVersion)",
                    "getBswImplementationSwVersion()");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public BswmdModelReferenceTargetException issueExceptionBecauseReferencePointsToIncorrectTarget(final GChoiceReference choiceRef, final Class<?> targetClass,
            final DefRef targetDefRef) {

        final MIContainer mdfTarget = choiceRef.getRefTargetMdf();

        final IGeneratorResult genResult = GeneratorResultBuilder
                .newBuilder(CommonGeneratorResultIds.getReferenceHasWrongType(this.getValidationResultOrigin()), "Reference {0} does not point to requested target {1}.",
                        choiceRef, targetDefRef)
                .addErrorObject(choiceRef).addErrorObject(mdfTarget).buildResult();
        throw new BswmdModelReferenceTargetException(genResult, choiceRef);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertConfigVariantNotNull(GAbstractModuleConfiguration moduleConfiguration) {
        final IEcucModuleConfiguration cfg = getEcuConfigurationAccess().cfg(moduleConfiguration.getMdfObject());
        if (!cfg.hasConfigurationVariant()) {

            final IHasValidationOrigin errorOrigin = getOrigin();
            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModelAccessFailureId(errorOrigin),
                    "The ImplementationConfigVariant of the module {0} does not exist.", moduleConfiguration).addErrorObject(moduleConfiguration);

            throw new BswmdModelException(builder.buildResult(), moduleConfiguration);
        }
    }

    @PublishedMethod
    @Override
    public final void assertMdfConfigElementHasCorrectDefinition(MIHasDefinition mdfCfgElement, MIParamConfMultiplicity mdfDefElem, DefRef defRef) {
        if (mdfDefElem == null) {
            final IHasValidationOrigin errorOrigin = getOrigin();
            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getDefinitionMissingForCEErrorId(errorOrigin),
                    "The definition is missing for {0}.", mdfCfgElement).addErrorObject(mdfCfgElement);
            throw new BswmdModelInvalidRequestException(builder.buildResult(), null);
        }

        if (!defRef.isDefinitionOf(mdfCfgElement)) {
            final IHasValidationOrigin errorOrigin = getOrigin();
            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModelAccessFailureId(errorOrigin),
                    "The configration element {0} does not match the definition {1} of the request.", mdfCfgElement, defRef).addErrorObject(mdfCfgElement);
            throw new BswmdModelInvalidRequestException(builder.buildResult(), null);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertContainerNotNull(GIHasContainer parent, GIContainer container, DefRef containerDefRef) {
        if (container == null) {
            final IHasValidationOrigin errorOrigin = getOrigin();
            final GeneratorResultBuilder builder = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getContainerNotExistsId(errorOrigin), "Container {0:lastShortname} does not exist. Element def.:{0:short} Parent: {1}",
                            containerDefRef, parent)
                    .addErrorMissingObject(parent.getMdfObject(), containerDefRef);

            builder.setPreferredSolvingAction(new SACreateContainer(parent.getMdfObject(), containerDefRef));

            throw new BswmdModelNotExistsException(builder.buildResult(), parent, containerDefRef);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertContainerIsExactyOneElement(GIHasContainer parent, List<GIContainer> containerList, DefRef containerDefRef) {
        if (containerList.isEmpty()) {
            assertContainerNotNull(parent, null, containerDefRef);
        } else if (containerList.size() > 1) {
            final GIContainer elem = containerList.get(0);
            assertElementIsTheOnlyElement(parent, elem, elem.getMdfObject());
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertParameterIsExactyOneElement(GIContainer parent, List<? extends GIParameter<?>> childList, DefRef paramDefRef) {

        if (childList.isEmpty()) {
            issueErrorBecauseParameterOrReferenceIsNull(parent, false, paramDefRef);
        } else if (childList.size() > 1) {
            final GIParamOrRef elem = childList.get(0);
            assertElementIsTheOnlyElement(parent, elem, elem.getMdfObject());
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertReferenceIsExactyOneElement(GIContainer parent, List<? extends GIReference<?>> childList, DefRef paramDefRef) {

        if (childList.isEmpty()) {
            issueErrorBecauseParameterOrReferenceIsNull(parent, true, paramDefRef);
        } else if (childList.size() > 1) {
            final GIParamOrRef elem = childList.get(0);
            assertElementIsTheOnlyElement(parent, elem, elem.getMdfObject());
        }
    }

    /**
     * Issue error because parameter or reference not null.
     *
     * @param parent the parent
     * @param isRef the is ref
     * @param paramDefRef the param def ref
     */
    private void issueErrorBecauseParameterOrReferenceIsNull(GIContainer parent, boolean isRef, DefRef paramDefRef) {
        final IHasValidationOrigin errorOrigin = getOrigin();

        final String solvingDescription;
        final GeneratorResultBuilder builder;
        if (!isRef) {
            builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterNotExistsId(errorOrigin),
                    "Parameter {0:lastShortname} does not exist. Element def.: {0:short} Parent: {1}", paramDefRef, parent);
            solvingDescription = "Create Parameter";
        } else {
            builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getReferenceNotExistsId(errorOrigin),
                    "Reference {0:lastShortname} does not exist. Element def.: {0:short}; Parent: {1}", paramDefRef, parent);
            solvingDescription = "Create Reference";
        }
        builder.addErrorMissingObject(parent.getMdfObject(), paramDefRef);
        builder.setPreferredSolvingAction(new SACreateParameter(parent.getMdfObject(), paramDefRef, solvingDescription));

        throw new BswmdModelNotExistsException(builder.buildResult(), parent, paramDefRef);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertParameterOrReferenceNotNull(GIContainer parent, GIParamOrRef parameter) {
        if (!parameter.existsMDF()) {
            boolean isRef = false;
            if (parameter instanceof GIReference<?>) {
                isRef = true;
            }
            issueErrorBecauseParameterOrReferenceIsNull(parent, isRef, parameter.getDefRef());
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertElementIsTheOnlyElement(GIHasContainer parent, GIModelObject elem, MIHasDefinition mdfObj) {

        final List<MIHasDefinition> paramByDef = getMdfModelAccess().getChildrenByDefinition(parent.getMdfObject(), elem.getDefRef());
        if (paramByDef.size() > 1) {
            final IHasValidationOrigin errorOrigin = getOrigin();

            final String solvingDescription;
            final GeneratorResultBuilder builder;
            if (elem instanceof GIParameter) {

                builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterWrongQuantityRequestedId(errorOrigin),
                        "Parameter {0} has the wrong quantity. Expected quantity: One element Actual quantity: Many elements.", mdfObj);
                solvingDescription = "Delete the unnecessary Parameters";
            } else if (elem instanceof GIReference<?>) {
                builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getReferenceWrongQuantityRequestedId(errorOrigin),
                        "Reference {0} has the wrong quantity. Expected quantity: One element Actual quantity: Many elements.", mdfObj);
                solvingDescription = "Delete the unnecessary References";
            } else {
                builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getContainerWrongQuantityRequestedId(errorOrigin),
                        "Container {0} has the wrong quantity. Expected quantity: One element Actual quantity: Many elements.", mdfObj);
                solvingDescription = "Delete the unnecessary Containers";
            }
            builder.addErrorObject(parent).addErrorMdfObjectList(paramByDef);
            final List<MIHasDefinition> deleteList = new ArrayList<>(paramByDef);
            deleteList.remove(mdfObj);
            final List<SADeleteMDFObject> deleteSaList = Lists.newArrayList();
            for (final MIHasDefinition paramToDelete : deleteList) {
                deleteSaList.add(new SADeleteMDFObject(paramToDelete));
            }
            builder.setPreferredSolvingAction(SolvingActions.combine(solvingDescription, deleteSaList));

            throw new BswmdModelWrongQuantityException(builder.buildResult(), parent, elem);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertParameterValueNotNull(GIParameter<?> parameter, Object value) {
        if (value == null) {

            final IHasValidationOrigin errorOrigin = getOrigin();
            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterHasNoValueId(errorOrigin),
                    "Parameter {0:noValue} has no value.", parameter).addErrorObject(parameter);

            addDefaultValueSolvingAction(builder, parameter);

            throw new BswmdModelParameterHasNoValueException(builder.buildResult(), parameter);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertParameterHasLegalValue(GIParameter<?> bswmdParam, String paramType) {
        boolean isLegalValue = true;
        final String valueString;
        if (bswmdParam.getMdfObject() instanceof MINumericalValue) {

            final MINumericalValue numVal = (MINumericalValue) bswmdParam.getMdfObject();

            valueString = ModelUtil.getValueString(numVal);
            if (numVal.getValue() != null) {

                if (bswmdParam instanceof GInteger) {
                    isLegalValue = modelAccess.containsInteger(numVal);
                }

                if (bswmdParam instanceof GFloat) {
                    isLegalValue = checkFloatLegalValue(numVal);
                }

                if (bswmdParam instanceof GBoolean) {
                    isLegalValue = modelAccess.containsBoolean(numVal);
                }

            }
        } else if (bswmdParam.getMdfObject() instanceof MITextualValue) {
            final MITextualValue textVal = (MITextualValue) bswmdParam.getMdfObject();
            valueString = textVal.getValue();
            if (textVal.getValue() != null) {

                if (bswmdParam instanceof GLinkerSymbol) {
                    isLegalValue = ModelUtil.isValidLinkerSymbol(((GLinkerSymbol) bswmdParam).getDefinition(), valueString);

                }
            }
        } else {
            return;
        }

        if (!isLegalValue) {

            // Illegal value found => Report it
            final IHasValidationOrigin errorOrigin = getOrigin();
            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterHasIllegalValue(errorOrigin),
                    "{0} parameter {1} has the illegal value '{2}'.", paramType, bswmdParam, valueString).addErrorObject(bswmdParam);

            addDefaultValueSolvingAction(builder, bswmdParam);

            throw new BswmdModelParameterHasIllegalValueException(builder.buildResult(), bswmdParam, valueString);
        }

    }

    /**
     * Check float legal value.
     *
     * <p>
     * EVAL00117320: General-Arch#247: BswmdModel: getValue() of Float parameter shall throw an IllValEx when INF or NaN is the value
     * </p>
     *
     * @param numVal the num val
     * @return true, if the parameter contains a float value and is no NaN,INF or -INF.
     */
    private boolean checkFloatLegalValue(final MINumericalValue numVal) {

        if (modelAccess.containsFloat(numVal)) {
            /*
             * Check for MBigDecimal
             */
            final BigDecimal value = modelAccess.getAsFloat(numVal);
            if (value != null) {
                if (!(value instanceof MBigDecimal)) {
                    return true;
                }

                final MBigDecimal mvalue = (MBigDecimal) value;
                if (!mvalue.isNaN() && !mvalue.isInfinite()) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertReferencePathNotNull(GIReference<?> reference, String path) {
        if (path == null || path.isEmpty() || path.charAt(0) != '/') {
            final IHasValidationOrigin errorOrigin = getOrigin();
            final IGeneratorResult genResult = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getReferenceFailureId(errorOrigin), "Reference {0} has no valid AUTOSAR target path.", reference)
                    .addErrorObject(reference).buildResult();
            throw new BswmdModelReferenceTargetException(genResult, reference);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertReferenceTargetNotNull(GIReference<?> reference, MIReferrable target) {
        if (target == null) {
            final IHasValidationOrigin errorOrigin = getOrigin();
            final IGeneratorResult genResult = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getReferenceHasNoRefTargetId(errorOrigin), "Reference {0} has no reference target.", reference).addErrorObject(reference)
                    .buildResult();
            throw new BswmdModelReferenceTargetException(genResult, reference);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertReferenceTargetHasCorrectType(GAbstractRefToContainer reference, MIReferrable target, Class<MIContainer> clazz) {
        /*
         * The Target must be an instance of clazz and it must be an instance of MIHasDefinition
         */
        if (!clazz.isInstance(target) || !(target instanceof MIHasDefinition)) {

            final IHasValidationOrigin errorOrigin = getOrigin();
            final IGeneratorResult genResult = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getReferenceHasWrongType(errorOrigin),
                            "Reference {0} has the wrong reference type. Expecting target type: {1} Actual target type: {2}.", reference, clazz.getSimpleName(),
                            target.mdfGetInterfaceClass().getSimpleName())
                    .addErrorObject(reference).addErrorObject(target).buildResult();
            throw new BswmdModelReferenceTargetException(genResult, reference);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertReferenceTargetHasCorrectDefinition(GReference reference, MIReferrable target) {

        MIReferenceParamDef refDefinition = null;
        MIContainerDef referenceDestinationDefinition = null;

        try {
            refDefinition = ((MIReferenceParamDef) (reference.getDefinition()));
            referenceDestinationDefinition = refDefinition.getDestination().getRefTarget();
        } catch (final RuntimeException ex) {
            logger.debug(ex);
        }

        DefRef expectedDefRef = null;
        if (referenceDestinationDefinition != null) {
            expectedDefRef = DefRef.create(referenceDestinationDefinition);
        }

        DefRef actualDefRef = null;
        if (target instanceof MIHasDefinition) {
            actualDefRef = DefRef.tryCreate((MIHasDefinition) target);
        }

        if (expectedDefRef == null || actualDefRef == null) {
            /*
             * Not enough information to check the target types. So assume that the check was correct
             */
            final String message = MessageFormat
                    .format("Warning: The definition {1} of the ReferenceValue {0} has a type destination {2}, but this does not point to a definition in the model. The expected target could not be evaluated. Is the destination BSWMD missing?",
                            reference, ModelAccessUtil.toDebugStringMDFObject(refDefinition), (refDefinition != null) ? (refDefinition.getDestination().getValue()) : "null");
            if (logger.isDebugEnabled()) {
                logger.warn(message, new RuntimeException("StackTrace"));
            } else {
                logger.warn(message);
            }
            return;
        }

        if (!expectedDefRef.equals(actualDefRef) && !actualDefRef.isRefinedOf(expectedDefRef, getMdfModelAccess())) {

            final IHasValidationOrigin errorOrigin = getOrigin();
            final IGeneratorResult genResult = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getReferenceTargetHasWrongDefinition(errorOrigin),
                            "Reference {0} pointing to a target with an invalid definition. Expected definition: {1} Actual definition: {2} Actual target: {3}.", reference,
                            expectedDefRef, actualDefRef, target)
                    .addErrorObject(reference).addErrorObject(target).buildResult();
            throw new BswmdModelReferenceTargetException(genResult, reference);
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertReferenceTargetHasCorrectDefinition(GChoiceReference reference, MIReferrable target) {

        Collection<MIContainerDefARRef> referenceDestinationDefinitionRefList = Collections.emptyList();
        MIChoiceReferenceParamDef refDefinition = null;

        try {
            refDefinition = ((reference.getDefinition()));
            referenceDestinationDefinitionRefList = refDefinition.getDestination();
        } catch (final RuntimeException ex) {
            logger.debug(ex);
            referenceDestinationDefinitionRefList = null;
        }

        final List<DefRef> expectedDefRefList = new ArrayList<>();
        if (referenceDestinationDefinitionRefList != null) {
            for (final MIContainerDefARRef ref : referenceDestinationDefinitionRefList) {
                final MIContainerDef refTarget = ref.getRefTarget();
                if (refTarget != null) {
                    expectedDefRefList.add(DefRef.create(refTarget));
                }
            }

        }

        DefRef actualDefRef = null;
        if (target instanceof MIHasDefinition) {
            actualDefRef = DefRef.create((MIHasDefinition) target);
        }

        if (expectedDefRefList.isEmpty() || actualDefRef == null) {
            /*
             * Not enough information to check the target types. So assume that the check was correct
             */
            final String message = MessageFormat
                    .format("Warning: The definition {1} of the ReferenceValue {0} has the type destinationList ({2}), but none of them pointing to a definition. The expected target could not be evaluated.",
                            reference, ModelAccessUtil.toDebugStringMDFObject(refDefinition), (refDefinition != null) ? (refDefinition.getDestination()) : "null");
            if (logger.isDebugEnabled()) {
                logger.warn(message, new RuntimeException("StackTrace"));
            } else {
                logger.warn(message);
            }
            return;
        }

        if (actualDefRef != null && !expectedDefRefList.isEmpty()) {

            for (final DefRef expectedDefRef : expectedDefRefList) {

                if (expectedDefRef.equals(actualDefRef) || actualDefRef.isRefinedOf(expectedDefRef, getMdfModelAccess())) {
                    /*
                     * The Reference is correct
                     */
                    return;
                }
            }
        }

        /*
         * No correct definition found, so report an error
         */
        final IHasValidationOrigin errorOrigin = getOrigin();
        final IGeneratorResult genResult = GeneratorResultBuilder
                .newBuilder(CommonGeneratorResultIds.getReferenceTargetHasWrongDefinition(errorOrigin),
                        "Reference {0} pointing to a target with an invalid definition. Expected definitions: {1} Actual definition: {2} Actual target: {3}.", reference,
                        expectedDefRefList, actualDefRef, target)
                .addErrorObject(reference).addErrorObject(target).buildResult();
        throw new BswmdModelReferenceTargetException(genResult, reference);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertReferenceTargetParameterNotNull(GIReference<?> reference, MIParameterValue targetParameter) {

        if (targetParameter == null) {

            final IHasValidationOrigin errorOrigin = getOrigin();
            final IGeneratorResult genResult = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getReferenceHasNoRefTargetId(errorOrigin), "Symbolic Name Reference {0:noValue} has no reference target.", reference)
                    .addErrorObject(reference).buildResult();
            throw new BswmdModelReferenceTargetException(genResult, reference);
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertReferenceContextNotNull(GInstanceReference reference, List<MIReferrableARRef> context) {
        if (context == null || context.isEmpty()) {

            final IHasValidationOrigin errorOrigin = getOrigin();
            final IGeneratorResult genResult = GeneratorResultBuilder
                    .newBuilder(CommonGeneratorResultIds.getReferenceFailureId(errorOrigin), "Reference {0} has no valid context.", reference).addErrorObject(reference)
                    .buildResult();
            throw new BswmdModelReferenceTargetException(genResult, reference);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertIntegerParameterValueInLongRange(GInteger gInteger, BigInteger value) {
        IMixedText msg = null;
        if (value.compareTo(LONG_MAX) >= 1) {
            msg = MixedText.format("Integer value '{0}' of '{1}' is too big to fit in a signed Long.", value, gInteger);
        } else if (value.compareTo(LONG_MIN) <= -1) {
            msg = MixedText.format("Integer value  '{0}' of '{1}' is too small to fit in a signed Long.", value, gInteger);
        }
        if (msg != null) {
            final IHasValidationOrigin errorOrigin = getOrigin();
            final IGeneratorResult genResult = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterHasIllegalValue(errorOrigin), msg).addErrorObject(gInteger)
                    .buildResult();
            throw new BswmdModelParameterHasIllegalValueException(genResult, gInteger, value.toString());
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertFloatParameterValueInJavaDoubleRange(GFloat gFloat, BigDecimal value) {
        IMixedText msg = null;
        if (value.compareTo(DOUBLE_MAX) > 0) {
            msg = MixedText.format("Autosar Float value '{0}' of '{1}' is too big to fit in  Double (Positive Overflow).", value, gFloat);
        } else if (value.compareTo(DOUBLE_MIN) < 0 && value.compareTo(ZERO) > 0) {
            msg = MixedText.format("Autosar Float value '{0}' of '{1}' is too small to fit in Double (Positive Underflow).", value, gFloat);
        } else if (value.compareTo(DOUBLE_MIN_NEG) > 0 && value.compareTo(ZERO) < 0) {
            msg = MixedText.format("Autosar Float value '{0}' of '{1}' is too small to fit in Double (Negative Underflow).", value, gFloat);
        } else if (value.compareTo(DOUBLE_MAX_NEG) < 0) {
            msg = MixedText.format("Autosar Float value '{0}' of '{1}' is too big to fit in Double (Negative Overflow).", value, gFloat);
        }
        if (msg != null) {
            final IHasValidationOrigin errorOrigin = getOrigin();
            final IGeneratorResult genResult = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterHasIllegalValue(errorOrigin), msg).addErrorObject(gFloat)
                    .buildResult();
            throw new BswmdModelParameterHasIllegalValueException(genResult, gFloat, value.toString());
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <T extends Enum<T>> void assertEnumerationHasLegalLiteral(GEnumeration<T> enumObj, Class<T> enumType, String value) {
        try {
            Enum.valueOf(enumType, value);

        } catch (final IllegalArgumentException ex) {
            // Illegal Enum Literal found => Report it
            final List<String> validValues = ModelEnumUtil.getValidValues(enumType);
            throw createAndThrowIllegalLiteralValueException(enumObj, validValues, value);

        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void assertEnumerationHasLegalLiteral(GAbstractEnumeration<?> enumObj, List<String> validValues, String value) {
        if (!validValues.contains(value)) {
            // Illegal Enum Literal found => Report it
            throw createAndThrowIllegalLiteralValueException(enumObj, validValues, value);

        }
    }

    /**
     * Creates the and throw illegal literal value exception.
     *
     * @param enumObj the enum obj
     * @param validValues the valid values
     * @param modelValue the model value
     * @return the bswmd model parameter has illegal value exception
     */
    private BswmdModelParameterHasIllegalValueException createAndThrowIllegalLiteralValueException(GIEnumParameter enumObj, List<String> validValues, String modelValue) {
        final GeneratorResultBuilder rb;

        rb = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterHasIllegalValue(this.getValidationResultOrigin()),
                "Enumeration parameter {0:noValue} has an illegal literal value '{1}'. Valid Values are: {2}", enumObj.getMdfObject(), modelValue, list2String(validValues));
        rb.addErrorObject(enumObj);

        if (validValues != null) {
            for (final String literal : validValues) {
                rb.addSolvingAction(new SASetTextual(enumObj.getMdfObject(), literal));
            }
        }

        throw new BswmdModelParameterHasIllegalValueException(rb.buildResult(), enumObj, modelValue);
    }

    /**
     * Convert an List<Strings> to an String.
     *
     * @param list the list
     * @return the string
     */
    private static String list2String(List<String> list) {
        boolean isFirst = true;
        final StringBuilder retVal = new StringBuilder();
        for (final String s : list) {
            if (!isFirst) {
                retVal.append(", ");
            } else {
                isFirst = false;
            }
            retVal.append(s);
        }
        return retVal.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public BswmdModelException issueExceptionFromModelException(GIModelObject parent, ModelException ex) {
        checkNotNull(parent);
        checkNotNull(ex);
        if (ex instanceof BswmdModelException) {
            return (BswmdModelException) ex;
        }

        final List<? extends IValidationResult> generatorResults = ModelExceptionProcessor.wrapExceptionIntoValidationResults(getProjectContext(), validationResultOrigin, ex);

        return new BswmdModelInvalidRequestException(generatorResults, parent, ex);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public BswmdModelInvalidRequestException issueInvalidRequestExceptionWithText(GIModelObject parent, IMixedText text) {
        return issueInvalidRequestExceptionWithText(parent, text, Collections.<MIObject> emptyList());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public BswmdModelInvalidRequestException issueInvalidRequestExceptionWithText(GIModelObject parent, IMixedText text, List<? extends MIObject> errorCEs) {
        checkNotNull(parent);

        final IHasValidationOrigin errorOrigin = this.getValidationResultOrigin();
        final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModelAccessFailureId(errorOrigin), text).addErrorObject(parent);

        builder.addErrorMdfObjectList(errorCEs);
        throw new BswmdModelInvalidRequestException(builder.buildResult(), parent);
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Caution: The GeneratorPackage, could be not available, if the GIModel was created without an {@link IGeneratorPackage}.
     * </p>
     */
    @PublishedMethod
    @Override
    public IGeneratorPackage getGeneratorPackage() {
        if (generatorPackage == null) {
            throw new UnsupportedOperationException("This Model was created without an IGeneratorPackage, so the getGeneratorPackage() method is not supported!");
        }
        return generatorPackage;
    }

}