package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIHasContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIParamOrRef;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIReference;
import com.vector.cfg.gen.core.bswmdmodel.param.GChoiceReference;
import com.vector.cfg.gen.core.bswmdmodel.param.GEnumeration;
import com.vector.cfg.gen.core.bswmdmodel.param.GFloat;
import com.vector.cfg.gen.core.bswmdmodel.param.GInstanceReference;
import com.vector.cfg.gen.core.bswmdmodel.param.GInteger;
import com.vector.cfg.gen.core.bswmdmodel.param.GReference;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrableARRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.util.version.IVersion;

/**
 * {@link GIModelVerifier} provides the methods to verify certain accesses into the BswmdModel. This class should not be used by clients. These method are
 * called from the internal BswmdMdoel implementation.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIModelVerifier {
    // CHECKSTYLE:ON

    /**
     * Assert ar version of bsw implementation is defined.
     *
     * @param cfg the cfg
     * @param version the version
     */
    @PublishedMethod
    void assertArVersionOfBswImplementationIsDefined(GAbstractModuleConfiguration cfg, final IVersion version);

    /**
     * Assert that the AR-Version of the ModuleDefinition is defined.
     *
     * @param cfg the cfg
     * @param version the version
     */
    @PublishedMethod
    void assertArSchemaVersionOfDefinitionIsDefined(GAbstractModuleConfiguration cfg, final IVersion version);

    /**
     * Assert sw version not null.
     *
     * @param cfg the cfg
     * @param version the version
     */
    @PublishedMethod
    void assertSwVersionOfBswImplementationIsDefined(GAbstractModuleConfiguration cfg, final IVersion version);

    /**
     * Checks if the specified container exists.
     *
     * @param parent the parent
     * @param container the container
     * @param containerDefRef the container def ref
     */
    @PublishedMethod
    void assertContainerNotNull(GIHasContainer parent, GIContainer container, DefRef containerDefRef);

    /**
     * Checks if the specified container list contains exactly one element.
     *
     * @param parent the parent
     * @param containerList the container list
     * @param containerDefRef the container def ref
     */
    @PublishedMethod
    void assertContainerIsExactyOneElement(GIHasContainer parent, List<GIContainer> containerList, DefRef containerDefRef);

    /**
     * Checks if the specified parameter list contains exactly one element.
     *
     * @param parent the parent
     * @param childList the child list
     * @param paramDefRef the param def ref
     */
    @PublishedMethod
    void assertParameterIsExactyOneElement(GIContainer parent, List<? extends GIParameter<?>> childList, DefRef paramDefRef);

    /**
     * Checks if the specified reference list contains exactly one element.
     *
     * @param parent the parent
     * @param childList the child list
     * @param paramDefRef the param def ref
     */
    @PublishedMethod
    void assertReferenceIsExactyOneElement(GIContainer parent, List<? extends GIReference<?>> childList, DefRef paramDefRef);

    /**
     * Checks if the specified parameter exists in the MDF model.
     *
     * @param parent the parent
     * @param parameter the parameter
     */
    @PublishedMethod
    void assertParameterOrReferenceNotNull(GIContainer parent, GIParamOrRef parameter);

    /**
     * Assert element is the only element.
     *
     * @param parent the parent
     * @param elem the elem
     * @param mdfObj the mdf obj
     */
    @PublishedMethod
    void assertElementIsTheOnlyElement(GIHasContainer parent, GIModelObject elem, MIHasDefinition mdfObj);

    /**
     * Checks if the specified parameter value exists.
     *
     * @param parameter the parameter
     * @param value the value
     */
    @PublishedMethod
    void assertParameterValueNotNull(GIParameter<?> parameter, Object value);

    /**
     * Checks if the specified references path is not <code>null</code>.
     *
     * @param reference the reference
     * @param path the path
     */
    @PublishedMethod
    void assertReferencePathNotNull(GIReference<?> reference, String path);

    /**
     * Checks if the specified references target exists.
     *
     * @param reference the reference
     * @param target the target
     */
    @PublishedMethod
    void assertReferenceTargetNotNull(GIReference<?> reference, MIReferrable target);

    /**
     * Checks if the specified references target exists.
     *
     * @param reference the reference
     * @param targetParameter the target parameter
     */
    @PublishedMethod
    void assertReferenceTargetParameterNotNull(GIReference<?> reference, MIParameterValue targetParameter);

    /**
     * Checks if the specified instance references context exists.
     *
     * @param reference the reference
     * @param context the context
     */
    @PublishedMethod
    void assertReferenceContextNotNull(GInstanceReference reference, List<MIReferrableARRef> context);

    /**
     * Checks if the specified enumeration has an illegal enumeration literal.
     *
     * @param <T> the generic type
     * @param enumObj the enum obj
     * @param enumType the enum type
     * @param value the value
     */
    @PublishedMethod
    <T extends Enum<T>> void assertEnumerationHasLegalLiteral(GEnumeration<T> enumObj, Class<T> enumType, String value);

    /**
     * Assert enumeration has legal literal.
     *
     * @param enumObj the enum obj
     * @param validValues the valid values
     * @param value the value
     */
    @PublishedMethod
    void assertEnumerationHasLegalLiteral(GAbstractEnumeration<?> enumObj, List<String> validValues, String value);

    /**
     * Checks if the specified parameter Object has a legal value.
     *
     * @param obj the obj
     * @param paramType the param type
     */
    @PublishedMethod
    void assertParameterHasLegalValue(GIParameter<?> obj, String paramType);

    /**
     * Checks if the specified integer parameter value is out of the Long datatype range.
     *
     * @param gInteger the g integer
     * @param value the value
     */
    @PublishedMethod
    void assertIntegerParameterValueInLongRange(GInteger gInteger, BigInteger value);

    /**
     * Checks if the specified float parameter value is out of the Double datatype range.
     *
     * @param gFloat the g float
     * @param value the value
     */
    @PublishedMethod
    void assertFloatParameterValueInJavaDoubleRange(GFloat gFloat, BigDecimal value);

    /**
     * Assert reference target has correct definition.
     *
     * @param reference the reference
     * @param target the target
     */
    @PublishedMethod
    void assertReferenceTargetHasCorrectDefinition(GReference reference, MIReferrable target);

    /**
     * Assert reference target has correct definition.
     *
     * @param reference the reference
     * @param target the target
     */
    @PublishedMethod
    void assertReferenceTargetHasCorrectDefinition(GChoiceReference reference, MIReferrable target);

    /**
     * Assert reference target has correct type.
     *
     * @param reference the reference
     * @param target the target
     * @param clazz the clazz
     */
    @PublishedMethod
    void assertReferenceTargetHasCorrectType(GAbstractRefToContainer reference, MIReferrable target, Class<MIContainer> clazz);

    /**
     * Assert config variant not null.
     *
     * @param moduleConfiguration the module configuration
     */
    @PublishedMethod
    void assertConfigVariantNotNull(GAbstractModuleConfiguration moduleConfiguration);

    /**
     * @param container
     * @param defref
     */
    @PublishedMethod
    void assertMdfConfigElementHasCorrectDefinition(MIHasDefinition configElem, MIParamConfMultiplicity definition, DefRef defref);
}
