package com.vector.cfg.dom.runtimesys.groovy.api;

import java.math.BigDecimal;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.taskmapping.IEvent;
import com.vector.cfg.model.sysdesc.api.taskmapping.ITaskMapping;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link IEventSelector} Api allows the definition of predicates for event (also called trigger) selection.
 * <p>
 * <div class="extdoc" id="IEventSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IEventSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(IEventSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(IEventSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(IEventSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches events (triggers) with the given event name.</div>
     *
     * @param name An event name.
     */
    @PublishedMethod
    void name(@Nonnull String name);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches events (triggers) with the given event name pattern.</div>
     *
     * @param namePattern An event pattern.
     */
    @PublishedMethod
    void name(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches events (triggers) with the given event autosar path.</div>
     *
     * @param asrPath An event autosar path.
     */
    @PublishedMethod
    void asrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches events (triggers) with the given event autosar path pattern.</div>
     *
     * @param asrPathPattern An event autosar path pattern.
     */
    @PublishedMethod
    void asrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="component">{@link #component(String)} matches events (triggers) which belong to components with the given component name.</div>
     *
     * @param name A component name.
     */
    @PublishedMethod
    void component(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} matches events (triggers) which belong to components which matches the given component name
     * pattern.</div>
     *
     * @param namePattern A component name pattern.
     */
    @PublishedMethod
    void component(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentType">{@link #componentType(String)} matches events (triggers) which are part of the internal behavior of component types with the given
     * component type name.</div>
     *
     * @param name A component type name.
     */
    @PublishedMethod
    void componentType(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentTypePattern">{@link #componentType(Pattern)} matches events (triggers) which are part of the internal behavior of component types which
     * matches the given component type name pattern.</div>
     *
     * @param namePattern A component type name pattern.
     */
    @PublishedMethod
    void componentType(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentTypeAsrPath">{@link #componentTypeAsrPath(String)} matches events (triggers) which are part of the internal behavior of component types
     * with the given component type autosar path.</div>
     *
     * @param asrPath A component type autosar path.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="componentTypeAsrPathPattern">{@link #componentTypeAsrPath(Pattern)} matches events (triggers) which are part of the internal behavior of component
     * types whose autosar path matches the given component type autosar path pattern.</div>
     *
     * @param asrPathPattern A component type asr path pattern.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="moduleConfiguration">{@link #moduleConfiguration(String)} matches events (triggers) which belong to module configurations with the given module
     * configuration name.</div>
     *
     * @param name A module configuration name.
     */
    @PublishedMethod
    void moduleConfiguration(@Nonnull String name);

    /**
     * <div class="extdoc" id="moduleConfigurationPattern">{@link #moduleConfiguration(Pattern)} matches events (triggers) which belong to module configurations which matches
     * the given module configuration name pattern.</div>
     *
     * @param namePattern A module configuration name pattern.
     */
    @PublishedMethod
    void moduleConfiguration(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="moduleConfigurationAsrPath">{@link #moduleConfigurationAsrPath(String)} matches events (triggers) which belong to module configurations with the
     * given module configuration autosar path.</div>
     *
     * @param asrPath A module configuration autosar path.
     */
    @PublishedMethod
    void moduleConfigurationAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="moduleConfigurationAsrPathPattern">{@link #moduleConfigurationAsrPath(Pattern)} matches events (triggers) which belong to module configurations
     * whose autosar path matches the given module configuration autosar path pattern.</div>
     *
     * @param asrPathPattern A module configuration asr path pattern.
     */
    @PublishedMethod
    void moduleConfigurationAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="task">{@link #task(String)} matches events (triggers) which are mapped to a task with the given task name.</div>
     *
     * @param name A task name.
     */
    @PublishedMethod
    void task(@Nonnull String name);

    /**
     * <div class="extdoc" id="taskPattern">{@link #task(Pattern)} matches events (triggers) which are mapped to a task whose name matches the given task name pattern.</div>
     *
     * @param name A task name pattern.
     */
    @PublishedMethod
    void task(@Nonnull Pattern namePattern);

    // ----------------------------

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches events (triggers) for which the given closure results to true.</div>
     *
     * @param code The closure to select events.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(IEvent.class) Closure<Boolean> code);

    /**
     * <div class="extdoc" id="bswEvent">{@link #bswEvent()} matches events (triggers) which are bsw events.</div>
     */
    @PublishedMethod
    void bswEvent();

    /**
     * <div class="extdoc" id="rteEvent">{@link #rteEvent()} matches events (triggers) which are rte events.</div>
     */
    @PublishedMethod
    void rteEvent();

    /**
     * <div class="extdoc" id="unmapped">{@link #unmapped()} matches unmapped events (triggers). In case of multi instantiated components/modules matches if unmapped at least in
     * one context. Use {@link #fullyUnmapped()} to determine whether an event is unmapped in all contexts.</div>
     */
    @PublishedMethod
    void unmapped();

    /**
     * <div class="extdoc" id="mapped">{@link #mapped()} matches mapped events (triggers). In case of multi instantiated components/modules matches if mapped at least in one
     * context. Use {@link #fullyMapped()} to determine whether an event is mapped in all contexts.</div>
     */
    @PublishedMethod
    void mapped();

    /**
     * <div class="extdoc" id="fullyUnmapped">{@link #fullyUnmapped()} matches events (triggers) which are not mapped in any context. If no multi instantiation is used, the
     * result is the same as for {@link #unmapped()}.</div>
     */
    @PublishedMethod
    void fullyUnmapped();

    /**
     * <div class="extdoc" id="fullyMapped">{@link #fullyMapped()} matches events (triggers) which are mapped in every context. If no multi instantiation is used, the result is
     * the same as for {@link #mapped()}.</div>
     */
    @PublishedMethod
    void fullyMapped();

    /**
     * <div class="extdoc" id="timing">{@link #timing()} matches events which are timing events (triggers).</div>
     */
    @PublishedMethod
    void timing();

    /**
     * <div class="extdoc" id="timingPeriod">{@link #timing(BigDecimal)} matches events (triggers) which are timing events with the given period (seconds).</div>
     *
     * @param period The period of the timing event in seconds.
     */
    @PublishedMethod
    void timing(BigDecimal period);

    /**
     * <div class="extdoc" id="init">{@link #init()} matches events (triggers) which are init events.</div>
     */
    @PublishedMethod
    void init();

    /**
     * <div class="extdoc" id="dataReception">{@link #dataReception()} matches events (triggers) which are data received events.</div>
     */
    @PublishedMethod
    void dataReceived();

    /**
     * <div class="extdoc" id="dataReceptionError">{@link #dataReceptionError()} matches events (triggers) which are data receive error events.</div>
     */
    @PublishedMethod
    void dataReceiveError();

    /**
     * <div class="extdoc" id="dataSendCompletion">{@link #dataSendCompletion()} matches events (triggers) which are data send completed events.</div>
     */
    @PublishedMethod
    void dataSendCompleted();

    /**
     * <div class="extdoc" id="operationInvoked">{@link #operationInvoked()} matches events (triggers) which are operation invoked events.</div>
     */
    @PublishedMethod
    void operationInvoked();

    /**
     * <div class="extdoc" id="operationInvokedNamed">{@link #operationInvoked(String)} matches operation invoked events (triggers) which are invoked by an operation with the
     * given operationName.</div>
     */
    @PublishedMethod
    void operationInvoked(@Nonnull String operationName);

    /**
     * <div class="extdoc" id="serverCallReturns">{@link #serverCallReturns()} matches events (triggers) which are asynchronous server call returns events.</div>
     */
    @PublishedMethod
    void serverCallReturns();

    /**
     * <div class="extdoc" id="modeSwitch">{@link #modeSwitch()} matches events (triggers) which are swc mode switch events.</div>
     */
    @PublishedMethod
    void modeSwitch();

    /**
     * <div class="extdoc" id="modeSwitchedAck">{@link #modeSwitchedAck()} matches events (triggers) which are mode switched acknowledgement events.</div>
     */
    @PublishedMethod
    void modeSwitchedAck();

    /**
     * <div class="extdoc" id="externalTrigger">{@link #externalTrigger()} matches events (triggers) which are external trigger occured events.</div>
     */
    @PublishedMethod
    void externalTrigger();

    /**
     * <div class="extdoc" id="internalTrigger">{@link #internalTrigger()} matches events (triggers) which are internal trigger occured events.</div>
     */
    @PublishedMethod
    void internalTrigger();

    /**
     * <div class="extdoc" id="background">{@link #background()} matches events (triggers) which are background events.</div>
     */
    @PublishedMethod
    void background();

    /**
     * <div class="extdoc" id="mandatory">{@link #mandatory()} matches events (triggers) which must be mapped. (The mapping of operation invoked events is optional, so this
     * predicate filters all operation invoked events.)</div>
     */
    @PublishedMethod
    void mandatory();

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<IEvent> getSelectedEvents();

    @KeepSecretFromPublishedApi
    List<ITaskMapping> getSelectedTaskMappings();

}
