package com.vector.cfg.consistency.contribution.helper.solvingactions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * This class is an {@link ISolvingAction} that sets a parameter to its default value.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class SetDefaultValue<NUM_TEXT_TYPE extends MIParameterValue> extends SetDefaultValueNonPublished<NUM_TEXT_TYPE> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SetDefaultValue.class);

    /**
     * Constructor for SetDefaultValue.
     *
     * @param parameter
     * @param defaultValue
     */
    @PublishedMethod
    public SetDefaultValue(NUM_TEXT_TYPE parameter, Object defaultValue) {
        super(parameter, defaultValue, false);
    }

    /**
     * Creates the a SetDefaultValue solving action. If the parameter has no default value, this method returns null.
     *
     * @param parameter the parameter
     * @return the new solving action or null if the parameter has no default value.
     */
    @PublishedMethod
    public static SetDefaultValue<?> create(MIParameterValue parameter) {
        return SetDefaultValueNonPublished.create(parameter);
    }

}
