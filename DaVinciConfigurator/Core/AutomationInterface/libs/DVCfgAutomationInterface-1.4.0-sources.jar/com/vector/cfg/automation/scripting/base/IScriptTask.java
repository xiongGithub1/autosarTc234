package com.vector.cfg.automation.scripting.base;

import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.IScriptTaskType.IScriptTaskTypeSignature;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.servicecontext.IServiceContext;
import com.vector.cfg.util.servicecontext.ServiceContext;

/**
 * {@link IScriptTask} represents a created script task from the client side script. The script task can be called, to execute the client code. See
 * {@link #call(IServiceContext, Object...)} method to execute the script task.
 *
 * <p>
 * The script task has a defined {@link IScriptTaskType}, which defines where the task is executable and what argument are passed to the task during execution. See
 * {@link IScriptTaskType} for details.
 * </p>
 *
 * <p>
 * The script task is created hold by an {@link IScript}, see {@link IScript} for more details.
 * </p>
 *
 * <h5>Load behavior</h5> The script task instance will not change, when a script is reloaded due to changes. So the user code, can hold a reference to the {@link IScriptTask}
 * when the script is changed.
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IScript
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IScriptTask extends IAutomationTask {

    /**
     * Returns the {@link IScript} containing this {@link IScriptTask}.
     *
     * @return the script
     */
    @PublishedMethod
    IScript getScript();

    /**
     * Return the script task name, specified during task construction.
     *
     * @return the task name
     */
    @Override
    @PublishedMethod
    String getName();

    /**
     * Returns the full qualified name of the script task including the script name.
     *
     * @return the qualified name
     */
    @Override
    @PublishedMethod
    String getQualifiedName();

    /**
     * Returns the script logger of {@link IScript#getScriptLogger()}.
     *
     * @return the script logger
     */
    @Override
    @PublishedMethod
    ILogger getScriptLogger();

    /**
     * Returns the short description of the task, if set, otherwise empty.
     *
     * <p>
     * The description is set during construction of the task, by calling <code>description("The description")</code>.
     * </p>
     *
     * @return the description
     */
    @PublishedMethod
    String getDescription();

    /**
     * Returns the help text description of the task, if set, otherwise empty.
     *
     * <p>
     * The help is the concatenation of the helpText userDefinedArgumentsHelp.
     * </p>
     *
     * @return the help text
     */
    @PublishedMethod
    String getHelp();

    /**
     * Returns the {@link IScriptTaskType}, which was specified during construction.
     *
     * <p>
     * The {@link IScriptTaskType} defines where the task is executable, and the arguments passed to the task during execution. See {@link IScriptTaskType} for more details.
     *
     * @return the task type
     * @see IScriptTaskType
     */
    @PublishedMethod
    IScriptTaskType getTaskType();

    /**
     * Calls the task code to execute it.
     *
     * <p>
     * The signature of this method is defined by the {@link IScriptTaskType}, see {@link #getTaskType()}. So the args <code>Object[]</code> must contain instance of the types
     * defined in the {@link IScriptTaskType} of this {@link IScriptTask}, otherwise the script is not callable.
     * </p>
     *
     * @param serviceContext the serviceContext to call the task in. If the task is a project task it must be a ProjectContext, otherwise it must be an ApplicationContext. If
     * the {@link ServiceContext} is <code>null</code> get currently available context is used.
     *
     * @param args the args which are passed the the {@link IScriptTask}.
     * @return the execution result of the script task, which contains the returned object from the script task.
     *
     * @exception ScriptingException
     * <ul>
     * <li>if the the execution of the task has failed.</li>
     * </ul>
     * @exception IllegalStateException
     * <ul>
     * <li>if this {@link IScriptTask} is a project task and if there is no active <code>IProject</code> (i.e. if <code>IProjectHandlingApi.isProjectActive()</code> returns
     * {@code false})</li>
     * </ul>
     * @see IScriptTaskType
     * @see IScriptTaskTypeSignature
     * @see IScriptTaskExecutionResult
     *
     */
    @PublishedMethod
    IScriptTaskExecutionResult call(@Nullable IServiceContext serviceContext, Object... args);

    /**
     * Calls the task code to execute it.
     *
     * @param logger the used logger to log the execution of the script task. If <code>null</code> a default user logger is used.
     * @param userDefinedArguments the arguments passed to the script a user defined arguments, if no arguments shall be passed call it with an empty {@link String}
     * @param serviceContext the serviceContext to call the task in. If the task is a project task it must be a ProjectContext, otherwise it must be an ApplicationContext. If
     * the {@link ServiceContext} is <code>null</code> get currently available context is used.
     * @param args the arguments passed to the script task. These must match the {@link #getTaskType()} signature.
     * @return the execution result of the script task, which contains the returned object from the script task.
     *
     * @exception ScriptingException
     * <ul>
     * <li>if the the execution of the task has failed.</li>
     * </ul>
     * @exception IllegalStateException
     * <ul>
     * <li>if this {@link IScriptTask} is a project task and if there is no active <code>IProject</code> (i.e. if <code>IProjectHandlingApi.isProjectActive()</code> returns
     * {@code false})</li>
     * </ul>
     * @see IScriptTaskType
     * @see IScriptTaskTypeSignature
     * @see IScriptTaskExecutionResult
     */
    @PublishedMethod
    IScriptTaskExecutionResult callWithUserArgs(@Nullable ILogger logger, @Nullable String userDefinedArguments, @Nullable IServiceContext serviceContext, Object... args);

}
