package com.vector.cfg.automation.api.project;

import java.nio.file.Path;
import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.ScriptConverters;

/**
 * {@link IOpenDpaProjectApi} provides means for parameterizing the process of opening a list of arxml files in a temporary project.
 *
 * <div class="extdoc" id="Common"> Sometimes it could be helpful to load AUTOSAR <code>arxml</code> files instead of a full-fledged DaVinci Configurator project. For example to
 * modify the content of a file for test cases with the AutomationInterface, instead of using an XML editor.
 *
 * <p>
 * You could load multiple <code>arxml</code> files into a temporary project, which allowed to read and write the loaded file content with the normal model APIs.
 * </p>
 * <p>
 * The following elements are loaded by default, without specifying the AUTOSAR files:
 * <ul>
 * <li>ModuleDefinitions from the SIP: To allow the usage of the BswmdModel</li>
 * <li>AUTOSAR standard definition: Refinement resolution of definitions</li>
 * </ul>
 * </p>
 *
 * <p>
 * <b>Caution:</b> Some APIs and services may not be available for this type of project, like:
 * <ul>
 * <li>Update workflow: You can't update a non existing project</li>
 * <li>Validation: The validation is disabled by default</li>
 * <li>Generation: The generators are not loaded by default</li>
 * </ul>
 *
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IProjectHandlingApi#parameterizeArxmlFileLoad(groovy.lang.Closure)
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IOpenArxmlFilesProjectApi extends IOpenProjectApi {

    /**
     * Adds arxml files to load.
     *
     * <div class="extdoc" id="arxmlFiles">
     * <h5>Arxml Files</h5> Add <code>arxml</code> files to load with the method {@link #arxmlFiles(Collection)}. Multiple files and method calls are allowed. The given values
     * are converted to {@link Path} instances using {@link ScriptConverters#TO_SCRIPT_PATH} <!--Ref:ScriptConverters.TO_SCRIPT_PATH-->.
     *
     *
     * </div>
     *
     * @param dpaFile the .dpa file of the project to be opened
     */
    @PublishedMethod
    void arxmlFiles(Collection<Object> filesToLoad);

    /**
     * Alias for {@link #arxmlFiles(Collection)}.
     *
     * @param filesToLoad the files to load
     * @see #arxmlFiles(Collection)
     */
    @PublishedMethod
    void arxmlFiles(Object... filesToLoad);

    /**
     * Alias for {@link #setLoadDefinitions(boolean)}.
     *
     * @param loadDefinitions
     */
    @PublishedMethod
    void loadDefinitions(boolean loadDefinitions);

    /**
     * Specified whether or not to load the definitions of the SIP including the AUTOSAR Standard definitions. The default is <code>true</code>.
     *
     * @param loadDefinitions whether or not to load the definitions of the SIP
     */
    @PublishedMethod
    void setLoadDefinitions(boolean loadDefinitions);

    /**
     * Alias for {@link #setRawAutosarDataMode(boolean)}.
     *
     * @param loadDefinitions
     */
    @PublishedMethod
    void rawAutosarDataMode(boolean rawAutosarData);

    /**
     * Enables the raw access to the loaded AUTOSAR data.
     *
     * <div class="extdoc" id="setRawAutosarDataMode">
     * <h5>Raw AUTOSAR Data Mode</h5> the method {@link #setRawAutosarDataMode(boolean)} specifies whether or not to use the raw ATUOSAR data model.
     *
     * <p>
     * <b>Currently only this mode is supported!</b> You have to set <code>rawAutosarDataMode = true</code>.
     * </p>
     *
     * Note: In raw mode most of the provided services and APIs will disabled, see below for details.
     *
     * </div>
     *
     * @param rawAutosarData the new raw autosar data mode
     */
    @PublishedMethod
    void setRawAutosarDataMode(boolean rawAutosarData);

}
