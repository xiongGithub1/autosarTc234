package com.vector.cfg.consistency.groovy.api;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.ui.ISettingAutoSolvingActionExecution;

/**
 * This interface gives access to validation settings.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISettings {

    /**
     * Gets the {@link ISettingAutoSolvingActionExecution} interface.
     *
     * @return the {@link ISettingAutoSolvingActionExecution} interface
     */
    @PublishedMethod
    ISettingAutoSolvingActionExecution getAutoSolvingActionExecution();
}
