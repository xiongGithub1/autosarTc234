package com.vector.cfg.model.access.ecucdefinition.elements.reference;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEcucUriReferenceDef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucUriReferenceDefinition extends IEcucAbstractRef {

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    MIEcucUriReferenceDef getDef();

}
