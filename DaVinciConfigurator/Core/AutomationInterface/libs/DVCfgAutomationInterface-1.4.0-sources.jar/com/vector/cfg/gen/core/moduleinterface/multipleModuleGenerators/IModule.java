package com.vector.cfg.gen.core.moduleinterface.multipleModuleGenerators;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;

/**
 * A IModule represents the information of a generator about it module, which it will generate.
 *
 * <p>
 * Please create modules with MultipleModuleGeneratorUtil to create {@link IModule} instances.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @author virtu
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IModule {

    /**
     * Gets the Module Definition Ref.
     *
     * @return The module Definition Ref
     */
    @PublishedMethod
    DefRef getModuleDefinitionRef();

}
