package com.vector.cfg.gen.core.genusage.groovy.api.swct;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.genusage.groovy.exceptions.GenerationProcessException;
import com.vector.cfg.gen.core.genusage.result.model.IGenerationResultModel;
import com.vector.cfg.gen.core.moduleinterface.EGenerationProcessResult;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IGenerationSwctApi} is the entry point to the Software Component Templates and Contract Phase Headers (Swct) generation API and provide functionality for the
 * generation of the software components.
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface IGenerationSwctApi {

    /**
     * Opens an empty settings block. This block contains settings related to Software Component Templates and Contract Phase Headers (Swct) generation.
     *
     * @param code Content of the block
     * @return the configured setting object
     * @see #settingsFromProject(Closure)
     */
    @PublishedMethod
    IGenerationSwctSettingsApi settings(
            @VDelegatesToWithClosureParam(IGenerationSwctSettingsApi.class) Closure<?> code);

    /**
     * Opens a new settings block which already pre configured with the project settings. This block contains settings related to Software Component Templates and Contract Phase
     * Headers (Swct) generation.
     *
     * @param code Content of the block
     * @return the configured setting object
     * @see #settings(Closure)
     */
    @PublishedMethod
    IGenerationSwctSettingsApi settingsFromProject(
            @VDelegatesToWithClosureParam(IGenerationSwctSettingsApi.class) Closure<?> code);

    /**
     * Returns the currently active setting of the recently created settings object, or the default project settings.
     *
     * @return The recently created settings object
     */
    @PublishedMethod
    IGenerationSwctSettingsApi getSettings();

    /**
     * Starts the generation. This method takes a settings object as an argument. So it is possible to reuse a settings object.
     *
     * <p>
     * Note: the returned result may indicate a error {@link EGenerationProcessResult#ERROR} for failed components. If the whole generation process fails this method will throw
     * and {@link GenerationProcessException}.
     * </p>
     *
     * @param settings {@link IGenerationSwctSettingsApi} object
     * @return the result of the Swct generation
     * @exception GenerationProcessException if the generation has failed due to an unexpected exception.
     */
    @PublishedMethod
    IGenerationResultModel generate(@Nonnull IGenerationSwctSettingsApi settings);

    /**
     * Starts the generation. The last opened settings block (see {@link #settings(Closure)} for details) is used for generation or if no settings block has been defined the
     * standard project settings from the project file are used.
     *
     * @return the result of the Swct generation
     * @exception GenerationProcessException if the generation has failed due to an unexpected exception.
     * @see #generate(IGenerationSwctSettingsApi) for details.
     * @see #settings(Closure)
     * @see #settingsFromProject(Closure)
     */
    @PublishedMethod
    IGenerationResultModel generate();

}
