/**
 * Automation script API for user interaction and input in a running script task to interaction with the user directly.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.automation.api.userinteraction;