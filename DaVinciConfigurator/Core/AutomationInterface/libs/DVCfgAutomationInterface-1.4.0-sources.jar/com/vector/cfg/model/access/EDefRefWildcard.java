package com.vector.cfg.model.access;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation">
 * <h4>Predefined DefRef Wildcards</h4> The class {@link EDefRefWildcard} contains the predefined {@link IDefRefWildcard}s for the {@link DefRef} class. These
 * {@link IDefRefWildcard}s could be used to create {@link DefRef}s, without creating your own wildcard for the standard use cases
 *
 * <p>
 * The {@link DefRef#create(String, String)} method will parse the first {@link String} to find a wildcard matching the {@link EDefRefWildcard}s.
 * </p>
 *
 * <p>
 * <h5>Predefined wildcards:</h5> The class {@link EDefRefWildcard} defines the following wildcards, with the specified semantic:
 * <ul>
 * <li>{@link EDefRefWildcard#ANY} <code>/[ANY]</code>: Matches on any package path. It is equal to any package and any packages refines from {@link #ANY} wildcard.</li>
 * <li>{@link EDefRefWildcard#AUTOSAR} <code>/[AUTOSAR]</code>: Matches on the AUTOSAR3 and AUTOSAR4 packages (see {@link DefRef} class). It is equal to the AUTOSAR packages,
 * but not to refined packages e.g. /MICROSAR. Any packages which refined from AUTOSAR also refines from {@link #AUTOSAR} wildcard.</li>
 * <li>{@link EDefRefWildcard#NOT_AUTOSAR_STMD} <code>/[!AUTOSAR_STMD]</code>: Matches on any package except the AUTOSAR packages. It is equal to any package, except AUTOSAR
 * packages. Any package refines from {@link #NOT_AUTOSAR_STMD} wildcard, except AUTOSAR packages.</li>
 * <li>{@link EDefRefWildcard#MICROSAR} <code>/[MICROSAR]</code>: Matches on any package stating with /MICROSAR (also /MICROSAR/S12x). It is equal to any package stating with
 * /MICROSAR. Any package starting with /MICROSAR refines from {@link #MICROSAR} wildcard.</li>
 * <li>{@link EDefRefWildcard#NOT_MICROSAR} <code>/[!MICROSAR]</code>: Matches on any package path not starting with /MICROSAR. It is equal to any package not starting with
 * /MICROSAR. Any package, which does not start with /MICROSAR, refines from {@link #NOT_MICROSAR} wildcard. Also the AUTOSAR packages refine from {@link #NOT_MICROSAR}
 * wildcard.</li>
 * </ul>
 * </p>
 *
 * <h5>Creation of the DefRef with Wildcard</h5> The elements of {@link EDefRefWildcard} could be passed to the {@link DefRef} constructor:
 *
 * <pre>
 * <code class="Java" id="Creation of DefRef with wildcard from EDefRefWildcard">
 * 	DefRef myDefRef = DefRef.create(EDefRefWildcard.MICROSAR, "CanIf");
 * </code>
 * </pre>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IDefRefWildcard
 * @see DefRef
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EDefRefWildcard implements IDefRefWildcard {

    /**
     * Wildcard that matches any package.
     *
     */
    ANY("/[ANY]") {
        @Override
        public boolean matches(DefRef defRefToMatch) {
            return true;
        }

    },
    /**
     * Wildcard for Packages that are Autosar3 or Autosar4 Packages.
     *
     * <p>
     * CAUTION: This will not be equal to refined definitions. But the {@link IModelAccess} will return refinements and definition checks with {@link IModelAccess} will
     * consider refinements, e.g. {@link DefRef#isDefinitionOf(DefRef, IModelAccess)}.
     * </p>
     *
     */
    AUTOSAR("/[AUTOSAR]") {

        @Override
        public boolean matches(DefRef defRefToMatch) {

            final int hashCode = defRefToMatch.hashCodeOfPackagePart();

            if (hashCode != AUTOSAR3_HASHCODE && hashCode != AUTOSAR4_HASHCODE) {
                // It can't start with /AUTOSAR .....
                return false;
            }

            final String packagesPart = defRefToMatch.getPackagePartOfDefRefString();

            if (packagesPart.equals(DefRef.AUTOSAR3_PACKAGE)) {
                return true;
            }

            if (packagesPart.equals(DefRef.AUTOSAR4_PACKAGE)) {
                return true;
            }
            return false;
        }

    },
    /**
     * Wildcard which matches against all packages except the AUTOSAR packages from {@link #AUTOSAR}.
     *
     * <p>
     * CAUTION: This will be equal to all definitions except AUTOSAR definitions. But the {@link IModelAccess} will return refinements and definition checks with
     * {@link IModelAccess} will consider refinements, e.g. {@link DefRef#isDefinitionOf(DefRef, IModelAccess)}.
     * </p>
     *
     */
    NOT_AUTOSAR_STMD("/[!AUTOSAR_STMD]") {
        @Override
        public boolean matches(DefRef defRefToMatch) {
            return !EDefRefWildcard.AUTOSAR.matches(defRefToMatch);
        }
    },

    /**
     * Wildcard for all Microsar Packages.
     *
     * A Package that starts with /MICROSAR will match this wildcard.
     */
    MICROSAR("/[MICROSAR]") {
        @Override
        public boolean matches(DefRef defRefToMatch) {
            if (defRefToMatch.getPackagePartOfDefRefString().startsWith(DefRef.MICROSAR_PACKAGE)) {
                return true;
            }
            return false;
        }

    },
    /**
     * Wildcard matches all packages except any package stating with {@link DefRef#MICROSAR_PACKAGE}. Also the AUTOSAR package is recognized. {@link IModelAccess} refinements of
     * MICROSAR element will be rejected by this wildcard.
     *
     * A Package that does <b>not</b> start with /MICROSAR will match this wildcard.
     */
    NOT_MICROSAR("/[!MICROSAR]") {
        @Override
        public boolean matches(DefRef defRefToMatch) {
            return !EDefRefWildcard.MICROSAR.matches(defRefToMatch);
        }

        @Override
        public boolean continueRefinementSearchFor(DefRef moduleDefRef) {
            if (EDefRefWildcard.MICROSAR.matches(moduleDefRef)) {
                return false;
            }
            return true;
        }

    }

    ;

    private static final int AUTOSAR3_HASHCODE = DefRef.AUTOSAR3_PACKAGE.hashCode();

    private static final int AUTOSAR4_HASHCODE = DefRef.AUTOSAR4_PACKAGE.hashCode();

    private final String wildcardString;

    /**
     * Constructor for EDefRefPatterns.
     *
     */
    EDefRefWildcard(String wildcardString) {
        this.wildcardString = wildcardString;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getWildcardString() {
        return wildcardString;
    }

    @PublishedMethod
    @Nullable
    public static EDefRefWildcard getWildcardByString(String wildcardString) {
        for (final EDefRefWildcard wild : values()) {
            if (wild.getWildcardString().equals(wildcardString)) {
                return wild;
            }
        }
        return null;
    }

    /**
     * @param defRef
     * @return
     */
    @PublishedMethod
    @Nullable
    public static EDefRefWildcard startsWithWildcard(String defRefString) {
        for (final EDefRefWildcard wild : values()) {
            if (defRefString.startsWith(wild.getWildcardString())) {
                return wild;
            }
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public boolean matches(DefRef defRefToMatch) {
        throw new AbstractMethodError();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public boolean continueRefinementSearchFor(DefRef moduleDefRef) {
        return true;
    }

}
