package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.model.sysdesc.ports.mapping.IPortInterfaceMapping;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.util.scripting.groovy.closurelogic.IClosureBooleanLogicCollector.IDescriptivePredicate;

import groovy.lang.Closure;

/**
 * The {@link IComponentPortSelector} Api allows the definition of predicates for component port selection.
 * <p>
 * <div class="extdoc" id="IComponentPortSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IComponentPortSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(IComponentPortSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(IComponentPortSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(IComponentPortSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches component ports with the given port name.</div>
     *
     * @param name A port name.
     */
    @PublishedMethod
    void name(@Nonnull String name);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches component ports with the given port name pattern.</div>
     *
     * @param namePattern A port name pattern.
     */
    @PublishedMethod
    void name(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches component ports with the given port autosar path.</div>
     *
     * @param asrPath A port autosar path.
     */
    @PublishedMethod
    void asrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches component ports with the given port autosar path pattern.</div>
     *
     * @param asrPathPattern A port autosar path pattern.
     */
    @PublishedMethod
    void asrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="component">{@link #component(String)} matches component ports with the given component name.</div>
     *
     * @param name A component name.
     */
    @PublishedMethod
    void component(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} matches component ports with the given component name pattern.</div>
     *
     * @param namePattern A component name pattern.
     */
    @PublishedMethod
    void component(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentAsrPath">{@link #componentAsrPath(String)} matches the component ports with the given component autosar path.</div>
     *
     * @param asrPath A component autosar path.
     */
    @PublishedMethod
    void componentAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="componentAsrPathPattern">{@link #componentAsrPath(Pattern)} matches component ports with the given component autosar path pattern.</div>
     *
     * @param asrPathPattern A component asr path pattern.
     */
    @PublishedMethod
    void componentAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="portInterfaceMapping">{@link #portInterfaceMapping(String)} matches component ports for whose port interfaces a port interface mapping with the
     * given port interface mapping name exists.</div>
     *
     * @param name A port interface mapping name.
     */
    @PublishedMethod
    void portInterfaceMapping(@Nonnull String name);

    /**
     * <div class="extdoc" id="portInterfaceMappingPattern">{@link #portInterfaceMapping(Pattern)} matches component ports for whose port interfaces a port interface mapping
     * with the given port interface mapping name pattern exists.</div>
     *
     * @param namePattern A port interface mapping name pattern.
     */
    @PublishedMethod
    void portInterfaceMapping(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="portInterfaceMappingAsrPath">{@link #portInterfaceMappingAsrPath(String)} matches component ports for whose port interfaces a port interface
     * mapping with the given port interface mapping autosar path exists.</div>
     *
     * @param asrPath A port interface mapping asr path.
     */
    @PublishedMethod
    void portInterfaceMappingAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="portInterfaceMappingAsrPathPattern">{@link #portInterfaceMappingAsrPath(Pattern)} matches component ports for whose port interfaces a port
     * interface mapping with the given port interface mapping autosar path pattern exists.</div>
     *
     * @param asrPathPattern A port interface mapping asr path pattern.
     */
    @PublishedMethod
    void portInterfaceMappingAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="componentType">{@link #componentType(String)} matches component ports whose component type's name equals the given component type name.</div>
     *
     * @param name A component type name.
     */
    @PublishedMethod
    void componentType(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentTypePattern">{@link #componentType(Pattern)} matches component ports whose component type's name matches the given component type name
     * pattern.</div>
     *
     * @param namePattern A component type name pattern.
     */
    @PublishedMethod
    void componentType(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentTypeAsrPath">{@link #componentTypeAsrPath(String)} matches the component ports whose component type's autosar path equals the given
     * component type autosar path.</div>
     *
     * @param asrPath A component type type autosar path.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="componentTypeAsrPathPattern">{@link #componentTypeAsrPath(Pattern)} matches component ports whose component type's autosar path matches the given
     * component type autosar path pattern.</div>
     *
     * @param asrPathPattern A component type asr path pattern.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull Pattern asrPathPattern);

    // ----------------------------

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches component ports for which the given closure results to true.</div>
     *
     * @param code The closure to select component ports.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(IComponentPort.class) Closure<Boolean> code);

    /**
     * <div class="extdoc" id="unconnected">{@link #unconnected()} matches unconnected component ports.</div>
     */
    @PublishedMethod
    void unconnected();

    /**
     * <div class="extdoc" id="connected">{@link #connected()} matches connected component ports.</div>
     */
    @PublishedMethod
    void connected();

    /**
     * <div class="extdoc" id="senderReceiver">{@link #senderReceiver()} matches component ports whose port has a sender/receiver port interface.</div>
     */
    @PublishedMethod
    void senderReceiver();

    /**
     * <div class="extdoc" id="clientServer">{@link #clientServer()} matches component ports whose port has a client/server port interface.</div>
     */
    @PublishedMethod
    void clientServer();

    /**
     * <div class="extdoc" id="modeSwitch">{@link #modeSwitch()} matches component ports whose port has a mode-switch port interface.</div>
     */
    @PublishedMethod
    void modeSwitch();

    /**
     * <div class="extdoc" id="nvData">{@link #nvData()} matches component ports whose port has a NvData port interface.</div>
     */
    @PublishedMethod
    void nvData();

    /**
     * <div class="extdoc" id="parameter">{@link #parameter()} matches component ports whose port has a parameter (calibration) port interface.</div>
     */
    @PublishedMethod
    void parameter();

    /**
     * <div class="extdoc" id="trigger">{@link #trigger()} matches component ports whose port has a trigger port interface.</div>
     */
    @PublishedMethod
    void trigger();

    /**
     * <div class="extdoc" id="provided">{@link #provided()} matches provided component ports (p-port).</div>
     */
    @PublishedMethod
    void provided();

    /**
     * <div class="extdoc" id="required">{@link #required()} matches required component ports (r-port).</div>
     */
    @PublishedMethod
    void required();

    /**
     * <div class="extdoc" id="providedRequired">{@link #providedRequired()} matches provided-required component ports (pr-port).</div>
     */
    @PublishedMethod
    void providedRequired();

    /**
     * <div class="extdoc" id="delegation">{@link #delegation()} matches delegation ports (ports of the Ecu composition).</div>
     */
    @PublishedMethod
    void delegation();

    /**
     * <div class="extdoc" id="application">{@link #application()} matches component ports whose port interface is an application port interface.</div>
     */
    @PublishedMethod
    void application();

    /**
     * <div class="extdoc" id="service">{@link #service()} matches component ports whose port interface is an service port interface.</div>
     */
    @PublishedMethod
    void service();

    /**
     * <div class="extdoc" id="applicationComponent">{@link #applicationComponent()} matches component ports whose component type is an application component type. Application
     * component types are all component types which are not service component types, as displayed in the ECU Software Components Editor, not ApplicationSwComponentTypes as
     * defined by AUTOSAR.</div>
     */
    @PublishedMethod
    void applicationComponent();

    /**
     * <div class="extdoc" id="serviceComponent">{@link #serviceComponent()} matches component ports whose component type is a service component type.</div>
     */
    @PublishedMethod
    void serviceComponent();

    /**
     * <div class="extdoc" id="parameterComponent">{@link #parameterComponent()} matches component ports whose component type is a parameter component type.</div>
     */
    @PublishedMethod
    void parameterComponent();

    /**
     * <div class="extdoc" id="nvBlockComponent">{@link #nvBlockComponent()} matches component ports whose component type is a nv block component type.</div>
     */
    @PublishedMethod
    void nvBlockComponent();

    /**
     * <div class="extdoc" id="sensorActuatorComponent">{@link #sensorActuatorComponent()} matches component ports whose component type is a sensor actuator component
     * type.</div>
     */
    @PublishedMethod
    void sensorActuatorComponent();

    /**
     * <div class="extdoc" id="ioHwAbstractionComponent">{@link #ioHwAbstractionComponent()} matches component ports whose component type is a I/O hardware abstraction component
     * type, also called EcuAbstractionSwComponentType.</div>
     */
    @PublishedMethod
    void ioHwAbstractionComponent();

    /**
     * <div class="extdoc" id="complexDeviceDriverComponent">{@link #complexDeviceDriverComponent()} matches component ports whose component type is a complex device driver
     * component type.</div>
     */
    @PublishedMethod
    void complexDeviceDriverComponent();

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<IComponentPort> getSelectedPorts();

    @KeepSecretFromPublishedApi
    IDescriptivePredicate<IPortInterfaceMapping<?>> getLastSetPortInterfaceMappingPredicate();

}
