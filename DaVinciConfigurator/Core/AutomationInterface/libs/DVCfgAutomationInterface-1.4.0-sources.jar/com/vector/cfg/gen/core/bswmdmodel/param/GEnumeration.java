package com.vector.cfg.gen.core.bswmdmodel.param;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasIllegalValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasNoValueException;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractEnumeration;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.gen.core.utils.formatting.primitives.EnumGenElement;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;

/**
 * Enumeration parameter of a definition typed bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GEnumeration<T extends Enum<T>>extends GAbstractEnumeration<T> {

    private final Class<T> enumType;

    private String value;

    /**
     * Constructor.
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GEnumeration(DefRef defRef, MITextualValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, Class<T> enumType, boolean onlyOneElement) {
        super(defRef, parameter, modelAccess, parent, onlyOneElement);
        this.enumType = enumType;

    }

    @PublishedMethod
    public GEnumeration(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MITextualValue parameter, GIContainer parent, Class<T> enumType, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);
        this.enumType = enumType;

    }

    /**
     * Returns the parameters value as Enumeration literal (Java enum instance).
     *
     * @return The value object
     *
     * @exception BswmdModelParameterHasNoValueException
     * <ul>
     * <li>if the value of the parameter is null</li>
     * </ul>
     * @exception BswmdModelParameterHasIllegalValueException
     * <ul>
     * <li>if the value of the parameter is illegal</li>
     * </ul>
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    public T getValue() {
        /*
         * The call to Enum.valueOf is safe, because we have already checked the value in the getValueMdf() method.
         */
        final T enumValue = Enum.valueOf(enumType, getValueMdf());
        return enumValue;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getValueMdf() {
        if (isValueChecked()) {
            return value;
        }
        try {
            switchView();

            final String valueLoc = getValueInternal();
            getModelVerifier().assertParameterValueNotNull(this, valueLoc);
            getModelVerifier().assertEnumerationHasLegalLiteral(this, enumType, valueLoc);

            value = valueLoc;
            setValueChecked();
            return value;

        } finally {
            restoreView();
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public EnumGenElement formatValue() {
        return F.formatEnum(getValue());
    }
}
