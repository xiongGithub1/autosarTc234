package com.vector.cfg.dom.runtimesys.groovy.api;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * <div class="extdoc" id="ITaskMapper"><!--Label:ITaskMapper-->{@link ITaskMapper} provides an Api to control and evaluate the task mapping.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITaskMapper {

    /**
     * <div class="extdoc" id="selectTask"><!--Label:ITaskMapper.selectTask-->{@link #selectTask(Closure)} allows to define predicates to select a task for the task
     * mapping.</div>
     *
     * @param code The code to select a task.
     * @throws SelectionException if the selection is not narrowed down to exactly one task.
     */
    @PublishedMethod
    void selectTask(@Nonnull @VDelegatesToWithClosureParam(ITaskSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="filterTaskMappings"><!--Label:ITaskMapper.filterTaskMappings-->{@link #filterTaskMappings(Closure)} allows to filter the task mappings that should
     * be created. This might be especially helpful to narrow down the task mappings after selecting events or executable entities when using multi instantiation (e.g. to filter
     * the task mappings for only one instance of a multi instantiated component prototype).</div>
     *
     * @param code The code to filter task mappings.
     */
    @PublishedMethod
    void filterTaskMappings(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="selectExecutionOrderConstraints"><!--Label:ITaskMapper.selectExecutionOrderConstraints-->{@link #selectExecutionOrderConstraints(Closure)} allows
     * to define predicates to select execution order constraints that should be applied.</div>
     *
     * @param code The code to select execution order constraints.
     */
    @PublishedMethod
    void selectExecutionOrderConstraints(@Nonnull @VDelegatesToWithClosureParam(IExecutionOrderConstraintSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="order"><!--Label:ITaskMapper.order-->{@link #order(Closure)} allows to evaluate and change the order of the task mappings.
     * <p>
     * It provides a possibility to order the already existing task mappings of the selected task and the new task mappings that should be created.
     * </p>
     * </div>
     *
     * @param code The code to define an order of the task mappings.
     */
    @PublishedMethod
    void order(
            @ClosureParams(value = FromString.class, options = "java.util.List<com.vector.cfg.model.sysdesc.api.taskmapping.IPositionInTaskEntry>") @Nonnull Closure<?> code);

    /**
     * <div class="extdoc" id="combineViaSymbol"><!--Label:ITaskMapper.combineViaSymbol-->{@link #combineViaSymbol(boolean)} determines whether the BswModuleEntities and the
     * RunnableEntities should be combined using their symbol. That means they will be mapped to the same position on the same task. It is enough to select only the
     * RunnableEntity or only the BswModuleEntity, when using this option both will be mapped. The default is true.
     * <p>
     * The condition is that the symbol of a RunnableEntity and the BswModuleEntry short name of a BswModuleEntity are equal.
     * </p>
     * </div>
     *
     * @param doCombine True if runnable and bsw module entities should be mapped together.
     */
    @PublishedMethod
    void combineViaSymbol(boolean doCombine);

    /**
     * <div class="extdoc" id="mapAllEventsOfRunnableEntity"><!--Label:ITaskMapper.mapAllEventsOfRunnableEntity-->{@link #mapAllEventsOfRunnableEntity(boolean, boolean)} is a
     * possibility to map all events of a RunnableEntity to the same position on a task. In case of the selection of events, the task mapping will be extended, by all events
     * (triggers) of runnable entities (functions) for which at least one event (trigger) is selected.
     * <p>
     * With help of the two boolean arguments, the behavior of ignoring already mapped events and ignoring events whose mapping is optional can be controlled.
     * </p>
     * </div>
     *
     * @param considerUnmappedOnly If true, only unmapped events, if false all events will be added to the selection.
     * @param considerMappingIsOptional If true events whose mapping is optional will not be added, if false all events will be added to the selection.
     */
    @PublishedMethod
    void mapAllEventsOfRunnableEntity(boolean considerUnmappedOnly, boolean considerMappingIsOptional);

    @KeepSecretFromPublishedApi
    Closure<?> getSelectTaskCode();

    @KeepSecretFromPublishedApi
    Closure<?> getFilterTaskMappingsCode();

    @KeepSecretFromPublishedApi
    Closure<?> getSelectEOCsCode();

    @KeepSecretFromPublishedApi
    Closure<?> getOrderCode();

    @KeepSecretFromPublishedApi
    boolean isCombineViaSymbol();

    @KeepSecretFromPublishedApi
    boolean isMapAllEventsOfRunnableEntity();

    @KeepSecretFromPublishedApi
    boolean isConsiderUnmappedOnly();

    @KeepSecretFromPublishedApi
    boolean isConsiderMappingIsOptional();
}
