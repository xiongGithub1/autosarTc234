package com.vector.cfg.gen.core.utils.formatting.structures;

import java.util.ArrayList;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.GenConstants;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.IListGenElement;
import com.vector.cfg.gen.core.utils.formatting.IPrimitiveGenElement;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractGenElement;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractPrimitiveElement;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.gen.core.utils.formatting.primitives.IntGenElement;
import com.vector.cfg.gen.core.utils.formatting.primitives.StringGenElement;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The Format class for define lists.
 *
 * <p>
 * Example: <br/>
 * <code><pre>
 * #define CHL_1
 * #define My_CHL2
 * #define CHL_503
 * </pre></code>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractGenList<LIST extends AbstractGenList<LIST, ELEM>, ELEM extends AbstractGenElement<ELEM>> extends AbstractGenElement<LIST> implements IListGenElement {

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractGenList.class);

    private final List<ELEM> genList = new ArrayList<>();

    private String header;

    private String footer;

    /**
     * Getter method for genList.
     *
     * @return Returns the genList.
     */
    @PublishedMethod
    protected List<ELEM> getGenList() {
        return genList;
    }

    AbstractGenList() {

    }

    /**
     * Creates the new list element.
     *
     * @param elem1 the elem1
     * @param elem2 the elem2
     * @return the elem
     */
    @PublishedMethod
    protected abstract ELEM createNewListElement(AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> elem1,
            AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> elem2);

    /**
     * Returns the number of defines in this define list.
     *
     * @return the number of defines in this define list
     */
    @PublishedMethod
    public int size() {
        return genList.size();
    }

    /**
     * Returns true, if the Array is Empty, otherwise false.
     *
     * @return Returns true, if the Array is Empty, otherwise false.
     */
    @PublishedMethod
    public boolean isEmpty() {
        return genList.size() == 0;
    }

    /**
     * Appends the element to the end of the list.
     *
     * @param define The element to add
     * @return The current GenList
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public LIST append(String define) {
        ensureObjectIsMutable();

        if (define == null) {
            throw new IllegalArgumentException("define is null");
        }

        final StringGenElement string = F.formatString(define);

        genList.add(createNewListElement(string, null));
        return (LIST) this;
    }

    /**
     * Appends the element to the end of the list.
     *
     * @param define The element to add
     * @return The current GenList
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public LIST append(StringGenElement define) {
        ensureObjectIsMutable();

        if (define == null) {
            throw new IllegalArgumentException("define is null");
        }

        genList.add(createNewListElement(define, null));
        return (LIST) this;
    }

    /**
     * Appends the element to the end of the list.
     *
     * @param define The element to add
     * @param value The value of the element
     * @return The current GenList
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public LIST append(String define, int value) {
        ensureObjectIsMutable();

        if (define == null) {
            throw new IllegalArgumentException("define is null");
        }

        final StringGenElement string = F.formatString(define);
        final IntGenElement val = F.formatInt(value);

        genList.add(createNewListElement(string, val));
        return (LIST) this;
    }

    /**
     * Appends the element to the end of the list.
     *
     * @param define The element to add
     * @param value The value of the element
     * @return The current GenList
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public LIST append(String define, String value) {
        ensureObjectIsMutable();

        if (define == null) {
            throw new IllegalArgumentException("define is null");
        }
        if (value == null) {
            throw new IllegalArgumentException("value is null");
        }

        final StringGenElement defineObj = F.formatString(define);
        final StringGenElement valueObj = F.formatString(value);

        genList.add(createNewListElement(defineObj, valueObj));
        return (LIST) this;
    }

    /**
     * Appends the element to the end of the list.
     *
     * @param define The element to add
     * @param value The value of the element
     * @return The current GenList
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public LIST append(StringGenElement define, IPrimitiveGenElement value) {
        ensureObjectIsMutable();

        if (define == null) {
            throw new IllegalArgumentException("define is null");
        }
        if (value == null) {
            throw new IllegalArgumentException("value is null");
        }

        genList.add(createNewListElement(define, (AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>>) value));
        return (LIST) this;
    }

    /**
     * Appends the element to the end of the list.
     *
     * @param define The element to add
     * @param value The value of the element
     * @return The current GenList
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public LIST append(String define, IPrimitiveGenElement value) {
        ensureObjectIsMutable();

        if (define == null) {
            throw new IllegalArgumentException("define is null");
        }
        if (value == null) {
            throw new IllegalArgumentException("value is null");
        }

        final StringGenElement defineObj = F.formatString(define);

        genList.add(createNewListElement(defineObj, (AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>>) value));
        return (LIST) this;
    }

    /**
     * Appends the element to the end of the list.
     *
     * @param listElement the list element
     * @return The current GenList
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public LIST append(ELEM listElement) {
        ensureObjectIsMutable();

        if (listElement == null) {
            throw new IllegalArgumentException("listElement is null");
        }

        genList.add(listElement);
        return (LIST) this;
    }

    /**
     * Append a GenList to this list.
     *
     * @param listToAppend the {@link GenDefineList} to append on this list.
     * @return This list.
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public LIST appendAll(LIST listToAppend) {

        for (final ELEM elem : listToAppend.getGenList()) {
            append(elem);
        }

        return (LIST) this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void generatePrefixComment(StringBuilder builder) {
        super.generatePrefixComment(builder);
        if (getPrefixComment() != null) {
            // Append a newline => The comment should be above the list content instead at the beginning of the line.
            builder.append(GenConstants.LINE_SEPARATOR);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    public LIST header(String headerParam) {
        ensureObjectIsMutable();

        if (headerParam == null) {
            throw new IllegalArgumentException("headerParam is null");
        }

        if (header != null) {
            throw new IllegalStateException("The header was already set.");
        }

        this.header = headerParam;

        return (LIST) this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    public LIST footer(String footerParam) {
        ensureObjectIsMutable();

        if (footerParam == null) {
            throw new IllegalArgumentException("footerParam is null");
        }

        if (footer != null) {
            throw new IllegalStateException("The footer was already set.");
        }

        this.footer = footerParam;

        return (LIST) this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    protected void generateHeader(StringBuilder builder, IGenFormatter formatter, int indent, IListGenElement genElement) {
        if (header != null) {
            formatter.formatPreHeader(builder, indent, genElement);
            builder.append(header);
            formatter.formatPostHeader(builder, indent, genElement);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    protected void generateFooter(StringBuilder builder, IGenFormatter formatter, int indent, IListGenElement genElement) {
        if (footer != null) {
            formatter.formatPreFooter(builder, indent, genElement);
            builder.append(footer);
            formatter.formatPostFooter(builder, indent, genElement);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected abstract void generateInternal(StringBuilder builder, IGenFormatter formatter, int indent, boolean rootElement);

}
