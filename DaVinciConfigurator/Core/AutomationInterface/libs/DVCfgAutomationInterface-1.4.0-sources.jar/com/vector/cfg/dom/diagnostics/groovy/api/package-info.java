/**
 * The diagnostics domain API is specifically designed to support diagnostics related use cases.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.dom.diagnostics.groovy.api;