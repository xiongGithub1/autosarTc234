package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.variants.IGenPostBuildSelectableVariantsService;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.IReferrableAccess;
import com.vector.cfg.model.access.ecucdefinition.IEcucDefinitionAccess;
import com.vector.cfg.model.access.ecuconfiguration.IEcuConfigurationAccess;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.IProjectContext;

/**
 * This interface defines the available model access services for the bswmd model.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIModelAccess {
    // CHECKSTYLE:ON
    /**
     * Returns the corresponding {@link GIModelFactory} of this model part.
     *
     * @return the factory, which was used to create this {@link GIModelAccess}.
     */
    @PublishedMethod
    GIModelFactory getFactory();

    /**
     * Gets the exception creator.
     *
     * <p>
     * <b>THIS IS FOR FRAMEWORK INTERNAL USE ONLY. Do not call this method!</b>
     * </p>
     *
     * @return the exception creator
     */
    @PublishedMethod
    GIExceptionCreator getExceptionCreator();

    /**
     * Returns the MDF model access service.
     *
     * <p>
     * Please make sure, that the creation {@link IModelView} is active when calling this method.
     * </p>
     *
     * @return the MDF {@link IModelAccess}.
     *
     * @exception IllegalStateException <ul>
     * <li>if the current active {@link IModelView} is not the creation model view of the {@link GIModelAccess}.</li>
     * </ul>
     *
     */
    @PublishedMethod
    IModelAccess getMdfModelAccess();

    /**
     * Returns the MDF {@link IModelCheckedAccess}.
     *
     * <p>
     * Please make sure, that the creation {@link IModelView} is active when calling this method.
     * </p>
     *
     * @return the MDF {@link IModelCheckedAccess}.
     *
     * @exception IllegalStateException <ul>
     * <li>if the current active {@link IModelView} is not the creation model view of the {@link GIModelAccess}.</li>
     * </ul>
     */
    @PublishedMethod
    IModelCheckedAccess getMdfModelCheckedAccess();

    /**
     * Returns the MDF referrable access service.
     *
     * <p>
     * Please make sure, that the creation {@link IModelView} is active when calling this method.
     * </p>
     *
     * @return the MDF {@link IReferrableAccess}.
     *
     * @exception IllegalStateException <ul>
     * <li>if the current active {@link IModelView} is not the creation model view of the {@link GIModelAccess}.</li>
     * </ul>
     */
    @PublishedMethod
    IReferrableAccess getMdfReferrableAccess();

    /**
     * Returns the {@link IProjectContext}.
     *
     * @return the project context
     */
    @PublishedMethod
    IProjectContext getProjectContext();

    /**
     * Returns the the {@link IModelViewManager}.
     *
     * @return
     */
    @PublishedMethod
    IModelViewManager getModelViewManager();

    /**
     * Returns the {@link IGenPostBuildSelectableVariantsService}.
     *
     * @return the service.
     */
    @PublishedMethod
    IGenPostBuildSelectableVariantsService getGenPostBuildSelectableVariantsService();

    /**
     * Returns the {@link IEcucDefinitionAccess}.
     *
     * @return the service.
     */
    @PublishedMethod
    IEcucDefinitionAccess getEcucDefinitionAccess();

    /**
     * Returns the {@link IEcuConfigurationAccess}.
     *
     * @return the service.
     */
    @PublishedMethod
    IEcuConfigurationAccess getEcuConfigurationAccess();

    /**
     * Gets the corresponding BswmdModel {@link GIModelObject} by an MDF configuration element, or creates the BswmdModel {@link GIModelObject}, if it does not
     * exist.
     *
     *
     * @param mdfCfgElement the MDF element to wrap in a {@link GIModelObject}.
     * @param defRef The DefRef of the passed element.
     * @return The corresponding bswmd model object of the passed element.
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the mdfCfgElement is not an instance of the passed defRef.</li>
     * <li>if the mdfCfgElement is null.</li>
     * <li>if the defRef is null.</li>
     * </ul>
     */
    @PublishedMethod
    GIModelObject getGenModelObjectByMDFObject(MIHasDefinition mdfCfgElement, DefRef defRef);

    /**
     * Gets the corresponding BswmdModel {@link GIModelObject} by an MDF configuration element, or creates the BswmdModel {@link GIModelObject}, if it does not
     * exist.
     *
     *
     * @param mdfCfgElement the MDF element to wrap in a {@link GIModelObject}.
     * @return The corresponding bswmd model object of the passed element.
     */
    @PublishedMethod
    GIModelObject getGenModelObjectByMDFObject(MIHasDefinition mdfCfgElement);

}
