package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.model.sysdesc.api.com.IDataCommunicationElement;
import com.vector.cfg.model.sysdesc.api.com.IDataMapping;
import com.vector.cfg.model.sysdesc.api.com.IOperationCommunicationElement;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="ICommunicationElementSelection"><!--Label:ICommunicationElementSelection-->{@link ICommunicationElementSelection} represents a selection of
 * {@link ICommunicationElement}s and the possible operations on these communication elements.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICommunicationElementSelection {

    /**
     * <div class="extdoc" id="autoMapTo"><!--Label:ICommunicationElementSelection.autoMapTo-->{@link #autoMapTo(Closure)} tries to auto-map the selection of communciation
     * elements according the data mapping assistant rules but offers more control for the auto-mapping: Inside the closure additional predicates for narrowing down the target
     * signal instances can be defined and code to evaluate and change the auto-mapper results can be provided.
     * <p>
     * {@link #autoMapTo(Closure)} will produce trace, info and warning logs. To see them, activate the
     * '{@link com.vector.cfg.dom.runtimesys.groovy.api.ICommunicationElementSelection}' logger with the appropriate log level.
     * </p>
     * </div>
     *
     * @param code The code to provide target predicates or evaluate matches.
     * @return A list of created data mappings.
     */
    @PublishedMethod
    <T extends IDataMapping> List<T> autoMapTo(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementAutoMapper.class) Closure<?> code);

    /**
     * <div class="extdoc" id="autoMap"><!--Label:ICommunicationElementSelection.autoMap-->{@link #autoMap()} tries to auto-map the selection of {@link ICommunicationElement}s
     * ({@link IDataCommunicationElement} or {@link IOperationCommunicationElement}) according the data mapping assistant default rules. Therefore the selection of possible
     * target signal instances is computed and tried to match to the selected communciation elements.</div>
     *
     * @return A list of created data mappings.
     */
    @PublishedMethod
    <T extends IDataMapping> List<T> autoMap();

    /**
     * Allows access to the single communication elements in the {@link ICommunicationElementSelection}.
     *
     * @return The collection of selected communication elements.
     */
    @PublishedMethod
    <T extends ICommunicationElement> Collection<T> getCommunicationElements();

}
