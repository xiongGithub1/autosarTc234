package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.taskmapping.ITaskMapping;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link ITaskMappingSelector} Api allows the definition of predicates for {@link ITaskMapping} selection.
 * <p>
 * <div class="extdoc" id="ITaskMappingSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITaskMappingSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="component">{@link #component(String)} matches task mappings whose event is part of the internal behavior of a component with the given component
     * name.</div>
     *
     * @param name A component name.
     */
    @PublishedMethod
    void component(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} matches task mappings whose event is part of the internal behavior of a component with the given
     * component name pattern.</div>
     *
     * @param namePattern A component name pattern.
     */
    @PublishedMethod
    void component(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="moduleConfiguration">{@link #moduleConfiguration(String)} matches task mappings whose event is part of the internal behavior of a module
     * configuration with the given module configuration name.</div>
     *
     * @param name A component name.
     */
    @PublishedMethod
    void moduleConfiguration(@Nonnull String name);

    /**
     * <div class="extdoc" id="moduleConfigurationPattern">{@link #moduleConfiguration(Pattern)} matches task mappings whose event is part of the internal behavior of a module
     * configuration with the given module configuration name pattern.</div>
     *
     * @param namePattern A component name pattern.
     */
    @PublishedMethod
    void moduleConfiguration(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="moduleConfigurationAsrPath">{@link #moduleConfigurationAsrPath(String)} matches task mappings whose event is part of the internal behavior of a
     * module configuration with the given module configuration autosar path.</div>
     *
     * @param asrPath A module configuration autosar path.
     */
    @PublishedMethod
    void moduleConfigurationAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="moduleConfigurationAsrPathPattern">{@link #moduleConfigurationAsrPath(Pattern)} matches task mappings whose event is part of the internal behavior
     * of a module configuration with the given module configuration autosar path pattern.</div>
     *
     * @param asrPath A module configuration autosar path.
     */
    @PublishedMethod
    void moduleConfigurationAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="unmapped">{@link #unmapped()} matches task mappings which are not mapped to a task.</div>
     */
    @PublishedMethod
    void unmapped();

    /**
     * <div class="extdoc" id="mapped">{@link #mapped()} matches task mappings which are mapped to a task.</div>
     */
    @PublishedMethod
    void mapped();

    /**
     * <div class="extdoc" id="task">{@link #task(String)} matches task mappings which are mapped to a task with the given task name.</div>
     *
     * @param name A task name.
     */
    @PublishedMethod
    void task(@Nonnull String name);

    /**
     * <div class="extdoc" id="taskPattern">{@link #task(Pattern)} matches task mappings which are mapped to a task whose name matches the given task name pattern.</div>
     *
     * @param name A task name pattern.
     */
    @PublishedMethod
    void task(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches task mappings for which the given closure results to true.</div>
     *
     * @param code The closure to select task mappings.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(ITaskMapping.class) Closure<Boolean> code);

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<ITaskMapping> getSelectedTaskMappings();

}
