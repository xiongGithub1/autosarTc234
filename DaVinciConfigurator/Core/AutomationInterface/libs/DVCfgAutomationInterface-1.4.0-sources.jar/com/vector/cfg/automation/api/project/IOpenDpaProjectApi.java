package com.vector.cfg.automation.api.project;

import java.nio.file.Path;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.ScriptConverters;

/**
 * {@link IOpenDpaProjectApi} provides means for parameterizing the process of opening a dpa project.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IOpenDpaProjectApi extends IOpenProjectApi {

    /**
     * Alias for {@link #setDpaFile(Object)}.
     */
    @PublishedMethod
    void dpaFile(Object dpaFile);

    /**
     * Sets the .dpa file of the project to be opened.
     *
     * <div class="extdoc" id="setDpaFile"><!--Label:IOpenProjectApi.setDpaFile-->
     * <h5>DPA File</h5> The method {@link #setDpaFile(Object)} sets the .dpa file of the project to be opened. The value given here is converted to {@link Path} using
     * {@link ScriptConverters#TO_SCRIPT_PATH} <!--Ref:ScriptConverters.TO_SCRIPT_PATH-->.</div>
     *
     * @param dpaFile the .dpa file of the project to be opened
     */
    @PublishedMethod
    void setDpaFile(Object dpaFile);

    /**
     * Alias for {@link #setLoadGenerators(boolean)}.
     *
     * @param generators the generators
     */
    @PublishedMethod
    void loadGenerators(boolean generators);

    /**
     * Specified whether or not to activate generators (including their validations) for the opened project.
     *
     * <div class="extdoc" id="setLoadGenerators"><!--Label:IOpenProjectApi.setLoadGenerators-->
     * <h5>Generators</h5> Using {@link #setLoadGenerators(boolean)} specifies whether or not to activate generators (including their validations) for the opened project.
     *
     * </div>
     *
     * @param generators whether or not to activate generators (including their validations) for the project
     */
    @PublishedMethod
    void setLoadGenerators(boolean generators);

    /**
     * Alias for {@link #setEnableValidation(boolean)}.
     *
     * @param validation the validation
     */
    @PublishedMethod
    void enableValidation(boolean validation);

    /**
     * USpecified whether or not to activate validation for the opened project.
     *
     * <div class="extdoc" id="setEnableValidation"><!--Label:IOpenProjectApi.setEnableValidation-->
     * <h5>Validation</h5> {@link #setEnableValidation(boolean)} specifies whether or not to activate validation for the opened project.
     *
     * </div>
     *
     * @param validation
     */
    @PublishedMethod
    void setEnableValidation(boolean validation);

}
