package com.vector.cfg.gen.core.bswmdmodel.param;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasIllegalValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasNoValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelReferenceTargetException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelWrongQuantityException;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractRef;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IReferenceAccess;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucInstanceRefDefinition;
import com.vector.cfg.model.access.ecuconfiguration.reference.IEcucInstanceReferenceParameter;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrableARRef;
import com.vector.cfg.model.mdf.model.autosar.base.MIARAnyInstanceRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIInstanceReferenceParamDef;

/**
 * InstanceReference parameter of a bswmd model.
 *
 * <p>
 * This class wraps {@link MIInstanceReferenceValue} parameters
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GInstanceReference extends GAbstractRef<MIReferrable> {

    private List<MIReferrableARRef> context = null;

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public GInstanceReference(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MIInstanceReferenceValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);

    }

    @Override
    @PublishedMethod
    protected void initRef() {
        final MIInstanceReferenceValue mdfObjLoc = getMdfObject();
        if (mdfObjLoc != null) {
            final MIARAnyInstanceRef instanceRef = mdfObjLoc.getValue();
            if (instanceRef != null) {
                context = instanceRef.getContext();
                final MIReferrableARRef ref = instanceRef.getTarget();
                if (ref != null) {
                    setPath(ref.getValue());
                    setTarget(ref.getRefTarget());
                }
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MIInstanceReferenceValue getMdfObjectUnsafe() {
        return (MIInstanceReferenceValue) super.getMdfObjectUnsafe();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIInstanceReferenceValue getMdfObject() {
        return (MIInstanceReferenceValue) super.getMdfObject();
    }

    /**
     * Returns true, if the underlying {@link MIInstanceReferenceValue} has a context list and the list has at least one context entry.
     *
     * @return Return true, if the reference has at least one context, otherwise false.
     */
    @PublishedMethod
    public boolean hasContext() {
        try {
            checkForInitialization();
            return context != null && !context.isEmpty();
        } catch (final BswmdModelNotExistsException
                | BswmdModelParameterHasNoValueException
                | BswmdModelParameterHasIllegalValueException
                | BswmdModelReferenceTargetException
                | BswmdModelWrongQuantityException ex) {
            return false;
        }
    }

    /**
     * Gets a list of context objects.
     *
     * <p>
     * Use {@link IReferenceAccess#getRefTarget(com.vector.cfg.model.mdf.commoncore.autosar.MIARRef)} to resolve the targets of the context objects.
     * </p>
     *
     * @return the list of context objects.
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the reference does not exist</li>
     * </ul>
     * @exception BswmdModelReferenceTargetException
     * <ul>
     * <li>if the reference has no valid context objects</li>
     * </ul>
     */
    @PublishedMethod
    public List<MIReferrableARRef> getContext() {
        try {
            switchView();

            checkForInitialization();
            getModelVerifier().assertReferenceContextNotNull(this, context);
            return context;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIInstanceReferenceParamDef getDefinition() {
        return (MIInstanceReferenceParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucInstanceRefDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucInstanceReferenceParameter getEcuConfiguration() {

        return getGeneratorModelAccess().getEcuConfigurationAccess().cfg(getMdfObject());
    }

}
