package com.vector.cfg.model.abstraction.api;

import java.util.Set;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.ar4x.swcomponenttemplate.composition.MIAssemblySwConnector;
import com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable;

/**
 * <p>
 * <div class="extdoc" id="IModelAbstraction" data-target-doc= "AutomationInterfaceDocumentation"><!--Label:IModelAbstraction.IModelAbstraction-->{@link IModelAbstraction} is
 * the common super interface for all model abstractions (as e.g. {@link Object} for all java classes). It defines common functionality which all model abstractions provide for
 * generic handling of model abstractions.</div>
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IModelAbstraction extends IHasModelObject {

    /**
     * {@link #getIdentifyingObjects()} is a bridge from the {@link IModelAbstraction} to the underlying MDF objects. For compound model abstractions e.g. a component port, not
     * only the port, but also the component will be returned.
     *
     * @return The set of identifying MDF objects for this object.
     */
    @PublishedMethod
    Set<MIObject> getIdentifyingObjects();

    /**
     * <p>
     * A name that can be used to classify/group the model abstraction for the user.
     * </p>
     *
     * @return A user readable name of type of abstraction (e.g. "Connector", "Port", etc).
     */
    @PublishedMethod
    String getNameOfAbstractionType();

    /**
     * User readable name of the model abstractions. For model abstraction which have no name a descriptive identifying name is returned.
     *
     * @return An identifying name for the model abstraction.
     */
    @PublishedMethod
    String getIdentifyingName();

    /**
     * User readable name of the model abstractions with additional variance information.
     *
     * @return The combination of {@link #getIdentifyingName()} and {@link #getVarianceInformationString()}.
     */
    @PublishedMethod
    String getIdentifyingNameWithVarianceInformation();

    /**
     * Computes the variance information string in case the project supports variance and the object directly has a variation point.
     *
     * @return The variant string in form "{variantA,variantB}" or an empty string if no variance is contained.
     */
    @PublishedMethod
    String getVarianceInformationString();

    /**
     *
     * @return True if the underlying MDFObject is removed, false otherwise.
     */
    @PublishedMethod
    boolean isRemoved();

    /**
     * {@inheritDoc}
     *
     * <div class="extdoc" id="getMdfObject" data-target-doc= "AutomationInterfaceDocumentation"><!--Label:IModelAbstraction.getMdfObject-->{@link #getMdfObject()} is a bridge
     * from the {@link IModelAbstraction} to the underlying MDF object. For compound model abstractions, the main object will be returned, e.g. returns the port for a component
     * port.</div>
     *
     * <p>
     * The returned MIObject is as most specific as possible (e.g. {@link MIIdentifiable}) but AUTOSAR version independent. For more advanced features, it has to be cast to the
     * actual used element (e.g. {@link MIAssemblySwConnector}) according to AUTOSAR. This can be determined by {@link MIObject#mdfGetInterfaceClass()}.
     * </p>
     *
     */
    @PublishedMethod
    @Override
    MIObject getMdfObject();
}
