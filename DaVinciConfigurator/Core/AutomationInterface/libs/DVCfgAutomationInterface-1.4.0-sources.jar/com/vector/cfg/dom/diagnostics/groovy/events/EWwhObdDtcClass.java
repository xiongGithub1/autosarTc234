package com.vector.cfg.dom.diagnostics.groovy.events;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum EWwhObdDtcClass {
    CLASS_A("DEM_DTC_WWHOBD_CLASS_A"),
    CLASS_B1("DEM_DTC_WWHOBD_CLASS_B1"),
    CLASS_B2("DEM_DTC_WWHOBD_CLASS_B2"),
    CLASS_C("DEM_DTC_WWHOBD_CLASS_C"),
    CLASS_NOCLASS("DEM_DTC_WWHOBD_CLASS_NOCLASS");

    private final String type;

    EWwhObdDtcClass(String type) {
        this.type = type;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        return type;
    }
}
