package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.model.sysdesc.api.com.IDataMapping;
import com.vector.cfg.model.sysdesc.api.com.ISignalGroupInstance;
import com.vector.cfg.model.sysdesc.api.com.ISignalInstance;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="ISignalInstanceSelection"><!--Label:ISignalInstanceSelection-->{@link ISignalInstanceSelection} represents a selection of
 * {@link IAbstractSignalInstance}s ({@link ISignalInstance} and {@link ISignalGroupInstance}) and the possible operations on these signal instances.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISignalInstanceSelection {

    /**
     * <div class="extdoc" id="autoMapTo"><!--Label:ISignalInstanceSelection.autoMapTo-->{@link #autoMapTo(Closure)} tries to auto-map the selection of signal instances
     * according the data mapping assistant rules but offers more control for the auto-mapping: Inside the closure additional predicates for narrowing down the target
     * communication elements can be defined and code to evaluate and change the auto-mapper results can be provided.
     * <p>
     * {@link #autoMapTo(Closure)} will produce trace, info and warning logs. To see them, activate the
     * '{@link com.vector.cfg.dom.runtimesys.groovy.api.ISignalInstanceSelection}' logger with the appropriate log level.
     * </p>
     * </div>
     *
     * @param code The code to provide target predicates or evaluate matches.
     * @return A list of created data mappings.
     */
    @PublishedMethod
    <T extends IDataMapping> List<T> autoMapTo(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceAutoMapper.class) Closure<?> code);

    /**
     * <div class="extdoc" id="autoMap"><!--Label:ISignalInstanceSelection.autoMap-->{@link #autoMap()} tries to auto-map the selection of {@link IAbstractSignalInstance}s
     * ({@link ISignalInstance} or {@link ISignalGroupInstance}) according the data mapping assistant default rules. Therefore the selection of possible target communication
     * elements is computed and tried to match to the selected signal instances.</div>
     *
     * @return A list of created data mappings.
     */
    @PublishedMethod
    <T extends IDataMapping> List<T> autoMap();

    /**
     * Allows access to the single signal instances in the {@link ISignalInstanceSelection}.
     *
     * @return The collection of selected signal instances.
     */
    @PublishedMethod
    <T extends IAbstractSignalInstance> Collection<T> getSignalInstances();

}
