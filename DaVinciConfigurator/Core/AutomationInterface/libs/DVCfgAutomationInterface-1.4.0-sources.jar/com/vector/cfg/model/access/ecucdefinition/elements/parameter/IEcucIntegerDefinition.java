package com.vector.cfg.model.access.ecucdefinition.elements.parameter;

import java.math.BigInteger;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIIntegerParamDef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucIntegerDefinition extends IEcucParameterDefinition {

    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    MIIntegerParamDef getDef();

    /**
     * returns the optional default value. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<BigInteger> getDefault();

    /**
     * returns the optional min value. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<BigInteger> getMinValue();

    /**
     * returns the optional max value. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<BigInteger> getMaxValue();

}
