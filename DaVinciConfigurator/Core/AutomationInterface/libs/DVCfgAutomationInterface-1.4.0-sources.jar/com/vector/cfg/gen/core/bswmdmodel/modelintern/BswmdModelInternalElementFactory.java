package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIChoiceContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIHasContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIList;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIParamOrRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.operations.EModelOperationCreationOptions;
import com.vector.cfg.model.operations.IModelOperations;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.davinci.util.base.VUtil;

/**
 * Provides methods to get {@link GIContainer}/{@link GIParamOrRef} from the MDF model and methods to create new {@link GIContainer}/{@link GIParamOrRef}/{@link GIList} objects
 * with corresponding objects in the MDF model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class BswmdModelInternalElementFactory {

    /**
     * Constructor is private because this factory only provides static methods.
     */
    private BswmdModelInternalElementFactory() {
    }

    // Public section

    // Get/Initialize (from MDF) methods

    /**
     * Gets the specified (by bswmdObjectCreator) container from MDF.
     *
     * @param <VALUE> the generic type
     * @param parent the parent
     * @param defRef the def ref
     * @param bswmdObjectCreator the bswmd object creator
     * @return the cont
     */
    @PublishedMethod
    public static <VALUE extends GIContainer> VALUE initializeReqOptContainer(GAbstractHasContainer parent, TypedDefRef<?, ? extends MIHasDefinition, ?> defRef,
            ICreateGIModelObjectFunction<VALUE> bswmdObjectCreator) {

        return BswmdModelInternalElementInitializer.initializeReqOptCont(parent, defRef, bswmdObjectCreator);
    }

    /**
     * Gets the specified (by bswmdObjectCreator) parameter from MDF.
     *
     * @param <BSWMD> the generic type
     * @param parent the parent
     * @param defRef the def ref
     * @param bswmdObjectCreator the bswmd object creator
     * @return the param
     */
    @PublishedMethod
    public static <BSWMD extends GIParamOrRef> BSWMD initializeReqOptParameter(GAbstractHasContainer parent, TypedDefRef<?, ? extends MIHasDefinition, ?> defRef,
            ICreateGIModelObjectFunction<BSWMD> bswmdObjectCreator) {

        return BswmdModelInternalElementInitializer.initializeReqOptParam(parent, defRef, bswmdObjectCreator);
    }

    // Create new GIList objects methods

    /**
     * Creates a new {@link GPListImpl} object.
     *
     * @param <VALUE> the generic type
     * @param parent the parent
     * @param defRef the def ref
     * @param bswmdObjectCreator the bswmd object creator
     * @return the GPListImpl
     */
    @PublishedMethod
    public static <VALUE extends GIParamOrRef> GIInternalPList<VALUE> createGPList(GAbstractHasContainer parent, TypedDefRef<?, ? extends MIHasDefinition, ?> defRef,
            ICreateGIModelObjectFunction<VALUE> bswmdObjectCreator) {

        return new GPListImpl<>(parent, defRef, bswmdObjectCreator);
    }

    /**
     * Creates a new {@link GCListImpl} object.
     *
     * @param <VALUE> the generic type
     * @param parent the parent
     * @param defRef the def ref
     * @param bswmdObjectCreator the bswmd object creator
     * @return the GCListImpl
     */
    @PublishedMethod
    public static <VALUE extends GIContainer> GIInternalCList<VALUE> createGCList(GAbstractHasContainer parent, TypedDefRef<?, ? extends MIHasDefinition, ?> defRef,
            ICreateGIModelObjectFunction<VALUE> bswmdObjectCreator) {

        return new GCListImpl<>(parent, defRef, bswmdObjectCreator);
    }

    // Create new conts/params methods

    /**
     * Creates a new {@link GIContainer} object in MDF model. If parent is a {@link GIChoiceContainer} a already existing choice option is deleted before the new option is
     * created.
     *
     * @param <BSWMD> the generic type
     * @param <MDF> the generic type
     * @param parent the parent
     * @param defRef the def ref
     * @param bswmdObjectCreator the bswmd object creator
     * @return the bswmd
     */
    @PublishedMethod
    public static <BSWMD extends GIContainer, MDF extends MIHasDefinition> BSWMD createCont(GIHasContainer parent, TypedDefRef<?, ? extends MIHasDefinition, ?> defRef,
            ICreateGIModelObjectFunction<BSWMD> bswmdObjectCreator) {

        final GAbstractHasContainer parentInternal = (GAbstractHasContainer) parent;

        deleteAlreadyExistingChoiceOption(parent);

        final ICreateMdfObjectFunction<MIHasDefinition> mdfModelObjectCreator = (mdfparent, def) -> getModelOperations(parentInternal).createContainerByDefinition(mdfparent, def,
                null, Integer.MAX_VALUE, EModelOperationCreationOptions.AUTO_PARAMETER_CREATION_1_TO_1_ONLY, EModelOperationCreationOptions.AUTO_CONTAINER_CREATION_1_TO_1_ONLY);

        return createGIModelObject(parentInternal, defRef, mdfModelObjectCreator, bswmdObjectCreator, null);
    }

    /**
     * Creates a new {@link GIParamOrRef} object in MDF model.
     *
     * @param <BSWMD> the generic type
     * @param <MDF> the generic type
     * @param parent the parent
     * @param defRef the def ref
     * @param bswmdObjectCreator the bswmd object creator
     * @param existingBswmd the existing bswmd
     * @return the bswmd
     */
    @PublishedMethod
    public static <BSWMD extends GIParamOrRef, MDF extends MIHasDefinition> BSWMD createParam(GIHasContainer parent, TypedDefRef<?, ? extends MIHasDefinition, ?> defRef,
            @Nullable ICreateGIModelObjectFunction<BSWMD> bswmdObjectCreator, @Nullable BSWMD existingBswmd) {

        final GAbstractHasContainer parentInternal = (GAbstractHasContainer) parent;

        final ICreateMdfObjectFunction<MIHasDefinition> mdfObjectCreator = (mdfparent, def) -> getModelOperations(parentInternal)
                .createParameterByDefinition((MIContainer) mdfparent, def);

        return createGIModelObject(parentInternal, defRef, mdfObjectCreator, bswmdObjectCreator, existingBswmd);
    }

    /**
     * This method checks if the specified parameters configuration object is available and sets the new value. If the object is missing it is implicitly created in the MDF
     * model.
     *
     * <p>
     * Secret because it is only called from classes of com.vector.cfg.gen.core.bswmdmodel. Can not set to package private because it is called form other packages of
     * bswmdmodel.
     * </p>
     *
     * @param <VALUE> the generic type
     * @param <BSWMD> the generic type
     * @param gAbstractParam the g abstract param
     * @param runnable the runnable
     */
    @KeepSecretFromPublishedApi
    public static <VALUE extends Object, BSWMD extends GIParamOrRef> void setValueMdf(GAbstractParam<VALUE> gAbstractParam, Runnable runnable) {

        if (!gAbstractParam.existsMDF()) {
            createParam(gAbstractParam.getParent(), VUtil.uncheckedCast(gAbstractParam.getDefRef()), null, VUtil.uncheckedCast(gAbstractParam));
        }

        final IModelViewManager vm = gAbstractParam.getGeneratorModelAccess().getModelViewManager();
        try (IModelViewExecutionContext viewContext = vm.executeWithModelView(gAbstractParam.getCreationModelView())) {
            try (IModelViewExecutionContext modeContext = vm.executeWithVariantSpecificModelChanges()) {
                runnable.run();
            }
        }
    }

    // Package private section

    /**
     * Creates a new {@link GIModelObject} object in MDF model.
     *
     * @param <BSWMD> the generic type
     * @param <MDF> the generic type
     * @param parent the parent
     * @param defRef the def ref
     * @param mdfObjectCreator the mdf object creator
     * @param bswmdObjectCreator the bswmd object creator
     * @param existingBswmd the existing bswmd
     * @return the bswmd
     */
    static <BSWMD extends GIModelObject, MDF extends MIHasDefinition> BSWMD createGIModelObject(GAbstractHasContainer parent,
            TypedDefRef<?, ? extends MIHasDefinition, ?> defRef, ICreateMdfObjectFunction<MDF> mdfObjectCreator, ICreateGIModelObjectFunction<BSWMD> bswmdObjectCreator,
            BSWMD existingBswmd) {

        try {
            final IInternalGeneratorModelAccess modelAccess = parent.getGenModelAccessInternal();
            parent.switchView();
            final MIHasDefinition createdMdfObject = mdfObjectCreator.create(parent.getMdfObject(), defRef);
            if (refreshParameterIfExisting(existingBswmd, createdMdfObject)) {
                return existingBswmd;
            } else {
                return bswmdObjectCreator.create(defRef, createdMdfObject, modelAccess, parent);
            }
        } catch (final ModelException ex) {
            throw parent.getGenModelAccessInternal().getExceptionCreator().issueExceptionFromModelException(parent, ex);
        } finally {
            parent.restoreView();
        }
    }

    /**
     * Removes the specified {@link GIModelObject} from MDF model.
     *
     * @param giObjectToRemove the object to remove
     */
    static void removeGIModelObject(GIModelObject giObjectToRemove) {

        final GAbstractModelObject abstractObjectToRemove = (GAbstractModelObject) giObjectToRemove;
        try {
            abstractObjectToRemove.switchView();
            final MIHasDefinition mdfObject = abstractObjectToRemove.getMdfObject();
            final IModelOperations mo = getModelOperations(abstractObjectToRemove);
            mo.deleteFromModel(mdfObject);
        } catch (final ModelException ex) {
            throw abstractObjectToRemove.getGenModelAccessInternal().getExceptionCreator().issueExceptionFromModelException(abstractObjectToRemove, ex);
        } finally {
            abstractObjectToRemove.restoreView();
        }
    }

    /**
     * Gets the model operations.
     *
     * @param parent the parent
     * @return the model operations
     */
    static IModelOperations getModelOperations(GAbstractModelObject gModelObject) {
        return gModelObject.getGenModelAccessInternal().getProjectContext().getService(IModelOperations.class);
    }

    // Private section

    /**
     * If the passed {@link GIModelObject} is a parameter and not null, its mdf object is refreshed.
     *
     * @param bswmdObject the bswmd object
     * @param mdfObject the mdf object
     * @return true, if the mdf object of the parameter was refresehed
     */
    private static boolean refreshParameterIfExisting(GIModelObject bswmdObject, MIHasDefinition mdfObject) {

        if (bswmdObject != null && bswmdObject instanceof GAbstractParamOrRef) {

            final GAbstractParamOrRef paramInternal = (GAbstractParamOrRef) bswmdObject;

            paramInternal.setNewMdfObjectInternal((MIParameterValue) mdfObject);

            return true;

        }

        return false;
    }

    /**
     * Deletes a already existing choice option of a {@link GIChoiceContainer}.
     *
     * @param parent the parent
     */
    private static void deleteAlreadyExistingChoiceOption(GIHasContainer parent) {
        if (parent instanceof GIChoiceContainer) {
            parent.getSubContainers().forEach(subCont -> {
                subCont.moRemove();
            });
        }
    }
}