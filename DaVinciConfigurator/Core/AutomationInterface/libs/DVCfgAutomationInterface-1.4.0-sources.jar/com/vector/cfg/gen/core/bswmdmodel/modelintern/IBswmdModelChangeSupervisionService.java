package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import java.lang.ref.WeakReference;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.gen.core.bswmdmodel.GIModelFactory;
import com.vector.cfg.util.IProjectContext;

/**
 * The {@link IBswmdModelChangeSupervisionService} provides model change support for the BswmdModel. Every created {@link GIModelFactory} shall register its
 * instance at this service.
 *
 * <p>
 * This service will then invalidate the internal BswmdModel caches of the registered {@link GIModelFactory GIModelFactries} by calling
 * {@link GAbstractModelFactory#markCacheAsInvalid()} method, when the underlying MDF model was changed.
 * </p>
 *
 * <p>
 * Caution: This interface is no intended to be used by clients!
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 *
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public interface IBswmdModelChangeSupervisionService {

    /**
     * Registers a internal {@link GAbstractModelFactory} to the {@link IProjectContext} global {@link IBswmdModelChangeSupervisionService}. The passed listener
     * is only referenced via a {@link WeakReference}, so the passed factory could be garbage collected.
     *
     * @param listener the listener
     * @exception NullPointerException <ul>
     * <li>if the listener is null</li>
     * </ul>
     */
    void addListener(GModelChangeListener listener);

    /**
     * Sets the cache state to active.
     *
     * <p>
     * This method shall be called for all clients using an internal cache, if the cache is going to be rebuild.
     * </p>
     */
    void setCacheStateToActive();

}
