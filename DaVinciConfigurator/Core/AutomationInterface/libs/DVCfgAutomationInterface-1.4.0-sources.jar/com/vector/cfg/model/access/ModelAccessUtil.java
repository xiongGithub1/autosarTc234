package com.vector.cfg.model.access;

import java.util.Collection;

import ru.novosoft.mdf.ext.MDFOutermostPackage;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.cedescriptor.aspect.IMdfObjectAspect;
import com.vector.cfg.model.exceptions.InvisibleVariantObjectException;
import com.vector.cfg.model.exceptions.ModelCeAlreadyRemovedException;
import com.vector.cfg.model.internal.MDFObjectFormatter;
import com.vector.cfg.model.internal.access.ModelInternalUtil;
import com.vector.cfg.model.internal.mdf.MObject;
import com.vector.cfg.model.internal.mdf.ModelRootPackage;
import com.vector.cfg.model.mdf.IModelObject;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.collections.ObjectsPrinter;
import com.vector.cfg.util.collections.ObjectsPrinter.IObjectLabelProvider;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.testing.IMockProvider;

/**
 * This class provides some static utility methods which shall be published for internal and external generators.
 *
 * <div class="extdoc" id="Common">
 * <h2>ModelAccessUtil</h2> The class {@link ModelAccessUtil} is a static utility class. It provides some very basic methods which are sometimes useful in client code and for
 * debugging.
 *
 * The most important are:
 * <ul>
 * <li>{@link #getProjectContext(MIObject)}: Returns the {@link IProjectContext} the specified {@link MIObject} corresponds to
 * <li>{@link #toDebugStringMDFObject(MIObject)}: Returns a string representation of the specified object and its content to support debugging
 * </ul>
 *
 * </div>
 *
 * <p>
 * <b>Important remark:</b> Do not change or add something here without discussing your requirements with the responsible PLD of the model plugin! In general, the policy for
 * providing static utility methods shall be: Use project services instead if possible. The are more flexible and can easily be mocked.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class ModelAccessUtil {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(ModelAccessUtil.class);

    /**
     * Constructor: Do not instantiate this class.
     */
    private ModelAccessUtil() {
    }

    /**
     * Gets the project context, by the passed {@link MIObject}.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible and/or removed MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * <p>
     * The {@link ModelAccessUtil#getProjectContext(MIObject)} supports the {@link IMockProvider} interface. See IMockProvider for more details.
     * </p>
     *
     * @param obj the obj
     * @return the {@link IProjectContext} to the corresponding {@link MIObject}.
     */
    @PublishedMethod
    public static IProjectContext getProjectContext(final IModelObject obj) {
        if (obj == null) {
            return null;
        }
        // This is for test to inject services, when the IModelObject was mocked, and the client code can't use ModelRootPackage, because its model internal.
        if (obj instanceof IMockProvider) {
            return getProjectContextFromMock((IMockProvider) obj);
        }

        final MDFOutermostPackage outermostPackage = getOutermostPackage(obj);
        return getProjectContext(outermostPackage);
    }

    private static IProjectContext getProjectContextFromMock(final IMockProvider obj) {
        final IProjectContext pc = obj.get(IProjectContext.class);
        if (pc instanceof IProjectContext) {
            return pc;
        } else {
            throw new IllegalArgumentException("The mocked Object " + obj + " does not support the IMockProvider for class IProjectContext!");
        }
    }

    private static MDFOutermostPackage getOutermostPackage(final IModelObject obj) {
        return obj.mdfGetOutermostPackage();
    }

    private static IProjectContext getProjectContext(final MDFOutermostPackage outermostPackage) {
        return ((ModelRootPackage) outermostPackage).getProjectContext();
    }

    /**
     * Gets the project context, by the passed {@link IDescriptor}.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param descriptor the descriptor
     * @return the {@link IProjectContext} to the corresponding {@link IDescriptor}, or <code>null</code>, if it does not exist.
     */
    @PublishedMethod
    public static IProjectContext getProjectContext(final IDescriptor descriptor) {
        return getProjectContext(getNextBestMDFObject(descriptor, true));
    }

    /**
     * @param descriptor
     * @param doNotCheckIsRemoved return a potentially removed object instead of continue the search
     * @return the first {@link MIObject} encountered on the path from the given descriptor on upwards (if any)
     */
    @KeepSecretFromPublishedApi
    public static MIObject getNextBestMDFObject(IDescriptor descriptor, boolean doNotCheckIsRemoved) {
        while (descriptor != null) {
            final IMdfObjectAspect<?> mdfObjectAspect = descriptor.getAspect(IMdfObjectAspect.class);
            if (mdfObjectAspect != null) {
                final MIObject mdfObject = mdfObjectAspect.getObject();
                if (doNotCheckIsRemoved || !mdfObject.moIsRemoved()) {// the removed check may cause an InterruptedRuntimeException
                    return mdfObject;
                }
            }
            descriptor = descriptor.getParent();
        }
        return null;
    }

    /**
     * Returns the requested service.
     *
     * <p>
     * Shortcut for <br/>
     * <code>ModelAccessUtil.{@link #getProjectContext(MIObject) getProjectContext}(obj).{@link com.vector.cfg.util.servicecontext.IServiceContext#getService(Class) getService}(service)</code>
     * </p>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @see {@link com.vector.cfg.util.servicecontext.IServiceContext#getService(Class) IServiceContext.getService()}
     *
     * @param obj the obj
     * @param service the service class
     * @return Service instance
     */
    @PublishedMethod
    public static <T> T getService(final IModelObject obj, final Class<T> service) {
        final IProjectContext projectContext = getProjectContext(obj);
        return projectContext != null ? projectContext.getService(service) : null;
    }

    /**
     * Returns <code>true</code> if the object has been removed from the model or is invisible in the current model view.
     *
     * @param object is the object to be checked
     * @return true, if the element is removed or invisible, otherwise false.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the element is null</li>
     * </ul>
     */
    @PublishedMethod
    public static boolean isRemovedOrInvisible(final MIObject object) {
        return ModelInternalUtil.isRemovedOrInvisible(object);
    }

    /**
     * Returns <code>true</code> if the object is visible in the current model view.
     *
     * @param object is the object to be checked
     * @return <code>true</code>, if the passed object is visible
     */
    @PublishedMethod
    public static boolean isVisible(final MIObject object) {
        return object.hasReadAccess();
    }

    /**
     * Returns <code>true</code> if the object has been removed from the model.
     *
     * <p>
     * Caution: This checks only, if the element is removed, <b>NOT</b> the visibility of the element!
     * </p>
     *
     * @param object
     * @return true, if the element is removed, otherwise false.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the element is null</li>
     * </ul>
     */
    @PublishedMethod
    public static boolean isRemovedOnly(final MIObject element) {
        if (element instanceof MObject) {
            if (((MObject) element).isRemoved()) {
                return true;
            }
        } else {
            if (element.moIsRemoved()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Ensures, that the passed {@link MIObject} is currently visible and not removed.
     *
     * <p>
     * Otherwise this method will throw either an {@link InvisibleVariantObjectException}, if invisible, or an {@link ModelCeAlreadyRemovedException}, if removed.
     * </p>
     *
     *
     * @param object is the object to be checked
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the element is null</li>
     * </ul>
     * @exception InvisibleVariantObjectException
     * <ul>
     * <li>if the element is invisible</li>
     * </ul>
     * @exception ModelCeAlreadyRemovedException
     * <ul>
     * <li>if the element is removed</li>
     * </ul>
     */
    @PublishedMethod
    public static void ensureIsVisible(MIObject object) {
        if (object == null) {
            throw new IllegalArgumentException("element is null");
        }
        if (!object.hasReadAccess()) {
            throw new InvisibleVariantObjectException(object);
        }
        if (object.moIsRemoved()) {
            throw new ModelCeAlreadyRemovedException(object, null);
        }
    }

    /**
     * Converts a {@link MIObject} into a String representation.
     *
     * <p>
     * Returns "&lt;null MIObject&gt;" if null
     * </p>
     * <p>
     * Returns "MIObject already removed" if (obj.moIsRemoved())
     * </p>
     *
     * <p>
     * Returns information about the MIObject depending on the type
     * </p>
     *
     * <p>
     * This is a Util method to replace MIObject.toString()
     * </p>
     *
     * @param obj the MIObject which is converted into a String
     * @return The String of the MIObject
     */
    @PublishedMethod
    public static String toStringMDFObject(final IModelObject obj) {
        return MDFObjectFormatter.toFormatStringMDFObjectInternal(obj, "", false, null);
    }

    /**
     * Converts a collection of {@link MIObject}s into a String representation.
     *
     * <p>
     * Returns "null" if null
     * </p>
     * <p>
     * Returns "MIObject already removed" if (obj.moIsRemoved())
     * </p>
     *
     * <p>
     * Returns information about the MIObject depending on the type
     * </p>
     *
     * <p>
     * This is a Util method to replace MIObject.toString()
     * </p>
     *
     * @param coll the collection which is converted into a String
     * @return The String of the MIObject
     */
    @PublishedMethod
    public static <T extends IModelObject> String toStringMDFObjectCollection(final Collection<T> coll) {
        if (coll == null) {
            return "null";
        }

        return ObjectsPrinter.toStringCollection(coll, new IObjectLabelProvider<T>() {

            @Override
            public String getLabel(final T object) {
                return toStringMDFObject(object);
            }

        });
    }

    /**
     * Converts a {@link MIObject} into a Debug-String representation.
     *
     * <p>
     * Returns "&lt;null MIObject&gt;" if null
     * </p>
     * <p>
     * Returns "MIObject already removed" if (obj.moIsRemoved())
     * </p>
     *
     * <p>
     * Returns information about the MIObject depending on the type
     * </p>
     *
     * <p>
     * This is a Util method to replace MIObject.toDebugString()
     * </p>
     *
     * @param obj the MIObject which is converted into a String
     * @return The Debug-String of the MIObject
     */
    @PublishedMethod
    public static String toDebugStringMDFObject(final IModelObject obj) {
        return MDFObjectFormatter.toFormatStringMDFObjectInternal(obj, "", true, null);
    }

    /**
     * Converts a collection of {@link MIObject}s into a Debug-String representation.
     *
     * <p>
     * Returns "null" if null
     * </p>
     * <p>
     * Returns "MIObject already removed" if (obj.moIsRemoved())
     * </p>
     *
     * <p>
     * Returns information about the MIObject depending on the type
     * </p>
     *
     * <p>
     * This is a Util method to replace MIObject.toString()
     * </p>
     *
     * @param coll the collection which is converted into a String
     * @return The String of the MIObject
     */
    @PublishedMethod
    public static <T extends IModelObject> String toDebugStringMDFObjectCollection(final Collection<T> coll) {
        if (coll == null) {
            return "null";
        }

        return ObjectsPrinter.toStringCollection(coll, new IObjectLabelProvider<T>() {

            @Override
            public String getLabel(final T object) {
                return toDebugStringMDFObject(object);
            }

        });
    }

}
