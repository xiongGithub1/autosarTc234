package com.vector.cfg.core.derivative;

import java.util.Comparator;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;

/**
 * Data structure containing name and uuid of a single derivative.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
@ReworkThisAtNextBreakingChange("Derive this class from ImplementationProperty class, keep only getName() as addition.")
public final class DerivativeInfo {
    private static final int HALF_INTEGER_BIT_SIZE = Integer.SIZE >> 1;

    private static final int LOWER_HALF_BIT_MASK = Integer.MAX_VALUE >> (HALF_INTEGER_BIT_SIZE - 1);

    @PublishedField(constantValueChangesAllowed = true)
    public static final Comparator<DerivativeInfo> SORTER = new Comparator<DerivativeInfo>() {
        @Override
        public int compare(DerivativeInfo der1, DerivativeInfo der2) {
            return der1.getName().compareTo(der2.getName());
        }
    };

    private final String derName;

    private final String derUUID;

    @PublishedMethod
    public DerivativeInfo(final String derName, final String derUUID) {
        // Safety, internal values should always contain at least an empty string
        if (derName != null) {
            this.derName = derName;
        } else {
            this.derName = "";
        }
        if (derUUID != null) {
            this.derUUID = derUUID.toUpperCase();
        } else {
            this.derUUID = "";
        }
    }

    /**
     * Get name of derivative.
     */
    @PublishedMethod
    public String getName() {
        // return getValue();
        return derName;
    }

    /**
     * Get uuid of derivative.
     */
    @PublishedMethod
    public String getUUID() {
        return derUUID;
    }

    /**
     * Get value and uuid in the notation 'value[uuid]'.
     */
    @KeepSecretFromPublishedApi
    public String toFormattedString() {
        return String.format("%s[%s]", getName(), getUUID());
    }

    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof DerivativeInfo) {

            final DerivativeInfo other = (DerivativeInfo) obj;
            // Prefer check of UUID as Name may change
            if (!derUUID.isEmpty() && !other.getUUID().isEmpty()) {
                return derUUID.equals(other.getUUID());
            } else {
                return derName.toLowerCase().equals(other.getName().toLowerCase());
            }

        } else if (obj instanceof String) {

            final String other = (String) obj;
            final boolean nameCheck = derName.toLowerCase().equals(other.toLowerCase());
            return nameCheck || (!derUUID.isEmpty() && derUUID.equals(other));

        }

        return false;
    }

    @Override
    public int hashCode() {
        int result = 0;
        if (derName != null) {
            result = derName.hashCode() << HALF_INTEGER_BIT_SIZE;
        }
        if (derUUID != null) {
            result ^= derUUID.hashCode() ^ LOWER_HALF_BIT_MASK;
        }
        return result;
    }

    @Override
    public String toString() {
        return String.format("(%s,%s)", getName(), getUUID());
    }
}
