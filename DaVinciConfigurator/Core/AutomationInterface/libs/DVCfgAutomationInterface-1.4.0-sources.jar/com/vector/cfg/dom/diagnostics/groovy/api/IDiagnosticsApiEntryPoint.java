package com.vector.cfg.dom.diagnostics.groovy.api;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IDiagnosticsApiEntryPoint} is the entry point for accessing the diagnostics domain interfaces.
 * <div class="extdoc" id="IDiagnosticsApiEntryPoint"><!--Label:IDiagnosticsApiEntryPoint-->The diagnostics domain API is specifically designed to support diagnostics related
 * use cases. It is available from the {@code IDomainApi} <!--Ref:IDomainApi--> in the form of the {@link IDiagnosticsApi} interface.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDiagnosticsApiEntryPoint {

    /**
     * {@link #getDiagnostics()} allows accessing the {@link IDiagnosticsApi} like a property.
     * <div class="extdoc" id="getDiagnostics"><!--Label:IDiagnosticsApiEntryPoint.getDiagnostics-->{@link #getDiagnostics()} allows accessing the {@link IDiagnosticsApi} like a
     * property.</div>
     *
     * @return the {@link IDiagnosticsApi}
     */
    @PublishedMethod
    IDiagnosticsApi getDiagnostics();

    /**
     * {@link #diagnostics(Closure)} allows accessing the {@link IDiagnosticsApi} in a scope-like way.
     * <div class="extdoc" id="diagnostics"><!--Label:IDiagnosticsApiEntryPoint.diagnostics-->{@link #diagnostics(Closure)} allows accessing the {@link IDiagnosticsApi} in a
     * scope-like way.</div>
     *
     * @param code the code (a {@link Closure}) working with the {@link IDiagnosticsApi}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T diagnostics(@Nonnull @VDelegatesToWithClosureParam(IDiagnosticsApi.class) Closure<T> code);

}
