package com.vector.cfg.gen.core.genusage.groovy.api;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.gencore.executionmodel.IGenerationStepSequence;
import com.vector.cfg.gen.core.gencore.executionmodel.IGenerationStepUsage;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IExtGenStepSettingsApi extends IGenerationStepSequence {

    /**
     * This method selects an {@link IGenerationStepUsage} to be executed. <br/>
     * The name of the generation step is used as ID <br/>
     * Already selected generators are not removed by this method. <br/>
     *
     * @param generator id of the external generation step
     */
    @PublishedMethod
    void selectStep(String genStep);

    /**
     * This method deselects an {@link IGenerationStepUsage}. <br/>
     * The name of the generation step is used as ID <br/>
     *
     * @param generator id of the external generation step
     */
    @PublishedMethod
    void deselectStep(String genStep);

    /**
     * This method selects an {@link IGenerationStepUsage} to be executed. <br/>
     * The name of the generation step is used as ID <br/>
     * Already selected generators are not removed by this method. <br/>
     *
     * @param generator ids of the external generation step
     */
    @PublishedMethod
    void selectStep(List<String> genSteps);

    /**
     * This method selects all available {@link IGenerationStepUsage} to be executed. <br/>
     *
     */
    @PublishedMethod
    void selectAll();

    /**
     * This method deselects an {@link IGenerationStepUsage}. <br/>
     * The name of the generation step is used as ID <br/>
     *
     * @param generator id of the external generation step
     */
    @PublishedMethod
    void deselectStep(List<String> genSteps);

    /**
     * This method returns an {@link IGenerationStepUsage} associated with the passed ID. <br/>
     * The name of the generation step is used as ID <br/>
     *
     * @param generator id of the external generation step
     */
    @PublishedMethod
    IGenerationStepUsage stepByName(String id);

    /**
     * Returns the IExtGenStepSequence object which contains the external generation steps in an dedicated order.
     *
     * @return
     */
    @PublishedMethod
    IGenerationStepSequence getStepSequence();

    /**
     * Overtakes the external generation steps activation settings from the project settings.
     */
    @PublishedMethod
    void loadProjectSettings();

    /**
     * Clears the GenerationStep selection.
     */
    @PublishedMethod
    void deselectAll();

}
