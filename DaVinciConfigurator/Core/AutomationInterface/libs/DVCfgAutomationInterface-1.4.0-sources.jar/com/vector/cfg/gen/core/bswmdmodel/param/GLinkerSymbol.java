package com.vector.cfg.gen.core.bswmdmodel.param;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MILinkerSymbolDef;

/**
 * LinkerSymbol parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GLinkerSymbol extends GString {

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public GLinkerSymbol(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MITextualValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @ReworkThisAtNextBreakingChange("Remove method - implemented in base type")
    public boolean hasValue() {
        return super.hasValue();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getValue() {
        try {
            switchView();

            final String value = super.getValue();
            getModelVerifier().assertParameterHasLegalValue(this, "LinkerSymbol");
            return value;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MILinkerSymbolDef getDefinition() {
        return (MILinkerSymbolDef) super.getDefinition();
    }

}
