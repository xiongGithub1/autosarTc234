package com.vector.cfg.consistency.ui;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IValidationResultId;

/**
 * Represents the group of semantically equal solving-actions in different validation-results of the same ID.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
public interface ISolvingActionGroupUI {

    /**
     * Gets the solving actions which are assigned to this group.
     *
     * @return the solving actions
     */
    @PublishedMethod
    Collection<ISolvingActionUI> getSolvingActions();

    /**
     * Gets the solving actions which are assigned to this group and belong to a result with the given ID.
     *
     * @param resultOrigin the result origin
     * @param id the result id
     * @return the solving actions
     */
    @PublishedMethod
    Collection<ISolvingActionUI> getSolvingActionsByResultId(String resultOrigin, int id);

    /**
     * @return a text that describes what these solving actions of the same kind do
     */
    @PublishedMethod
    String getSolvingActionDescription();

    /**
     * Return a positive integer that identifies this solving action group among other solving actions of the same {@link IValidationResultId}. Changing this Id will break
     * compatibility to automation clients. Some solving action groups don't have an id. Therefore {@link #hasIntegerId()} has to be checked before.
     *
     * @return
     */
    @PublishedMethod
    int getId();

    /**
     * Checks if this solving action group has an integer id.
     *
     * @return true, if it has an id
     */
    @PublishedMethod
    boolean hasIntegerId();

}
