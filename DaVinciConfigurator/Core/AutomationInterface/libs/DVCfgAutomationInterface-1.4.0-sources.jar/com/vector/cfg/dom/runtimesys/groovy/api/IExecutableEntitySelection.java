package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.taskmapping.IExecutableEntity;
import com.vector.cfg.model.sysdesc.api.taskmapping.ITaskMapping;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IExecutableEntitySelection"><!--Label:IExecutableEntitySelection-->{@link IExecutableEntitySelection} represents a selection of
 * {@link IExecutableEntity}s and the possible operations on these.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IExecutableEntitySelection {

    /**
     * <div class="extdoc" id="mapToTask"><!--Label:IExecutableEntitySelection.mapToTask-->{@link #mapToTask(Closure)} tries to perform a task mapping for the selection of
     * executable entities (functions). Inside the closure the task mapping can be controlled, e.g. selecting the task to which the events (triggers) of the selected executable
     * entities should be mapped to and order the event's positions.</div>
     *
     * <p>
     * The executable entity selection will produce trace, info and warning logs. To see them, activate the
     * '{@link com.vector.cfg.dom.runtimesys.groovy.api.IExecutableEntitySelection}' logger with the appropriate log level.
     * </p>
     *
     * @param code The code to provide select a task and order the task mappings.
     * @return A list of created task mappings.
     * @throws Throws a {@link SelectionException} if more than one or none task is selected inside the closure.
     */
    @PublishedMethod
    List<? extends ITaskMapping> mapToTask(@Nonnull @VDelegatesToWithClosureParam(ITaskMapper.class) Closure<?> code);

    /**
     * Allows access to the single executable entities in the {@link IExecutableEntitySelection}.
     *
     * @return The collection of selected {@link IExecutableEntity}s.
     */
    @PublishedMethod
    Collection<? extends IExecutableEntity> getExecutableEntities();

}
