package com.vector.cfg.gen.core.gencore.generationsteps;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IValidationResultSource;
import com.vector.cfg.core.project.EEnvironmentTargetType;
import com.vector.cfg.gen.core.moduleinterface.EGenerationPhaseType;

/**
 * {@link IGenerationStep} represents one configured generation step in the project.
 *
 * <p>
 * The {@link IGenerationStep} must implement {@link #equals(Object)} and {@link #hashCode()}, or must ensure, that object identity is given.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IGenerationStep extends IValidationResultSource {

    /**
     * Returns the name of the external generation step. <br/>
     * The name is also treated as the ID.
     *
     * @return the name
     */
    @PublishedMethod
    String getName();

    /**
     * Returns a list of phases when the generation step is executed.
     *
     * @return the phases to execute
     */
    @PublishedMethod
    List<EGenerationPhaseType> getPhasesToExecute();

    /**
     * Gets the execution type of the generation step.
     *
     * @return the execution type
     */
    @PublishedMethod
    EGenStepExecutionType getExecutionType();

    /**
     * Gets the target type of the generation step.
     *
     * <p>
     * Note: The returned {@link EEnvironmentTargetType} can also be {@link EEnvironmentTargetType#NONE NONE}.
     * </p>
     *
     * @return the target type
     */
    @PublishedMethod
    EEnvironmentTargetType getTargetType();
}
