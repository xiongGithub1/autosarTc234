package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIEnumParameter;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasIllegalValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasNoValueException;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucEnumDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucEnumParameter;
import com.vector.cfg.model.enums.ModelEnumUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEnumerationParamDef;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Enumeration parameter base class for "definition typed" and "untyped" bswmd models.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class GAbstractEnumeration<T> extends GAbstractParam<String> implements GIEnumParameter {

    private static final ILogger logger = Logger.INSTANCE.createLogger(GAbstractEnumeration.class);

    /**
     * Constructor.
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GAbstractEnumeration(DefRef defRef, MITextualValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, boolean onlyOneElement) {
        super(defRef, parameter, modelAccess, parent, onlyOneElement);

    }

    /**
     * Constructor.
     */
    @PublishedMethod
    public GAbstractEnumeration(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MITextualValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MITextualValue getMdfObject() {
        return (MITextualValue) super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MITextualValue getMdfObjectUnsafe() {
        return (MITextualValue) super.getMdfObjectUnsafe();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @ReworkThisAtNextBreakingChange("Remove method - implemented in base type")
    public boolean hasValue() {
        return super.hasValue();
    }

    @PublishedMethod
    protected String getValueInternal() {
        try {
            switchView();

            final MITextualValue mdfObject = getMdfObject();
            if (mdfObject != null) {
                return mdfObject.getValue();
            }
            return null;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    public T getValueOrDefault(T defaultValue) {
        if (hasValue()) {
            return getValue();
        }

        return defaultValue;
    }

    /**
     * Returns the parameters value as Enumeration literal (Java enum instance).
     *
     * @return The value object
     *
     * @exception BswmdModelParameterHasNoValueException
     * <ul>
     * <li>if the value of the parameter is null</li>
     * </ul>
     * @exception BswmdModelParameterHasIllegalValueException
     * <ul>
     * <li>if the value of the parameter is illegal</li>
     * </ul>
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    public abstract T getValue();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <CUSTOM_ENUM extends Enum<CUSTOM_ENUM>>CUSTOM_ENUM getAsCustomEnum(Class<CUSTOM_ENUM> destClass) {
        try {
            switchView();

            checkNotNull(destClass);
            CUSTOM_ENUM retValue;

            final String modelValue = getValueMdf();

            try {

                retValue = ModelEnumUtil.getEnumLiteralFromAutosarValue(modelValue, destClass);
                // The result of getEnumLiteralFromAutosarValue() could be null => So do errorhandling outside of the catch block
            } catch (final Exception e) {
                // No valid Return value exists, because of Exception
                if (logger.isTraceEnabled()) {
                    logger.trace(e);
                }
                retValue = null;
            }

            if (retValue == null) {
                final List<String> validValues = ModelEnumUtil.getValidValues(destClass);

                getModelVerifier().assertEnumerationHasLegalLiteral(this, validValues, modelValue);

            }

            return retValue;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(String valueOf) {

        BswmdModelInternalElementFactory.setValueMdf(this, () -> getGeneratorModelAccess().getMdfModelAccess().setAsString(getMdfObject(), valueOf));
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(GIEnumClass enumVal) {

        BswmdModelInternalElementFactory.setValueMdf(this, () -> {
            String value = null;
            if (enumVal != null) {
                value = enumVal.name();
            }
            getGeneratorModelAccess().getMdfModelAccess().setAsString(getMdfObject(), value);
        });

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValue(GIEnumClass newValue) {
        this.setValueMdf(newValue);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIEnumerationParamDef getDefinition() {
        return (MIEnumerationParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucEnumDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucEnumParameter getEcuConfiguration() {

        final IEcucParameter cfg = super.getEcuConfiguration();
        return (IEcucEnumParameter) cfg;
    }

}
