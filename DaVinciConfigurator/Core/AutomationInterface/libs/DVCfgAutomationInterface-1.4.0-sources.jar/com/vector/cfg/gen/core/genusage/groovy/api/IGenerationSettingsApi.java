package com.vector.cfg.gen.core.genusage.groovy.api;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.gencore.executionmodel.IGeneratorUsage;
import com.vector.cfg.gen.core.genusage.groovy.exceptions.GeneratorNotFoundException;
import com.vector.cfg.gen.core.moduleinterface.EGenerationProcessType;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="Settings"> The class {@link IGenerationSettingsApi} encapsulates all settings which belong to a generation process. <br/>
 * E.g.
 * <ul>
 * <li>Select the generators to execute</li>
 * <li>Select the target type (Real, VTT)</li>
 * <li>Select the external generation steps</li>
 * <li>If the module supports multiple module configurations, select the configurations which shall be generated</li>
 * </ul>
 * </div>
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface IGenerationSettingsApi {

    /**
     * Opens an empty settings block. This block contains settings related to external generation steps.
     *
     * @param code Content of the block
     * @return
     */
    @PublishedMethod
    IExtGenStepSettingsApi externalGenerationSteps(
            @VDelegatesToWithClosureParam(IExtGenStepSettingsApi.class) Closure<?> code);

    /**
     * Opens an empty settings block. This block contains settings related to external generation steps.
     *
     * @param code Content of the block
     * @return
     */
    @PublishedMethod
    IExtGenStepSettingsApi externalGenerationStepsFromProject(
            @VDelegatesToWithClosureParam(IExtGenStepSettingsApi.class) Closure<?> code);

    /**
     * This method fetches the generators associated with the passed DefRef and adds them to the list of generators which shall be executed. <br/>
     * It is possible to pass full qualified DefRefs (E.g. "/MICROSAR/Adc") or only the module definition short name of the DefRef (E.g. "Os").<br/>
     * Passed MSN are interpreted to match any package ("/[ANY]/MSN"). <br/>
     * Already selected generators are not removed by this method. <br/>
     *
     * If a DefRef could not be resolved to a generator, a {@link GeneratorNotFoundException} will be thrown.
     *
     * @param generators String vararg of defRefs or module definition short name
     * @throws GeneratorNotFoundException
     */
    @PublishedMethod
    void selectGeneratorsByDefRef(String... defRef);

    /**
     * This method fetches the generators associated with the passed DefRef and adds them to the list of generators which shall be executed. <br/>
     * It is possible to pass a full qualified DefRef (E.g. "/MICROSAR/Adc") or only the module definition short name of the DefRef (E.g. "Os").<br/>
     * Passed MSN are interpreted to match any package ("/[ANY]/MSN"). <br/>
     * Already selected generators are not removed by this method. <br/>
     *
     * If a DefRef could not be resolved to a generator, a {@link GeneratorNotFoundException} will be thrown.
     *
     * @param generators String of defRef or module definition short name
     * @throws GeneratorNotFoundException
     */
    @PublishedMethod
    void selectGeneratorByDefRef(String defRef);

    /**
     * This method fetches the generators associated with the passed DefRef and adds them to the list of generators which shall be executed. <br/>
     * It is possible to pass full qualified DefRefs (E.g. "/MICROSAR/Adc") or only the module definition short name of the DefRef (E.g. "Os").<br/>
     * Passed MSN are interpreted to match any package ("/[ANY]/MSN"). <br/>
     * Already selected generators are not removed by this method. <br/>
     *
     * If a DefRef could not be resolved to a generator, a {@link GeneratorNotFoundException} will be thrown.
     *
     * @param generators DefRef vararg of defRefs or module definition short names
     * @throws GeneratorNotFoundException
     */
    @PublishedMethod
    void selectGeneratorsByDefRef(DefRef... defRef);

    /**
     * This method fetches the generators associated with the passed DefRef and adds them to the list of generators which shall be executed. <br/>
     * It is possible to pass a full qualified DefRef (E.g. "/MICROSAR/Adc") or only the module definition short name of the DefRef (E.g. "Os").<br/>
     * Passed MSN are interpreted to match any package ("/[ANY]/MSN"). <br/>
     * Already selected generators are not removed by this method. <br/>
     *
     * If a DefRef could not be resolved to a generator, a {@link GeneratorNotFoundException} will be thrown.
     *
     * @param generators String of defRef or module definition short name
     * @throws GeneratorNotFoundException
     */
    @PublishedMethod
    void selectGeneratorByDefRef(DefRef defRef);

    /**
     * This method selects an {@link IGeneratorUsage} to be executed. <br/>
     * Already selected generators are not removed by this method. <br/>
     *
     * @param generator IGeneratorUsage to select
     */
    @PublishedMethod
    void selectGenerator(IGeneratorUsage generator);

    /**
     * This method selects a List of {{@link IGeneratorUsage} to be executed. <br/>
     * Already selected generators are not removed by this method. <br/>
     *
     * @param generator List of IGeneratorUsage to select
     */
    @PublishedMethod
    void selectGenerators(IGeneratorUsage... generators);

    /**
     * This method selects a List of {{@link IGeneratorUsage} to be executed. <br/>
     * Already selected generators are not removed by this method. <br/>
     *
     * @param generator List of IGeneratorUsage to select
     */
    @PublishedMethod
    void selectGenerators(List<IGeneratorUsage> generators);

    /**
     * This method selects all available {{@link IGeneratorUsage} to be executed. <br/>
     *
     */
    @PublishedMethod
    void selectAll();

    /**
     * This method deselects all available {{@link IGeneratorUsage} to be executed. <br/>
     */
    @PublishedMethod
    void deselectAll();

    /**
     * This method deselects generators selected by a List of {{@link DefRef}. <br/>
     *
     * @param generator List of IGeneratorUsage to deselect
     */
    @PublishedMethod
    void deselectGenerators(DefRef... defRef);

    /**
     * This method deselects generators selected by a List of {{@link String}. <br/>
     *
     * @param generator List of IGeneratorUsage to deselect
     */
    @PublishedMethod
    void deselectGenerators(String... defRef);

    /**
     * This method deselects one generator selected by {{@link String}. <br/>
     *
     * @param generator List of IGeneratorUsage to deselect
     */
    @PublishedMethod
    void deselectGenerators(List<String> defRef);

    /**
     * This method deselects the passed generator. <br/>
     *
     * @param generator List of IGeneratorUsage to deselect
     */
    @PublishedMethod
    void deselectGenerator(IGeneratorUsage generator);

    /**
     * Returns all valid generators from the SIP. <br/>
     * If a generator requires an absent module configuration, it will not be returned by this method.
     *
     * @return list of IGeneratorUsage.
     */
    @PublishedMethod
    List<IGeneratorUsage> getAllGenerators();

    /**
     * Returns a generator associated with the passed DefRef.
     *
     *
     * @param defRefString The DefRef to select the generator
     * @return IGeneratorUsage The associated IGeneratorUsage
     * @throws GeneratorNotFoundException If no generator is associated with the passed DefRef.
     */
    @PublishedMethod
    IGeneratorUsage generatorByDefRef(String defRefString);

    /**
     * Returns a list of valid generators associated with the passed DefRefs.
     *
     * @param defRefString List of DefRefs to select the generators
     * @return IGeneratorUsage A list of valid IGeneratorUsage
     * @throws GeneratorNotFoundException If no associated generator could be found for a passed DefRef.
     */
    @PublishedMethod
    List<IGeneratorUsage> generatorsByDefRef(String... defRefs);

    /**
     * Returns the selected generators.
     *
     * @return selected generators
     */
    @PublishedMethod
    List<IGeneratorUsage> getSelectedGenerators();

    /**
     * Sets the ignore error flag.
     *
     * @param the flag to set
     */
    @PublishedMethod
    void setIgnoreErrors(boolean i);

    /**
     * Gets the ignoreErrors flag of this generator setting.
     *
     * @return the ignoreErrors flag
     */
    @PublishedMethod
    boolean getIgnoreErrors();

    /**
     * Sets the generation target to Real.
     */
    @PublishedMethod
    void selectGenerationTargetReal();

    /**
     * Sets the generation target to VTT.
     */
    @PublishedMethod
    void selectGenerationTargetVtt();

    /**
     * Overtakes the selected Generators and GenerationSteps from the project file.
     */
    @PublishedMethod
    void loadProjectSettings();

    /**
     * Returns the settings for external generation steps.
     *
     * @return settings block
     */
    @PublishedMethod
    IExtGenStepSettingsApi getExternalGenerationStepSettings();

    /**
     * Returns the selected target type. VTT or Real Target.
     *
     * @return target type
     */
    @PublishedMethod
    EGenerationProcessType getGenerationTarget();

}
