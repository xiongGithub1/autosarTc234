package com.vector.cfg.gen.core.moduleinterface.generatorpackageaspects;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IDeployablePackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;

/**
 * <div class="extdoc" id="Common">
 * <h2>Deployable Packages and GeneratorPackageAspects</h2> If you need {@link IGeneratorPackageAspect}s in your {@link IDeployablePackage}, then the {@link IDeployablePackage}
 * can implement the {@link IDeployablePackageHasPackageAspects} to mark it, that it can have {@link IGeneratorPackageAspect}s.
 *
 * <p>
 * This is useful for example, if a deployable packages wants to contribute Post-build selectable validations.
 * </p>
 *
 * <p>
 * Note: Every {@link IGeneratorPackage} is also an {@link IDeployablePackageHasPackageAspects}, so this interface is not needed for normal generators.
 * </p>
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IDeployablePackageHasPackageAspects {

    /**
     * Retrieve a registered {@link IGeneratorPackageAspect} by its class object.
     *
     * <p>
     * Attention: This method can only be called, when the {@link IDeployablePackage} is already initialized.
     * </p>
     *
     * @param <T> the generic type of the service
     * @param clazz the class object of the requested aspect.
     * @return the associated aspect or None, if the aspect does not exist.
     */
    @PublishedMethod
    <T extends IGeneratorPackageAspect> Optional<T> getPackageAspect(Class<T> clazz);
}
