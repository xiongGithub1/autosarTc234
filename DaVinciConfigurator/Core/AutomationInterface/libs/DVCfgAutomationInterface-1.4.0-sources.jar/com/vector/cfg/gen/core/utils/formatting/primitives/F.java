package com.vector.cfg.gen.core.utils.formatting.primitives;

import static com.google.common.base.Preconditions.checkArgument;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIEnumParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIFloatParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIIntParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.gen.core.bswmdmodel.param.GBoolean;
import com.vector.cfg.gen.core.bswmdmodel.param.GEnumeration;
import com.vector.cfg.gen.core.bswmdmodel.param.GFloat;
import com.vector.cfg.gen.core.bswmdmodel.param.GInteger;
import com.vector.cfg.gen.core.bswmdmodel.param.GString;
import com.vector.cfg.gen.core.utils.formatting.IGenElement;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Static helper class for generator format objects
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IGenElement
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class F {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(F.class);

    private F() {

    }

    /**
     * Creates a new format object for a Boolean element.
     *
     * @param boolObj The Boolean
     * @return A new boolean format object.
     */
    @PublishedMethod
    public static BoolGenElement formatBool(Boolean boolObj) {
        return new BoolGenElement(boolObj);
    }

    /**
     * Creates a new format object for a Boolean element.
     *
     * @param boolObj The Boolean
     * @return A new boolean format object.
     */
    @PublishedMethod
    public static BoolGenElement formatBool(boolean boolObj) {
        return new BoolGenElement(boolObj);
    }

    /**
     * Creates a new format object for a Boolean element.
     *
     * @param gBoolean The Boolean
     * @return A new Boolean format object.
     */
    @PublishedMethod
    public static BoolGenElement formatBool(GBoolean gBoolean) {
        return new BoolGenElement(gBoolean);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param intObj The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatInt(int intObj) {
        return new IntGenElement(intObj);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param intObj The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatInt(Integer intObj) {
        return new IntGenElement(intObj);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param longObj The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatInt(Long longObj) {
        return new IntGenElement(longObj);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param longObj The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatInt(long longObj) {
        return new IntGenElement(longObj);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param bigIntObj The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatInt(BigInteger bigIntObj) {
        return new IntGenElement(bigIntObj);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param gInteger The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatInt(GInteger gInteger) {
        return new IntGenElement(gInteger);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param gInteger The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatInt(GIParameter<?> gInteger) {
        checkArgument(gInteger instanceof GIIntParameter, "The passed Parameter must be a GIIntParameter!");
        return new IntGenElement((GIIntParameter) gInteger);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param longObj The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatLong(Long longObj) {
        return new IntGenElement(longObj);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param longObj The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatLong(long longObj) {
        return new IntGenElement(longObj);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param gInteger The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatLong(GInteger gInteger) {
        return new IntGenElement(gInteger);
    }

    /**
     * Creates a new format object for a Integer element.
     *
     * @param gInteger The Integer
     * @return A new Integer format object.
     */
    @PublishedMethod
    public static IntGenElement formatLong(GIParameter<?> gInteger) {
        checkArgument(gInteger instanceof GIIntParameter, "The passed Parameter must be a GIIntParameter!");
        return new IntGenElement((GIIntParameter) gInteger);
    }

    /**
     * Creates a new format object for a String element.
     *
     * @param stringObj The String
     * @return A new String format object.
     */
    @PublishedMethod
    public static StringGenElement formatString(String stringObj) {
        return new StringGenElement(stringObj);
    }

    /**
     * Creates a new format object for a String element.
     *
     * @param gString The String
     * @return A new String format object.
     */
    @PublishedMethod
    public static StringGenElement formatString(GString gString) {
        return new StringGenElement(gString);
    }

    /**
     * Creates a new format object for a Enum BswmdModel element.
     *
     * @param gEnum A GEnumeration object
     * @return A new Enum format object.
     */
    @PublishedMethod
    public static <E extends Enum<E>> EnumGenElement formatEnum(GEnumeration<E> gEnum) {
        return new EnumGenElement(gEnum);
    }

    /**
     * Creates a new format object for a Enum BswmdModel element.
     *
     * @param gEnum A GEnumeration object
     * @return A new Enum format object.
     */
    @PublishedMethod
    public static <E extends Enum<E>> EnumGenElement formatEnum(GIParameter<String> gEnum) {
        checkArgument(gEnum instanceof GIEnumParameter, "The passed Parameter must be a GIEnumParameter!");
        return new EnumGenElement((GIEnumParameter) gEnum);
    }

    /**
     * Creates a new format object for a Java Enum element.
     *
     * @param enumObj A Java Enum object
     * @return A new Enum format object.
     */
    @PublishedMethod
    public static <E extends Enum<E>> EnumGenElement formatEnum(Enum<E> enumObj) {
        return new EnumGenElement(enumObj);
    }

    /**
     * Creates a new format object for a Float element.
     *
     * @param doubleObj The double value
     * @return A new float format object.
     * @throws NumberFormatException if {@code doubleObj} is infinite or NaN.
     */
    @PublishedMethod
    public static FloatGenElement formatFloat(Double doubleObj) {
        return new FloatGenElement(doubleObj);
    }

    /**
     * Creates a new format object for a Float element.
     *
     * @param doubleObj The double value
     * @return A new float format object.
     * @throws NumberFormatException if {@code doubleValue} is infinite or NaN.
     */
    @PublishedMethod
    public static FloatGenElement formatFloat(double doubleValue) {
        return new FloatGenElement(doubleValue);
    }

    /**
     * Creates a new format object for a BigDecimal value.
     *
     * @param bigDecimal The double value
     * @return A new float format object.
     */
    @PublishedMethod
    public static FloatGenElement formatFloat(BigDecimal bigDecimal) {
        return new FloatGenElement(bigDecimal);
    }

    /**
     * Creates a new format object for a Float element.
     *
     * @param gFloat The float bswmd object
     * @return A new float format object.
     * @throws NumberFormatException if {@code gFloat} value is infinite or NaN.
     *
     */
    @PublishedMethod
    public static FloatGenElement formatFloat(GFloat gFloat) {
        return new FloatGenElement(gFloat);
    }

    /**
     * Creates a new format object for a Float element.
     *
     * @param gFloat The float bswmd object
     * @return A new float format object.
     * @throws NumberFormatException if {@code gFloat} value is infinite or NaN.
     *
     */
    @PublishedMethod
    public static FloatGenElement formatFloat(GIParameter<?> gFloat) {
        checkArgument(gFloat instanceof GIFloatParameter, "The passed Parameter must be a GIFloatParameter!");
        return new FloatGenElement((GIFloatParameter) gFloat);
    }

}
