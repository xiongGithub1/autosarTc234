package com.vector.cfg.gen.core.utils.generatorresult;

import java.util.Collection;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.helper.validationresults.IValidationResultBuilder;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.view.config.IModelView;

/**
 * The {@link IGeneratorResultBuilder} interface provides the build API for different {@link GeneratorResultBuilder}s, which are the common method to build an
 * {@link IGeneratorResult}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 *
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGeneratorResultBuilder<T extends IGeneratorResultBuilder<T>> extends IValidationResultBuilder<T> {

    /**
     * Builds a new instance of {@link IGeneratorResult} with the given content of the builder and returns it.
     *
     * <p>
     * Note: The created {@link IValidationResult} will have an implicit ModelView context. The {@link IModelView} which is active during this creation call of
     * the {@link IValidationResult} is used! <br />
     * If you want to override this behavior, please call the addXXXContext (e.g.
     * {@link #addPredefinedVariantContext(com.vector.cfg.model.view.config.variant.IPredefinedVariantView)}) methods.
     * </p>
     *
     * @return A new {@link IGeneratorResult}
     *
     * @see IGeneratorResultSink
     * @see IGeneratorResult
     * @exception IllegalArgumentException <ul>
     * <li>if no description text is in the result</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    IGeneratorResult buildResult();

    /**
     * Adds the specified GeneratorModelObject to the internal set of erroneous ConfigurationElements (CEs). It is ensured that the internal set never contain
     * duplicate ConfigurationElements.
     *
     * <p>
     * Note: Every erroneous entry is also added to the dependent list.
     * </p>
     *
     *
     * <p>
     * Note: The creation ModelView (see BswmdModel) of the passed element, is also added as implicit view context of this result. If you want to override this
     * behavior, please call the addXXXContext (e.g. {@link #addPredefinedVariantContext(com.vector.cfg.model.view.config.variant.IPredefinedVariantView)})
     * methods. The implicit set {@link IModelView} during creation is then omitted (see {@link #buildResult()}).
     * </p>
     *
     * @param erroneousBswmdObject One Bswmd generator model object
     * @return This builder
     *
     * @exception IllegalArgumentException <ul>
     * <li>if erroneousBswmdObject is null</li>
     * </ul>
     */
    @PublishedMethod
    T addErrorObject(GIModelObject erroneousBswmdObject);

    /**
     * Adds all objects in the collection to the internal set of erroneous ConfigurationElements (CEs). It is ensured that the internal set never contain
     * duplicate ConfigurationElements.
     *
     * <p>
     * Note: Every erroneous entry is also added to the dependent list.
     * </p>
     *
     * <p>
     * Note: The creation ModelView (see BswmdModel) of the passed elements, is also added as implicit view context of this result. If you want to override this
     * behavior, please call the addXXXContext (e.g. {@link #addPredefinedVariantContext(com.vector.cfg.model.view.config.variant.IPredefinedVariantView)})
     * methods. The implicit set {@link IModelView} during creation is then omitted (see {@link #buildResult()}).
     * </p>
     *
     *
     * @param erroneousBswmdCollection A collection of Bswmd generator model objects
     * @return This builder
     *
     * @exception IllegalArgumentException <ul>
     * <li>if erroneousBswmdCollection is null</li>
     * </ul>
     */
    @PublishedMethod
    <R extends GIModelObject> T addErrorBswmdObjectList(Collection<R> erroneousBswmdCollection);

    /**
     * Adds the specified GeneratorModelObject to the internal set of dependent ConfigurationElements (CEs). It is ensured that the internal set never contain
     * duplicate ConfigurationElements.
     *
     * <p>
     * Note: The creation ModelView (see BswmdModel) of the passed element, is also added as implicit view context of this result. If you want to override this
     * behavior, please call the addXXXContext (e.g. {@link #addPredefinedVariantContext(com.vector.cfg.model.view.config.variant.IPredefinedVariantView)})
     * methods. The implicit set {@link IModelView} during creation is then omitted (see {@link #buildResult()}).
     * </p>
     *
     * @param genModelObject One Bswmd generator model object
     * @return This builder
     *
     * @exception IllegalArgumentException <ul>
     * <li>if genModelObject is null</li>
     * </ul>
     */
    @PublishedMethod
    T addDependentObject(GIModelObject genModelObject);

    /**
     * Adds all objects in the collection to the internal set of dependent ConfigurationElements (CEs). It is ensured that the internal set never contain
     * duplicate ConfigurationElements.
     *
     * <p>
     * Note: The creation ModelView (see BswmdModel) of the passed elements, is also added as implicit view context of this result. If you want to override this
     * behavior, please call the addXXXContext (e.g. {@link #addPredefinedVariantContext(com.vector.cfg.model.view.config.variant.IPredefinedVariantView)})
     * methods. The implicit set {@link IModelView} during creation is then omitted (see {@link #buildResult()}).
     * </p>
     *
     * @param bswmdObjectCollection A collection of Bswmd generator model objects
     * @return This builder
     *
     * @exception IllegalArgumentException <ul>
     * <li>if bswmdObjectCollection is null</li>
     * </ul>
     */
    @PublishedMethod
    <R extends GIModelObject> T addDependentBswmdObjectList(Collection<R> bswmdObjectCollection);

    /**
     * Adds a {@link IDescriptor} which marks the Definition of defRef as erroneous.
     *
     * <p>
     * You can use this method to mark a certain object as missing or needed.
     * </p>
     *
     * <p>
     * Note: Every erroneous entry is also added to the dependent list.
     * </p>
     *
     *
     * <p>
     * Note: The creation ModelView (see BswmdModel) of the passed element, is also added as implicit view context of this result. If you want to override this
     * behavior, please call the addXXXContext (e.g. {@link #addPredefinedVariantContext(com.vector.cfg.model.view.config.variant.IPredefinedVariantView)})
     * methods. The implicit set {@link IModelView} during creation is then omitted (see {@link #buildResult()}).
     * </p>
     *
     * @param parentBswmdObject A parent element
     * @param missingCeDefRef The {@link DefRef} object of the missing element.
     * @return This builder
     *
     * @exception IllegalArgumentException <ul>
     * <li>if parentBswmdObject is null</li>
     * <li>if missingCeDefRef is null</li>
     * </ul>
     */
    @PublishedMethod
    T addErrorMissingObject(GIModelObject parentBswmdObject, DefRef missingCeDefRef);

    /**
     * Adds a {@link IDescriptor} which marks the Definition of defRef as dependent.
     *
     * <p>
     * You can use this method to mark a certain object as missing or needed.
     * </p>
     *
     * <p>
     * Note: The creation ModelView (see BswmdModel) of the passed element, is also added as implicit view context of this result. If you want to override this
     * behavior, please call the addXXXContext (e.g. {@link #addPredefinedVariantContext(com.vector.cfg.model.view.config.variant.IPredefinedVariantView)})
     * methods. The implicit set {@link IModelView} during creation is then omitted (see {@link #buildResult()}).
     * </p>
     *
     * @param parentBswmdObject A parent element
     * @param missingCeDefRef The {@link DefRef} object of the missing element.
     * @return This builder
     *
     * @exception IllegalArgumentException <ul>
     * <li>if parentBswmdObject is null</li>
     * <li>if missingCeDefRef is null</li>
     * </ul>
     */
    @PublishedMethod
    T addDependentMissingObject(GIModelObject parentBswmdObject, DefRef missingCeDefRef);
}
