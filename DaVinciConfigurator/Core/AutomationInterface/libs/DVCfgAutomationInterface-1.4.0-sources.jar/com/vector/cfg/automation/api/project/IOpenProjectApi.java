package com.vector.cfg.automation.api.project;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 * {@link IOpenProjectApi} provides means for parameterizing the process of opening a project.
 *
 * <div class="extdoc" id="IOpenProjectApi"><!--Label:IOpenProjectApi-->{@link IOpenProjectApi} contains the methods for parameterizing the process of opening a project.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IOpenProjectApi {

}
