package com.vector.cfg.automation.scripting.api.project;

import java.nio.file.Path;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.IScriptTask;
import com.vector.cfg.util.path.IHasURI;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IProjectRef} is a handle on a project not yet loaded but ready to be opened.
 *
 * <div class="extdoc" id="IProjectRef"><!--Label:IProjectRef-->{@link IProjectRef} is a handle on a project not yet loaded but ready to be opened. This could be used to open
 * the project.
 * <p>
 * {@link IProjectRef} instances can be obtained from form the following methods:
 * <ul>
 * <li>{@code IProjectHandlingApi.createProject(Closure)} <!--Ref:IProjectHandlingApi.createProject--></li>
 * <li>{@code IProjectHandlingApi.parameterizeProjectLoad(Closure)} <!--Ref:IProjectHandlingApi.parameterizeProjectLoad--></li>
 * </ul>
 * </p>
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IProject
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IProjectRef extends IHasURI {

    /**
     * Returns the {@link Path} to the Dpa file of the referenced Project as absolute path.
     *
     * @return the project path to the Dpa file
     */
    @PublishedMethod
    Path getDpaProjectFilePath();

    /**
     * Opens this {@link IProjectRef}'s {@link IProject}. <div class="extdoc" id="openProject"><!--Label:IProjectRef.openProject-->The {@link IProject} is not really opened
     * until {@link IProjectRef#openProject(Closure)} is called. Here, the project is opened and the given {@link Closure} is executed on the opened project. When
     * {@link IProjectRef#openProject(Closure)} returns the project has already been closed.</div>
     *
     * @param code the code (a {@link Closure}) working with opened {@link IProject}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T openProject(@Nonnull @VDelegatesToWithClosureParam(IProject.class) Closure<T> code);

    /**
     * Returns the advanced options of the {@link IProjectRef}.
     *
     * @return the advanced options
     */
    @PublishedMethod
    IProjectRefAdvancedUsage advanced();

    /**
     * Returns the advanced options of the {@link IProjectRef}.
     *
     * @return the advanced options
     */
    @PublishedMethod
    IProjectRefAdvancedUsage getAdvanced();

    /**
     * {@link IProjectRefAdvancedUsage} provides methods for advanced usages of {@link IProject} instances.
     *
     * <div class="extdoc" id="IProjectRefAdvancedUsage"><!--Label:sec:IProjectRefAdvancedUsage-->
     * <h5>Advanced Open Project Use Cases</h5> The method {@link IProjectRef#advanced()} provides methods for advanced usages of {@link IProject} instances. For example you can
     * open a project which will not be closed when the open stack frame is left. This can be helpful for unit tests.
     * <ul>
     * <li>{@code IProjectRefAdvancedUsage.openProject()}: Open the project and return the {@link IProject} as reference, but you have to manually close the project.</li>
     * </ul>
     *
     * The {@link IProjectRefAdvancedUsage} API this only for special use cases, with have very narrow scope. If you are not sure that you need it don't use it.
     *
     * </div>
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     * @noimplement This interface is not intended to be implemented by clients.
     * @see IProject
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IProjectRefAdvancedUsage extends IProjectRef {

        /**
         * Opens this {@link IProjectRef}'s {@link IProject} and returns the {@link IProject}.
         *
         * <p>
         * <b>Caution:</b> You have to close the {@link IProject}, with the {@link IProject#close()} method, when you are finished with processing. If the {@link IProject} is
         * not could until the {@link IScriptTask} execution is finished, to execution will fail!
         * </p>
         *
         * @return the opened project
         */
        @PublishedMethod
        IProject openProject();

    }
}
