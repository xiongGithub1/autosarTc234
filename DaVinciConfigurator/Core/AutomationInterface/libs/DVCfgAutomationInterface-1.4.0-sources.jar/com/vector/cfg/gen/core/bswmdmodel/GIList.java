package com.vector.cfg.gen.core.bswmdmodel;

import java.util.Collection;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * Interface which represents a collection for objects with upper multiplicity > 1.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @param <VALUE> the generic type
 */
//CHECKSTYLE:OFF Class Naming problem
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface GIList<VALUE extends GIModelObject> extends List<VALUE> {
    //CHECKSTYLE:ON

    /**
     * Creates a new child element and appends it to this {@link GIList}. The new object is finally returned.
     *
     * @return the created element
     */
    @PublishedMethod
    VALUE createAndAdd();

    /**
     * Creates a new child element and inserts it to this {@link GIList} at the specified index position . The new object is finally returned.
     *
     * @param index the index
     * @return the created element
     */
    @PublishedMethod
    VALUE createAndAdd(int index);

    /**
     * @deprecated This method is not supported for {@link GIList}
     */
    @Override
    @Deprecated
    @PublishedMethod
    void add(int index, VALUE element);

    /**
     * @deprecated This method is not supported for {@link GIList}
     */
    @Override
    @Deprecated
    @PublishedMethod
    boolean add(VALUE e);

    /**
     * @deprecated This method is not supported for {@link GIList}
     */
    @Override
    @Deprecated
    @PublishedMethod
    boolean addAll(Collection<? extends VALUE> c);

    /**
     * @deprecated This method is not supported for {@link GIList}
     */
    @Override
    @Deprecated
    @PublishedMethod
    boolean addAll(int index, Collection<? extends VALUE> c);

    /**
     * @deprecated This method is not supported for {@link GIList}
     */
    @Override
    @Deprecated
    @PublishedMethod
    VALUE set(int index, VALUE element);

}
