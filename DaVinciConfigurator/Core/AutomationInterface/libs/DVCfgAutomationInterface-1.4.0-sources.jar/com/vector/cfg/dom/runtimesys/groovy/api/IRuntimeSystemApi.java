package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.abstraction.api.IModelAbstraction;
import com.vector.cfg.model.mdf.IModelObject;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.model.sysdesc.api.component.IComponentType;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.model.sysdesc.api.taskmapping.IEvent;
import com.vector.cfg.model.sysdesc.api.taskmapping.IExecutableEntity;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IRuntimeSystemApi {

    /**
     * <div class="extdoc" id="selectComponentPorts"><!--Label:IRuntimeSystemApi.selectComponentPorts-->{@link #selectComponentPorts(Closure)} allows the selection of
     * {@link IComponentPort}s using predicates.</div> See {@link ISourceComponentPortSelector} for the available predicates.
     *
     * @param code the predicates for selecting component ports
     * @return the {@link IComponentPortSelection}
     */
    @PublishedMethod
    IComponentPortSelection selectComponentPorts(@Nonnull @VDelegatesToWithClosureParam(ISourceComponentPortSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="selectCommunicationElements"><!--Label:IRuntimeSystemApi.selectCommunicationElements-->{@link #selectCommunicationElements(Closure)} allows the
     * selection of {@link ICommunicationElement}s using predicates.</div> See {@link ICommunicationElementSelector} for the available predicates.
     *
     * @param code the predicates for selecting communication elements
     * @return the {@link ICommunicationElementSelection}
     */
    @PublishedMethod
    ICommunicationElementSelection selectCommunicationElements(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="selectSignalInstances"><!--Label:IRuntimeSystemApi.selectSignalInstances-->{@link #selectSignalInstances(Closure)} allows the selection of
     * {@link IAbstractSignalInstance}s using predicates.</div> See {@link ISignalInstanceSelector} for the available predicates.
     *
     * @param code the predicates for selecting signal instances
     * @return the {@link ISignalInstanceSelection}
     */
    @PublishedMethod
    ISignalInstanceSelection selectSignalInstances(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id=
     * "getModelAbstractionsForMdfObjects"><!--Label:IRuntimeSystemApi.getModelAbstractionsForMdfObjects-->{@link #getModelAbstractionsForMdfObjects(Collection)} is a method for
     * an arbitrary access to all model abstractions which correspond to the given collection of MDF objects.</div>
     * <p>
     * If a given MDF object is removed or not visible for the currently active variant view it will be ignored.
     * </p>
     *
     * <p>
     * The method may determine IModelAbstractions which are not yet part of the published Automation Interface. Nevertheless using the common methods in
     * {@link IModelAbstraction} is allowed.
     * </p>
     *
     * @param mdfObjects The MDF objects for which model abstractions should be retrieved.
     * @return A collection of model abstraction which represent the given MDF objects.
     */
    @PublishedMethod
    Collection<? extends IModelAbstraction> getModelAbstractionsForMdfObjects(Collection<IModelObject> mdfObjects);

    /**
     * <div class="extdoc" id="selectComponentTypes"><!--Label:IRuntimeSystemApi.selectComponentTypes-->{@link #selectComponentTypes(Closure)} allows the selection of
     * {@link IComponentType}s using predicates.</div> See {@link IComponentTypeSelector} for the available predicates.
     *
     * @param code the predicates for selecting component types
     * @return the {@link IComponentTypeSelection}
     */
    @PublishedMethod
    IComponentTypeSelection selectComponentTypes(@Nonnull @VDelegatesToWithClosureParam(IComponentTypeSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="selectEvents"><!--Label:IRuntimeSystemApi.selectEvents-->{@link #selectEvents(Closure)} allows the selection of {@link IEvent}s using
     * predicates.</div> See {@link IEventSelector} for the available predicates.
     *
     * @param code the predicates for selecting events
     * @return the {@link IEventSelection}
     */
    @PublishedMethod
    IEventSelection selectEvents(@Nonnull @VDelegatesToWithClosureParam(IEventSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="selectExecutableEntities"><!--Label:IRuntimeSystemApi.selectExecutableEntities-->{@link #selectExecutableEntities(Closure)} allows the selection
     * of {@link IExecutableEntity}s using predicates.</div> See {@link IExecutableEntitySelector} for the available predicates.
     *
     * @param code the predicates for selecting executable entities
     * @return the {@link IExecutableEntitySelection}
     */
    @PublishedMethod
    IExecutableEntitySelection selectExecutableEntities(@Nonnull @VDelegatesToWithClosureParam(IExecutableEntitySelector.class) Closure<?> code);

}
