package com.vector.cfg.gen.core.utils.formatting.structures;

import static com.google.common.base.Preconditions.checkNotNull;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.formatting.IGenElement;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.IHierarchicGenElement;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractGenElement;
import com.vector.cfg.gen.core.utils.formatting.structures.internal.GenElementSwitch;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * {@link AbstractGenStructure} is an abstract implementation for structure elements for formatting, see {@link IHierarchicGenElement} for more details.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractGenStructure<E extends AbstractGenStructure<E>> extends AbstractGenElement<E> implements IHierarchicGenElement {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractGenStructure.class);

    @PublishedField
    protected final List<IGenElement> arrayList = new ArrayList<>();

    @PublishedField
    protected final String blockOpenTag;

    @PublishedField
    protected final String blockCloseTag;

    @PublishedField
    protected final String elementSeperationTag;

    private String afterBlockOpenComment;

    private String beforeBlockCloseComment;

    private String header;

    private String footer;

    AbstractGenStructure() {
        blockOpenTag = "{";
        blockCloseTag = "}";
        elementSeperationTag = ", ";
    }

    AbstractGenStructure(String blockOpenTag, String blockCloseTag, String elementSeperationTag) {
        this.blockOpenTag = blockOpenTag;
        this.blockCloseTag = blockCloseTag;
        this.elementSeperationTag = elementSeperationTag;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    public E header(String headerParam) {
        ensureObjectIsMutable();

        if (headerParam == null) {
            throw new IllegalArgumentException("headerParam is null");
        }

        if (header != null) {
            throw new IllegalStateException("The header was already set.");
        }

        this.header = headerParam;

        return (E) this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    public E footer(String footerParam) {
        ensureObjectIsMutable();

        if (footerParam == null) {
            throw new IllegalArgumentException("footerParam is null");
        }

        if (footer != null) {
            throw new IllegalStateException("The footer was already set.");
        }

        this.footer = footerParam;

        return (E) this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    public E afterBlockOpenComment(String commentParam) {
        ensureObjectIsMutable();

        if (commentParam == null) {
            throw new IllegalArgumentException("commentParam is null");
        }

        if (afterBlockOpenComment != null) {
            /*
             * Append the new Comment to the existing
             */
            afterBlockOpenComment += commentParam;
        } else {
            afterBlockOpenComment = commentParam;
        }

        return (E) this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    public E beforeBlockCloseComment(String commentParam) {
        ensureObjectIsMutable();

        if (commentParam == null) {
            throw new IllegalArgumentException("commentParam is null");
        }

        if (beforeBlockCloseComment != null) {
            /*
             * Append the new Comment to the existing
             */
            beforeBlockCloseComment += commentParam;
        } else {
            beforeBlockCloseComment = commentParam;
        }

        return (E) this;
    }

    /**
     * Returns the number of elements in this structure. It will only count the elements in current level subelement are not counted.
     *
     * @return the number of elements in this structure
     */
    @PublishedMethod
    public int size() {
        return arrayList.size();
    }

    /**
     * Returns true, if the Array is Empty, otherwise false.
     *
     * @return Returns true, if the Array is Empty, otherwise false.
     */
    @PublishedMethod
    public boolean isEmpty() {
        return arrayList.size() == 0;
    }

    /**
     * Appends the element to the end of the array.
     *
     * @param obj The element to add
     * @return The current GenArray
     *
     * @exception NullPointerException <ul>
     * <li>if the obj is null</li>
     * </ul>
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public E append(Object obj) {
        ensureObjectIsMutable();
        if (obj == null) {
            throw new NullPointerException("Can not create a GenElement for a null object. Passing null is not allowed.");
        }
        final IGenElement genElement = GenElementSwitch.getGenElementByObject(obj);
        if (genElement == null) {
            throw new NullPointerException(MessageFormat.format("Can not create a GenElement for the given element:{0}", obj.toString()));
        }

        arrayList.add(genElement);

        return (E) this;
    }

    /**
     * Appends the list of objects to the end of the array.
     *
     * @param obj The list of objects to add
     * @return The current GenArray
     *
     * @exception NullPointerException <ul>
     * <li>if the objects is null</li>
     * </ul>
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public E append(Object... objects) {
        ensureObjectIsMutable();
        checkNotNull(objects, "Can not create  GenElements for a null object. Passing null is not allowed.");

        for (final Object obj : objects) {
            append(obj);
        }

        return (E) this;
    }

    /**
     * Appends the collection to the end of the array.
     *
     * @param obj The collection to add
     * @return The current GenArray
     *
     * @exception NullPointerException <ul>
     * <li>if the collection is null</li>
     * </ul>
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public E append(Iterable<? super Object> collection) {
        ensureObjectIsMutable();

        if (collection == null) {
            throw new NullPointerException("collection parameter is null");
        }
        for (final Object obj : collection) {
            append(obj);
        }

        return (E) this;
    }

    /**
     * Creates a new inner structure. Appends it to the current structure, and returns the <b>inner</b> structure.
     *
     * @return The new inner structure
     */
    @PublishedMethod
    public abstract E createInner();

    @PublishedMethod
    @SuppressWarnings("rawtypes")
    @Override
    protected void generateInternal(StringBuilder builder, IGenFormatter formatter, int indent, boolean isRootElement) {

        if (header != null) {
            formatter.formatPreHeader(builder, indent, this);
            builder.append(header);
            formatter.formatPostHeader(builder, indent, this);
        }
        if (isRootElement) {
            formatter.formatPreBlockStart(builder, indent);
        }

        generatePrefixComment(builder);
        builder.append(blockOpenTag);
        generateAfterBlockOpenComment(builder);

        formatter.formatPostBlockStart(builder, indent);

        final int innerIndent = indent + 1;

        int x = 0;
        final int size = arrayList.size();
        for (final IGenElement element : arrayList) {

            if (element instanceof AbstractGenStructure) {

                formatter.formatPreBlockStart(builder, innerIndent);

                ((AbstractGenStructure) element).generateInternal(builder, formatter, innerIndent, false);

                if (x != size - 1) {
                    // Generate a , when it is not the last Element
                    builder.append(elementSeperationTag);
                }
                formatter.formatPostBlockEnd(builder, innerIndent);

            } else if (element instanceof GenPreprocessCondition) {

                ((GenPreprocessCondition) element).generateInternal(builder, formatter, innerIndent, false);

            } else {

                formatter.formatPreElement(builder, innerIndent);
                element.generate(builder, formatter, innerIndent, false);

                if (x != size - 1) {
                    // Generate a , when it is not the last Element
                    builder.append(elementSeperationTag);
                }

                formatter.formatPostElement(builder, innerIndent);
            }

            x++;
        }

        formatter.formatPreBlockEnd(builder, indent);

        generateBeforeBlockCloseComment(builder);
        builder.append(blockCloseTag);
        generatePostfixComment(builder);
        if (footer != null) {
            formatter.formatPreFooter(builder, indent, this);
            builder.append(footer);
            formatter.formatPostFooter(builder, indent, this);
        }

        // Do not Add any PostBlock formating for the root Object
        return;
    }

    @PublishedMethod
    protected final void generateAfterBlockOpenComment(StringBuilder builder) {
        if (afterBlockOpenComment != null) {
            generateCommentInternal(builder, afterBlockOpenComment);
        }
    }

    @PublishedMethod
    protected final void generateBeforeBlockCloseComment(StringBuilder builder) {
        if (beforeBlockCloseComment != null) {
            generateCommentInternal(builder, beforeBlockCloseComment);
        }
    }

}
