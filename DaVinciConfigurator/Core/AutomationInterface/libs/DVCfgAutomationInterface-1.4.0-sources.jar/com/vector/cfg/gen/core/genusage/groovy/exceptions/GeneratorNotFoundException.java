package com.vector.cfg.gen.core.genusage.groovy.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public class GeneratorNotFoundException extends RuntimeException {

    @PublishedMethod
    public GeneratorNotFoundException(String string) {
        super(string);
    }

    /**
     * <code>serialVersionUID</code> describes UID for this exception.
     */
    private static final long serialVersionUID = 6967296753493120654L;

}
