package com.vector.cfg.gen.core.genusage.result.model;

import java.util.Set;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * This interface represents the root node of the tree of all executed generators and external generation steps.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGenerationResultRoot extends IGenModelElement {

    /**
     * Gets the all generator and step elements.
     *
     * @param <T> the generic type
     * @return the all generator and step elements
     */
    @PublishedMethod
    <T extends IGenerationItem> Set<T> getAllGeneratorAndStepElements();

}
