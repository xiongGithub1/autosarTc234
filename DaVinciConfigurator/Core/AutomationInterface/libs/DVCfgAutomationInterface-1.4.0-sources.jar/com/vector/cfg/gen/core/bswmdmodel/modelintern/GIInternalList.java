package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIList;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
//CHECKSTYLE:OFF Class Naming problem
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface GIInternalList<VALUE extends GIModelObject> extends GIList<VALUE> {
    //CHECKSTYLE:ON

    /**
     * Invalidate cache. Resets the internal children list.
     */
    @PublishedMethod
    void invalidateCache();
}
