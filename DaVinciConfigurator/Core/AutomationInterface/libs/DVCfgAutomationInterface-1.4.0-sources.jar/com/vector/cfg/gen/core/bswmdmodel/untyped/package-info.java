/**
 * The BswmdModel interface and base types for the an untyped access without a generated BswmdModel.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.bswmdmodel.untyped;