package com.vector.cfg.gen.core.bswmdmodel.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.bswmdmodel.GIReference;

/**
 * Thrown to indicate that the model object has an illegal reference target.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class BswmdModelReferenceTargetException extends BswmdModelException {
    private static final long serialVersionUID = 7865018849827831775L;

    private final GIReference<?> reference;

    /**
     * Constructor for BswmdModelReferenceTargetException.
     *
     * @param genResult the gen result
     * @param reference the reference
     */
    @PublishedMethod
    public BswmdModelReferenceTargetException(IValidationResult genResult, GIReference<?> reference) {
        super(genResult, reference.getParent());
        this.reference = reference;
    }

    /**
     * Returns the reference model object.
     *
     * @return the reference
     */
    @PublishedMethod
    public GIReference<?> getReference() {
        return reference;
    }

}
