package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.google.common.base.Strings;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIReference;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasIllegalValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasNoValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelReferenceTargetException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelWrongQuantityException;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.davinci.util.base.VUtil;

/**
 *
 * The abstract base class for bswmd model references.
 *
 * <p>
 * Attention: Please use {@link GIReference} interface in client code.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class GAbstractRef<REF_TARGET extends MIReferrable> extends GAbstractParamOrRef implements GIReference<REF_TARGET> {

    private String path = null;

    private MIReferrable target = null;

    private boolean initialized;

    /**
     * Constructor.
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GAbstractRef(@Nonnull DefRef defRef, @Nullable MIParameterValue parameter, @Nonnull IInternalGeneratorModelAccess modelAccess, @Nonnull GIContainer parent,
            boolean onlyOneElement) {
        super(defRef, parameter, modelAccess, parent, onlyOneElement);
    }

    /**
     * Constructor.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     */
    @PublishedMethod
    public GAbstractRef(@Nonnull IInternalGeneratorModelAccess modelAccess, @Nonnull DefRef defRef, @Nullable MIParameterValue parameter, @Nonnull GIContainer parent,
            boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean hasPath() {
        try {
            checkForInitialization();
            return !Strings.isNullOrEmpty(path);
        } catch (final BswmdModelNotExistsException
                | BswmdModelParameterHasNoValueException
                | BswmdModelParameterHasIllegalValueException
                | BswmdModelReferenceTargetException
                | BswmdModelWrongQuantityException ex) {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean hasRefTarget() {
        try {
            checkForInitialization();
            return target != null;
        } catch (final BswmdModelNotExistsException
                | BswmdModelParameterHasNoValueException
                | BswmdModelParameterHasIllegalValueException
                | BswmdModelReferenceTargetException
                | BswmdModelWrongQuantityException ex) {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public boolean asBoolean() {
        if (existsMDF() && hasPath() && hasRefTarget()) {
            return true;
        }
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getPath() {
        try {
            switchView();

            checkForInitialization();
            getModelVerifier().assertReferencePathNotNull(this, path);
            return path;
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    public REF_TARGET getRefTargetMdf() {
        try {
            switchView();

            checkForInitialization();
            getModelVerifier().assertReferenceTargetNotNull(this, target);
            return (REF_TARGET) target;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setRefTargetMdf(REF_TARGET referenceTarget) {

        // Creates a new element if it is missing
        if (!existsMDF()) {
            BswmdModelInternalElementFactory.createParam(getParent(), VUtil.uncheckedCast(getDefRef()), null, this);
        }

        final IModelViewManager vm = getGeneratorModelAccess().getModelViewManager();
        try (IModelViewExecutionContext viewContext = vm.executeWithModelView(getCreationModelView())) {
            try (IModelViewExecutionContext modeContext = vm.executeWithVariantSpecificModelChanges()) {
                final MIParameterValue mdfObject = getMdfObject();
                if (!(mdfObject instanceof MIReferenceValue)) {
                    throw new UnsupportedOperationException("Only MIReferenceValues are currently supported!");
                }
                getGeneratorModelAccess().getMdfModelAccess().setReferenceValue((MIReferenceValue) mdfObject, referenceTarget);
            }
        }
    }

    /**
     * Inits the current reference by the subclass implementation.
     */
    @PublishedMethod
    protected abstract void initRef();

    /**
     * Gets the target {@link MIReferrable} in an unsafe manner.
     *
     * @return the target unsafe
     */
    @PublishedMethod
    protected final MIReferrable getTargetUnsafe() {
        return target;
    }

    /**
     * Check for initialization.
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the reference does not exist</li>
     * </ul>
     * @exception BswmdModelParameterHasNoValueException
     * <ul>
     * <li>if the reference not valid paths</li>
     * </ul>
     * @exception BswmdModelReferenceTargetException
     * <ul>
     * <li>if the reference has no ref targets</li>
     * </ul>
     */
    @PublishedMethod
    protected final void checkForInitialization() {
        try {
            switchView();
            checkCacheAndInvalidateIfNecessary();

            if (!initialized) {
                initRef();
                initialized = true;
            }

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void invalidateCache() {
        super.invalidateCache();
        initialized = false;
    }

    /**
     * Sets the target.
     *
     * @param target the new target
     */
    @PublishedMethod
    protected void setTarget(MIReferrable target) {
        this.target = target;
    }

    /**
     * Sets the path.
     *
     * @param path the new path
     */
    @PublishedMethod
    protected void setPath(String path) {
        this.path = path;
    }

}
