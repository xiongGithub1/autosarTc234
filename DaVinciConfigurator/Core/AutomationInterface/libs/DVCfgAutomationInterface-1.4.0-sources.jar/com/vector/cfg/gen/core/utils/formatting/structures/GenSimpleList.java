package com.vector.cfg.gen.core.utils.formatting.structures;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractGenElement;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractPrimitiveElement;
import com.vector.cfg.gen.core.utils.formatting.structures.GenSimpleList.ListElement;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The Format class for simple lists.
 *
 * Every element pair is separated by a newline.
 *
 * <p>
 * Example: <br/>
 * <code><pre>
 * CHL_1
 * My_CHL2
 * CHL_503
 * Type Value
 * First Second
 * </pre></code>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GenSimpleList extends AbstractGenList<GenSimpleList, ListElement> {

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenSimpleList.class);

    @PublishedField
    public static final GenSimpleList EMPTY_LIST = create().setImmutable();

    @PublishedMethod
    protected GenSimpleList() {
        super();

    }

    @PublishedMethod
    public static GenSimpleList create() {
        final GenSimpleList simpleList = createInternal();

        return simpleList;

    }

    private static GenSimpleList createInternal() {
        return new GenSimpleList();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected ListElement createNewListElement(AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> elem1,
            AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> elem2) {
        return new ListElement(elem1, elem2);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void generateInternal(StringBuilder builder, IGenFormatter formatter, int indent, boolean isRootElement) {

        generateHeader(builder, formatter, indent, this);

        generatePrefixComment(builder);

        for (final ListElement element : getGenList()) {

            formatter.formatPreElement(builder, indent);

            element.getFirst().generate(builder, formatter, indent, false);

            if (element.getSecond() != null) {

                builder.append(" ");
                element.getSecond().generate(builder, formatter, indent, false);
            }

            builder.append(" \r\n");

            formatter.formatPostElement(builder, indent);

        }

        generatePostfixComment(builder);

        generateFooter(builder, formatter, indent, this);
    }

    /**
     * List element used by the {@link GenSimpleList}
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     * @since 1.0
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    public class ListElement extends AbstractGenElement<ListElement> {

        private final AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> first;

        private final AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> second;

        @PublishedMethod
        public ListElement(AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> def, AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> val) {
            first = def;
            second = val;
        }

        @PublishedMethod
        public AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> getFirst() {
            return first;
        }

        @PublishedMethod
        public AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> getSecond() {
            return second;
        }

        /**
         * {@inheritDoc}
         */
        @PublishedMethod
        @Override
        protected void generateInternal(StringBuilder builder, IGenFormatter formatter, int indent, boolean isRootElement) {
            throw new IllegalStateException("Method is not supported");

        }

    }

}
