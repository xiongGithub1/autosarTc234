package com.vector.cfg.gen.core.utils.formatting.structures.internal;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.MessageFormat;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.param.GBoolean;
import com.vector.cfg.gen.core.bswmdmodel.param.GEnumeration;
import com.vector.cfg.gen.core.bswmdmodel.param.GFloat;
import com.vector.cfg.gen.core.bswmdmodel.param.GInteger;
import com.vector.cfg.gen.core.bswmdmodel.param.GString;
import com.vector.cfg.gen.core.utils.formatting.IGenElement;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenElementSwitch {

    private GenElementSwitch() {

    }

    @PublishedMethod
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static IGenElement getGenElementByObject(Object obj) {

        /*
         * GenElements
         */
        if (obj instanceof IGenElement) {
            return (IGenElement) obj;

        }
        /*
         * String
         */
        else if (obj instanceof String) {
            return F.formatString((String) obj);
        } else if (obj instanceof GString) {
            return F.formatString((GString) obj);
        }
        /*
         * Integer
         */
        else if (obj instanceof Byte) {
            return F.formatInt((Byte) obj);
        } else if (obj instanceof Short) {
            return F.formatInt((Short) obj);
        } else if (obj instanceof Integer) {
            return F.formatInt((Integer) obj);
        } else if (obj instanceof GInteger) {
            return F.formatInt((GInteger) obj);
        } else if (obj instanceof Long) {
            return F.formatInt((Long) obj);
        } else if (obj instanceof BigInteger) {
            return F.formatInt((BigInteger) obj);
        }
        /*
         * Enum
         */
        else if (obj instanceof Enum) {
            return F.formatEnum((Enum) obj);
        } else if (obj instanceof GEnumeration) {
            return F.formatEnum((GEnumeration) obj);
        }
        /*
         * Boolean
         */
        else if (obj instanceof Boolean) {
            return F.formatBool((Boolean) obj);
        } else if (obj instanceof GBoolean) {
            return F.formatBool((GBoolean) obj);
        }

        /*
         * Float
         */
        else if (obj instanceof GFloat) {
            return F.formatFloat((GFloat) obj);
        } else if (obj instanceof Float) {
            return F.formatFloat((Float) obj);
        } else if (obj instanceof Double) {
            return F.formatFloat((Double) obj);
        } else if (obj instanceof BigDecimal) {
            return F.formatFloat((BigDecimal) obj);
        } else {
            final String className;
            if (obj == null) {
                className = "null";
            } else {
                className = obj.getClass().getName();
            }
            throw new IllegalArgumentException(MessageFormat.format("Object type {0} not supported. Please convert the type into a Format type. See class F.", className));
        }

    }
}
