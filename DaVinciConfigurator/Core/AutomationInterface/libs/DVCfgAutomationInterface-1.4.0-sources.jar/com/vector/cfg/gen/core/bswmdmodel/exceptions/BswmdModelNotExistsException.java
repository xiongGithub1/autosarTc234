package com.vector.cfg.gen.core.bswmdmodel.exceptions;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.model.access.DefRef;

/**
 * Thrown to indicate that a requested model object does not exist.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class BswmdModelNotExistsException extends BswmdModelException {

    private static final long serialVersionUID = -1315616586528750199L;

    private final DefRef defRef;

    /**
     * Constructor for BswmdModelNotExistsException.
     *
     * @param result the result
     * @param parent the parent
     * @param defRef the def ref
     */
    @PublishedMethod
    public BswmdModelNotExistsException(IValidationResult result, @Nullable GIModelObject parent, DefRef defRef) {
        super(result, parent);
        this.defRef = defRef;
    }

    /**
     * Returns the definition Ref of the requested model object.
     *
     * @return
     */
    @PublishedMethod
    public DefRef getDefRef() {
        return defRef;
    }

}
