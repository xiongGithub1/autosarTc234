package com.vector.cfg.gen.core.utils.formatting;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.formatting.formatter.AbstractFormatter;

/**
 * The formatter interface for all {@link IGenElement}s.
 * <p>
 * If you want to implement a formatter, you have to implement the {@link IGenFormatProvider} interface too.
 * </p>
 * <p>
 * Attention: This interface is not intended to be implemented by the user! Please use class {@link AbstractFormatter} as base class.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenFormatter {

    @PublishedMethod
    void formatPreBlockStart(StringBuilder builder, int indent);

    @PublishedMethod
    void formatPostBlockStart(StringBuilder builder, int indent);

    @PublishedMethod
    void formatPreBlockEnd(StringBuilder builder, int indent);

    @PublishedMethod
    void formatPostBlockEnd(StringBuilder builder, int indent);

    @PublishedMethod
    void formatPreElement(StringBuilder builder, int indent);

    @PublishedMethod
    void formatPostElement(StringBuilder builder, int indent);

    /**
     * This method is called, when a new element is formatted.
     * <p>
     * You can use this method to format a Header before an element
     * </p>
     *
     * @param builder the builder
     * @param indent the indent
     * @param element the element to format
     */
    @PublishedMethod
    void formatPreHeader(StringBuilder builder, int indent, IListGenElement element);

    /**
     * This method is called, when a new element is formatted.
     * <p>
     * You can use this method to format a Header before an element
     * </p>
     *
     * @param builder the builder
     * @param indent the indent
     * @param element the element to format
     */
    @PublishedMethod
    void formatPostHeader(StringBuilder builder, int indent, IListGenElement element);

    /**
     * This method is called, when a element was formatted.
     * <p>
     * You can use this method to format a footer after an element
     * </p>
     *
     * @param builder the builder
     * @param indent the indent
     * @param element the element
     * @param footer the footerString from the element
     */
    @PublishedMethod
    void formatPreFooter(StringBuilder builder, int indent, IListGenElement element);

    /**
     * This method is called, when a element was formatted.
     * <p>
     * You can use this method to format a footer after an element
     * </p>
     *
     * @param builder the builder
     * @param indent the indent
     * @param element the element
     * @param footer the footerString from the element
     */
    @PublishedMethod
    void formatPostFooter(StringBuilder builder, int indent, IListGenElement element);
}
