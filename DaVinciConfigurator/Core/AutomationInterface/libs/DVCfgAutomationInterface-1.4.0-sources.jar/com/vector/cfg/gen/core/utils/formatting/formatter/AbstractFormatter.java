package com.vector.cfg.gen.core.utils.formatting.formatter;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.GenConstants;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatProvider;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.IListGenElement;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * {@link AbstractFormatter} provides the abstract implementation for an {@link IGenFormatter}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractFormatter implements IGenFormatProvider, IGenFormatter {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractFormatter.class);

    /**
     * Instantiates a new formatter.
     */
    @PublishedMethod
    protected AbstractFormatter() {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IGenFormatter getFormatter() {
        return this;
    }

    /**
     * Checks if is last entry a new line.
     *
     * @param builder the builder
     * @return true, if is last entry a new line
     */
    @PublishedMethod
    protected boolean isLastEntryANewLine(StringBuilder builder) {
        if (builder.length() - GenConstants.LINE_SEPARATOR.length() >= 0) {
            final String lastChars = builder.substring(builder.length() - GenConstants.LINE_SEPARATOR.length());
            if (lastChars.equals(GenConstants.LINE_SEPARATOR)) {
                return true;
            }
        }
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreBlockStart(StringBuilder builder, int indent) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostBlockStart(StringBuilder builder, int indent) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreBlockEnd(StringBuilder builder, int indent) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostBlockEnd(StringBuilder builder, int indent) {
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreElement(StringBuilder builder, int indent) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostElement(StringBuilder builder, int indent) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreHeader(StringBuilder builder, int indent, IListGenElement element) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostHeader(StringBuilder builder, int indent, IListGenElement element) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreFooter(StringBuilder builder, int indent, IListGenElement element) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostFooter(StringBuilder builder, int indent, IListGenElement element) {

    }

}
