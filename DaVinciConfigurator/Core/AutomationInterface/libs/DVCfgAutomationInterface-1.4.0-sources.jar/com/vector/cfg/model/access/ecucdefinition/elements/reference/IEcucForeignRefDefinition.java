package com.vector.cfg.model.access.ecucdefinition.elements.reference;

import javax.annotation.concurrent.NotThreadSafe;
import javax.jmi.reflect.RefClass;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIForeignReferenceParamDef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucForeignRefDefinition extends IEcucAbstractRef {

    /**
     * Returns an optional holding the target ref class. Never returns <code>null</code>.
     *
     * @return
     * @deprecated Not required anymore. Otherwise use {@link #getDestinationTypeForForeignReference()}
     */
    @PublishedMethod
    @Deprecated
    @ReworkThisAtNextBreakingChange("Remove this method - no internal and external usage found in R16!")
    Optional<? extends RefClass> getTargetRefClass();

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    MIForeignReferenceParamDef getDef();

    /**
     * Returns the MDF type which is allowed as type of referenced objects as defined in the specified foreign reference definition.
     *
     * @return
     */
    @PublishedMethod
    Optional<Class<? extends MIReferrable>> getDestinationTypeForForeignReference();

}
