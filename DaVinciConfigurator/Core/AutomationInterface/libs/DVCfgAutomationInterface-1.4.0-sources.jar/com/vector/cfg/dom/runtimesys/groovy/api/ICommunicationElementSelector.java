package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link ICommunicationElementSelector} Api allows the definition of predicates for communication element selection.
 * <p>
 * <div class="extdoc" id="ICommunicationElementSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICommunicationElementSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} Add a custom predicated which matches communication elements for which the given closure results
     * to true.</div>
     *
     * @param code The closure to select communication elements.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(ICommunicationElement.class) Closure<Boolean> code);

    /**
     * <div class="extdoc" id="unconnected">{@link #unconnected()} matches communication elements whose component port is unconnected.</div>
     */
    @PublishedMethod
    void unconnected();

    /**
     * <div class="extdoc" id="connected">{@link #connected()} matches communication elements whose component port is connected.</div>
     */
    @PublishedMethod
    void connected();

    /**
     * <div class="extdoc" id="unmapped">{@link #unmapped()} matches communication elements whose are not data-mapped.</div>
     */
    @PublishedMethod
    void unmapped();

    /**
     * <div class="extdoc" id="mapped">{@link #mapped()} matches communication elements whose are data-mapped.</div>
     */
    @PublishedMethod
    void mapped();

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches communication elements with the given data element or operation name.</div>
     *
     * @param name A data element or operation name.
     */
    @PublishedMethod
    void name(String name);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches communication elements with the given data element or operation name pattern.</div>
     *
     * @param namePattern A data element or operation name pattern.
     */
    @PublishedMethod
    void name(Pattern namePattern);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches communication elements with the given data element or operation autosar path.</div>
     *
     * @param asrPath A data element or operation autosar path.
     */
    @PublishedMethod
    void asrPath(String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches communication elements with the given data element or operation autosar path pattern.</div>
     *
     * @param asrPathPattern A data element or operation autosar path pattern.
     */
    @PublishedMethod
    void asrPath(Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="port">{@link #port(String)} matches communication elements with the given component port name.</div>
     *
     * @param portName A component port name.
     */
    @PublishedMethod
    void port(String portName);

    /**
     * <div class="extdoc" id="portPattern">{@link #port(Pattern)} matches communication elements with the given component port name pattern.</div>
     *
     * @param portNamePattern A component port name pattern.
     */
    @PublishedMethod
    void port(Pattern portNamePattern);

    /**
     * <div class="extdoc" id="portAsrPath">{@link #portAsrPath(String)} matches communication elements with the given component port autosar path.</div>
     *
     * @param portAsrPath A component port autosar path.
     */
    @PublishedMethod
    void portAsrPath(String portAsrPath);

    /**
     * <div class="extdoc" id="portAsrPathPattern">{@link #portAsrPath(Pattern)} matches communication elements with the given component port autosar path pattern.</div>
     *
     * @param portAsrPathPattern A component port autosar path pattern.
     */
    @PublishedMethod
    void portAsrPath(Pattern portAsrPathPattern);

    /**
     * <div class="extdoc" id="component">{@link #component(String)} matches communication elements with the given component name.</div>
     *
     * @param componentName A component name.
     */
    @PublishedMethod
    void component(String componentName);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} matches communication elements with the given component name pattern.</div>
     *
     * @param componentNamePattern A component name pattern.
     */
    @PublishedMethod
    void component(Pattern componentNamePattern);

    /**
     * <div class="extdoc" id="componentAsrPath">{@link #componentAsrPath(String)} matches communication elements with the given component name autosar path.</div>
     *
     * @param componentAsrPath A component name autosar path.
     */
    @PublishedMethod
    void componentAsrPath(String componentAsrPath);

    /**
     * <div class="extdoc" id="componentAsrPathPattern">{@link #componentAsrPath(Pattern)} matches communication elements with the given component name autosar path
     * pattern.</div>
     *
     * @param componentAsrPathPattern A component name autosar path pattern.
     */
    @PublishedMethod
    void componentAsrPath(Pattern componentAsrPathPattern);

    /**
     * <div class="extdoc" id="senderReceiver">{@link #senderReceiver()} matches communication elements whose port has a sender/receiver port interface.</div>
     */
    @PublishedMethod
    void senderReceiver();

    /**
     * <div class="extdoc" id="clientServer">{@link #clientServer()} matches communication elements whose port has a client/server port interface.</div>
     */
    @PublishedMethod
    void clientServer();

    /**
     * <div class="extdoc" id="trigger">{@link #trigger()} matches communication elements whose port has a trigger port interface.</div>
     */
    @PublishedMethod
    void trigger();

    /**
     * <div class="extdoc" id="provided">{@link #provided()} matches communication elements whose port is a provided port (p-port).</div>
     */
    @PublishedMethod
    void provided();

    /**
     * <div class="extdoc" id="required">{@link #required()} matches communication elements whose port is a required port (r-port).</div>
     */
    @PublishedMethod
    void required();

    /**
     * <div class="extdoc" id="delegation">{@link #delegation()} matches communication elements whose port is delegation port.</div>
     */
    @PublishedMethod
    void delegation();

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<ICommunicationElement> getSelectedCommunicationElements();

    /**
     *
     * @return The selected communication elements filtered to be suitable for data mapping.
     */
    @KeepSecretFromPublishedApi
    List<com.vector.cfg.model.sysdesc.datamapping.ICommunicationElement> getSelectedCommunicationElementsSuitableForDataMapping();

}
