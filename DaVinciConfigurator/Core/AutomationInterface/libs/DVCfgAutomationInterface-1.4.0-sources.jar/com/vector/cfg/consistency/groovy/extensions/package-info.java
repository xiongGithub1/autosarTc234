/**
 * This package contains consistency-related groovy-extension-methods, e.g. for getting validation-results of an {@link com.vector.cfg.model.mdf.MIObject MIObject} or
 * {@link com.vector.cfg.model.access.DefRef DefRef}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
package com.vector.cfg.consistency.groovy.extensions;
