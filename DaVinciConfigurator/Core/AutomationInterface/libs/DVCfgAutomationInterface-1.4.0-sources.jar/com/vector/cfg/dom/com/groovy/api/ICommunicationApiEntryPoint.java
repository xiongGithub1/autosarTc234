package com.vector.cfg.dom.com.groovy.api;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link ICommunicationApiEntryPoint} is the entry point for accessing the communication domain interfaces.
 * <div class="extdoc" id="ICommunicationApiEntryPoint"><!--Label:ICommunicationApiEntryPoint-->The communication domain API is specifically designed to support communication
 * related use cases. It is available from the {@code IDomainApi} <!--Ref:IDomainApi--> in the form of the {@link ICommunicationApi} interface.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICommunicationApiEntryPoint {

    /**
     * {@link #getCommunication()} allows accessing the {@link ICommunicationApi} like a property.
     * <div class="extdoc" id="getCommunication"><!--Label:ICommunicationApiEntryPoint.getCommunication-->{@link #getCommunication()} allows accessing the
     * {@link ICommunicationApi} like a property.</div>
     *
     * @return the {@link ICommunicationApi}
     */
    @PublishedMethod
    ICommunicationApi getCommunication();

    /**
     * {@link #communication(Closure)} allows accessing the {@link ICommunicationApi} in a scope-like way.
     * <div class="extdoc" id="communication"><!--Label:ICommunicationApiEntryPoint.communication-->{@link #communication(Closure)} allows accessing the
     * {@link ICommunicationApi} in a scope-like way.</div>
     *
     * @param code the code (a {@link Closure}) working with the {@link ICommunicationApi}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T communication(@Nonnull @VDelegatesToWithClosureParam(ICommunicationApi.class) Closure<T> code);

}
