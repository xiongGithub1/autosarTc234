package com.vector.cfg.model.access.ecuconfiguration.elements;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucDefinition;
import com.vector.cfg.model.exceptions.InvisibleVariantObjectException;
import com.vector.cfg.model.exceptions.ModelCeHasNoDefinitionException;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 * Implementations of this interface doesn't care for object visibility. So, if the related object is invisible, accessing its content over this API will lead
 * to a {@link InvisibleVariantObjectException}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucHasDefinition {

    /**
     * Returns the related configuration object. Never returns <code>null</code>.
     *
     * @return
     */
    @PublishedMethod
    <T extends MIHasDefinition> T getEcucObject();

    /**
     * Returns <code>true</code> if the object is visible in the current model view.
     *
     * @return
     */
    @PublishedMethod
    boolean isVisible();

    /**
     * Returns <code>true</code> if the object has been removed from the MDF model (independent of the current visibility).
     *
     * @return
     */
    @PublishedMethod
    boolean isRemoved();

    /**
     * Returns <code>true</code> if the object has been removed from the MDF model or is invisible in the current model view.
     *
     * @return
     */
    @PublishedMethod
    boolean isRemovedOrInvisible();

    /**
     * Returns the definition path (the definition reference value path) if available.
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @return
     */
    @PublishedMethod
    Optional<String> getEcucDefinitionPath();

    /**
     * Returns <code>true</code> if this object has a definition (a target object of the definition reference). In this case calling
     * {@link #getEcucDefinition()} is safe.
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @return
     */
    @PublishedMethod
    boolean hasEcucDefinition();

    /**
     * Returns the definition of this object if available and throws a {@link ModelCeHasNoDefinitionException} if not. Never returns <code>null</code>.
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @return
     * @throws ModelCeHasNoDefinitionException if this object has no definition.
     */
    @PublishedMethod
    <T extends IEcucDefinition> T getEcucDefinition();

    /**
     * Removes the object from the MDF model.
     */
    @PublishedMethod
    void deleteFromModel();

}
