package com.vector.cfg.model.access;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.MessageFormat;
import java.util.Collection;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Interner;
import com.google.common.collect.Interners;
import com.google.common.collect.Sets;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.internal.access.IDefRefDefinitionCache;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.blockelements.MIDocumentationBlock;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIEcucAddInfoParamValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBooleanParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIChoiceContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIChoiceReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEcucAddInfoParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEcucMultilineStringParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEnumerationParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFloatParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIForeignReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFunctionNameDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIInstanceReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIIntegerParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MILinkerSymbolDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIStringParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MISymbolicNameReferenceParamDef;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.string.StringCache;

/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation">
 * <h3>TypedDefRefs</h3> The <code>TypedDefRef</code> class represents an AUTOSAR definition reference with the type of the AUTOSAR (MDF) model. So every {@link TypedDefRef}
 * knows which Definition, Configuration and Value element is correct for the Definition path.
 *
 * The <code>DEF_TYPE</code>, <code>CONFIG_TYPE</code> and <code>VALUE_TYPE</code> are Java generics and are used many APIs to return the specific type of a request.
 *
 * In addition the most {@link TypedDefRef}s also provide additional {@link TypeInfo} data, like the Multiplicity of the element. See {@link TypeInfo} javadoc for more details.
 *
 * </div>
 * <p>
 * DefRefs are constant; their values cannot be changed after they are created. This class is immutable!
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@Immutable
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class TypedDefRef<DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> extends DefRef implements IDebugable {
    private static final long serialVersionUID = -260003990965883372L;

    private static final ILogger logger = Logger.INSTANCE.createLogger(TypedDefRef.class);

    private final Class<DEF_TYPE> modelDefinitionClass;

    private final Class<CONFIG_TYPE> modelConfigClass;

    private final Class<VALUE_TYPE> valueClass;

    private final TypeInfo typeInfo;

    TypedDefRef(
            final String packagesPartOfDefRef,
            final String defRefWithoutPackagesLoc,
            @Nullable final String wholeDefRefString,
            final Class<DEF_TYPE> modelDefinitionClass,
            final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass,
            @Nullable final TypeInfo additionalInfos) {
        super(packagesPartOfDefRef, defRefWithoutPackagesLoc, wholeDefRefString);

        if (modelDefinitionClass == null) {
            throw new IllegalArgumentException("modelDefinitionClass is null.");
        }
        if (modelConfigClass == null) {
            throw new IllegalArgumentException("modelConfigClass is null.");
        }
        if (valueClass == null) {
            throw new IllegalArgumentException("valueClass is null.");
        }

        this.modelDefinitionClass = modelDefinitionClass;
        this.modelConfigClass = modelConfigClass;
        this.valueClass = valueClass;

        if (additionalInfos != null) {
            this.typeInfo = additionalInfos;
        } else {
            this.typeInfo = TypeInfo.NONE;
        }

    }

    TypedDefRef(final IDefRefWildcard packageWildcard, final String moduleDefRef, final Class<DEF_TYPE> modelDefinitionClass, final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass,
            @Nullable final TypeInfo additionalInfos) {
        super(packageWildcard, moduleDefRef);
        if (modelDefinitionClass == null) {
            throw new IllegalArgumentException("modelDefinitionClass is null.");
        }
        if (modelConfigClass == null) {
            throw new IllegalArgumentException("modelConfigClass is null.");
        }
        if (valueClass == null) {
            throw new IllegalArgumentException("valueClass is null.");
        }

        this.modelDefinitionClass = modelDefinitionClass;
        this.modelConfigClass = modelConfigClass;
        this.valueClass = valueClass;

        if (additionalInfos != null) {
            this.typeInfo = additionalInfos;
        } else {
            this.typeInfo = TypeInfo.NONE;
        }
    }

    TypedDefRef(final DefRef defRef, final Class<DEF_TYPE> modelDefinitionClass, final Class<CONFIG_TYPE> modelConfigClass, final Class<VALUE_TYPE> valueClass) {
        super(checkNotNull(defRef));

        if (modelDefinitionClass == null) {
            throw new IllegalArgumentException("modelDefinitionClass is null.");
        }
        if (modelConfigClass == null) {
            throw new IllegalArgumentException("modelConfigClass is null.");
        }
        if (valueClass == null) {
            throw new IllegalArgumentException("valueClass is null.");
        }

        this.modelDefinitionClass = modelDefinitionClass;
        this.modelConfigClass = modelConfigClass;
        this.valueClass = valueClass;
        this.typeInfo = TypeInfo.NONE;
    }

    @KeepSecretFromPublishedApi
    public static TypedDefRef<?, ?, ?> createDefRefByDefinitionObj(final MIParamConfMultiplicity definitionObj) {
        checkNotNull(definitionObj);

        @SuppressWarnings("unchecked")
        final Class<? extends MIParamConfMultiplicity> defClass = definitionObj.mdfGetInterfaceClass();
        final Class<? extends MIHasDefinition> instClass;
        final Class<?> valueClass;

        // Params
        if (defClass == MIIntegerParamDef.class) {
            instClass = MINumericalValue.class;
            valueClass = BigInteger.class;
        } else if (defClass == MIFloatParamDef.class) {
            instClass = MINumericalValue.class;
            valueClass = BigDecimal.class;

        } else if (defClass == MIBooleanParamDef.class) {
            instClass = MINumericalValue.class;
            valueClass = Boolean.class;

        } else if (defClass == MIEnumerationParamDef.class) {
            instClass = MITextualValue.class;
            valueClass = String.class;

        } else if (defClass == MIFunctionNameDef.class) {
            instClass = MITextualValue.class;
            valueClass = String.class;

        } else if (defClass == MILinkerSymbolDef.class) {
            instClass = MITextualValue.class;
            valueClass = String.class;

        } else if (defClass == MIEcucMultilineStringParamDef.class) {
            instClass = MITextualValue.class;
            valueClass = String.class;

        } else if (defClass == MIStringParamDef.class) {
            instClass = MITextualValue.class;
            valueClass = String.class;

        } else if (defClass == MIEcucAddInfoParamDef.class) {
            instClass = MIEcucAddInfoParamValue.class;
            valueClass = MIDocumentationBlock.class;
        }
        // Refs
        else if (defClass == MISymbolicNameReferenceParamDef.class) {
            instClass = MIReferenceValue.class;
            valueClass = MIParameterValue.class;

        } else if (defClass == MIChoiceReferenceParamDef.class) {
            instClass = MIReferenceValue.class;
            valueClass = MIContainer.class;

        } else if (defClass == MIReferenceParamDef.class) {
            instClass = MIReferenceValue.class;
            valueClass = MIContainer.class;

        } else if (defClass == MIInstanceReferenceParamDef.class) {
            instClass = MIInstanceReferenceValue.class;
            valueClass = MIReferrable.class;

        } else if (defClass == MIForeignReferenceParamDef.class) {
            instClass = MIReferenceValue.class;
            valueClass = MIReferrable.class;
        }

        // Container || Module

        else if (defClass == MIParamConfContainerDef.class) {
            instClass = MIContainer.class;
            valueClass = Void.class;

        } else if (defClass == MIChoiceContainerDef.class) {
            instClass = MIContainer.class;
            valueClass = Void.class;

        } else if (defClass == MIModuleDef.class) {
            instClass = MIModuleConfiguration.class;
            valueClass = Void.class;

        } else {
            throw new IllegalStateException("Definition class " + defClass.getName() + " missing! Internal error!");
        }

        return createDefRefByDefinitionObj(definitionObj, defClass, instClass, valueClass);

    }

    private static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> createDefRefByDefinitionObj(
            final MIParamConfMultiplicity defObj, final Class<DEF_TYPE> modelDefinitionClass, final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass) {

        if (logger.isTraceEnabled()) {
            trace("createDefRefByDefinitionObj(MIParamConfMultiplicity defObj)", "called with ({0})", defObj);
        }

        if (defObj == null) {
            throw new IllegalArgumentException("defObj is null.");
        }

        final IModelAccess modelAccess = ModelUtil.getModelAccess(defObj);
        final IReferrableAccess refAccess = ModelUtil.getReferrableAccess(defObj);

        final String defRefloc = StringCache.INSTANCE.getUniqueString(refAccess.getAutosarPath(defObj));

        final String packagesPart = StringCache.INSTANCE.getUniqueString(getPackagePartByMDFObject(defObj, modelAccess, refAccess));
        String defRefWithoutPackages = null;
        if (packagesPart != null) {
            // Build DefRef without packages and the corresponding hashCode
            defRefWithoutPackages = StringCache.INSTANCE.getUniqueString(stripLeadingSeperator(defRefloc.substring(packagesPart.length(), defRefloc.length())));
        }

        return new TypedDefRef<>(packagesPart, defRefWithoutPackages, defRefloc, modelDefinitionClass, modelConfigClass, valueClass, null);
    }

    /**
     * @param refAccess
     * @param mdfObj
     */
    private static String getPackagePartByMDFObject(final MIParamConfMultiplicity defObj, final IModelAccess modelAccess, final IReferrableAccess refAccess) {

        final MIModuleDef moduleDefinitionObj = modelAccess.getModuleDefinition(defObj);
        if (moduleDefinitionObj != null) {
            final String moduleDef = refAccess.getAutosarPath(moduleDefinitionObj);
            // Subtract the module and return the packages
            final String packagePart = moduleDef.substring(0, moduleDef.length() - moduleDefinitionObj.getName().length() - 1);

            return packagePart;
        }

        return null;
    }

    /*
     * Public methods
     */

    /**
     * Returns the class object of the configuration elements, which have this definition.
     *
     * @return the class object of the configuration objects
     */
    @PublishedMethod
    public Class<CONFIG_TYPE> getModelConfigurationClass() {
        return modelConfigClass;
    }

    /**
     * Returns the class object of the definition of the configuration elements, which comply to this {@link DefRef}.
     *
     * @return the class object of the definition
     */
    @PublishedMethod
    public Class<DEF_TYPE> getModelDefinitionClass() {
        return modelDefinitionClass;
    }

    /**
     * Returns the class object of the value of the parameter elements, which comply to this {@link DefRef}.
     *
     * <p>
     * If the element has no value (e.g. Container) {@link Void} is returned.
     * </p>
     *
     * @return the class object of the value of the parameters
     */
    @PublishedMethod
    public Class<VALUE_TYPE> getModelValueClass() {
        return valueClass;
    }

    /**
     * Gets the additional type information.
     *
     * @return the additional type information
     */
    @PublishedMethod
    public TypeInfo getAdditionalTypeInformation() {
        return typeInfo;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    public DEF_TYPE getDefinitionObject(final IProjectContext projectContext) {
        final MIParamConfMultiplicity defObj = super.getDefinitionObject(projectContext);
        if (defObj == null) {
            return null;
        }
        return (DEF_TYPE) defObj;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    public List<DEF_TYPE> getPossibleDefinitionsForDefRefWithWildcard(final IProjectContext projectContext) {
        return super.getPossibleDefinitionsForDefRefWithWildcard(projectContext);
    }

    /**
     * Checks if <code>this</code> object is the definition of the passed modelObject and an instance of the modelObjectClass.
     *
     *
     * <p>
     * Note: This method tests also refinements. So, if the modelObject is refined of this definition, it will also yield to true.
     * </p>
     *
     * <p>
     * Note: This method is an implicit null and modelObjectClass class check. This means, if it returns true, the modelObject is an instance of modelObjectClass.
     * </p>
     *
     * <p>
     * The method will return <code>false</code>, if the passed modelObject is removed. The method will return <code>false</code>, if the passed modelObject is invisible.
     * </p>
     *
     * @param modelObject The modelObject to check.
     * @return <code>true</code>, if this is the definition of the modelObject and it is instance of modelObjectClass.
     *
     */
    @PublishedMethod
    @Override
    public boolean isDefinitionOf(final MIObject modelObject) {
        return super.isDefinitionOfInternal(modelObject, modelConfigClass);
    }

    /**
     * <p>
     * DO NOT use this method! Use {@link #isDefinitionOf(MIObject)} instead, because a {@link TypedDefRef} already provides the type information.
     * </p>
     *
     * {@inheritDoc}
     *
     */
    @PublishedMethod
    @Deprecated
    @Override
    public boolean isDefinitionOf(final MIObject modelObject, final Class<? extends MIHasDefinition> classToCheck) {
        return super.isDefinitionOfInternal(modelObject, classToCheck);
    }

    /**
     * <p>
     * DO NOT use this method! Use {@link #asDefinitionOf(MIObject)} instead, because a {@link TypedDefRef} already provides the type information.
     * </p>
     * {@inheritDoc}
     */
    @PublishedMethod
    @Deprecated
    @Override
    public <R extends MIHasDefinition> R asDefinitionOf(final MIObject modelObject, final Class<R> classToCheck) {
        return super.asDefinitionOfInternal(modelObject, classToCheck);
    }

    /**
     * Checks if <code>this</code> object is the definition of the passed modelObject and an instance of modelObjectClass. If the check is true, the method returns the object
     * casted to modelObjectClass. Otherwise the method return <code>null</code>.
     *
     * <p>
     * Note: This method tests also refinements. So, if the modelObject is refined of this definition, it will also yield to true.
     * </p>
     *
     * <p>
     * Note: This method is an implicit null and classToCheck class check. This means, if it returns true, the modelObject is an instance of classToCheck.
     * </p>
     *
     * <p>
     * The method will return <code>false</code>, if the passed modelObject is removed. The method will return <code>false</code>, if the passed modelObject is invisible.
     * </p>
     *
     * @param modelObject The modelObject to check.
     * @return <code>object</code>, if this is the definition of the modelObject and it is instance of modelObjectClass. Otherwise null.
     * @see #isDefinitionOf(MIObject)
     *
     */
    @PublishedMethod
    public CONFIG_TYPE asDefinitionOf(final MIObject modelObject) {
        return super.asDefinitionOfInternal(modelObject, modelConfigClass);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public boolean isModuleDefinitionDefRef() {

        if (getModelDefinitionClass() != MIModuleDef.class) {
            return false;
        }
        if (getModelConfigurationClass() != MIModuleConfiguration.class) {
            return false;
        }

        return super.isModuleDefinitionDefRef();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toDebugString() {

        final StringBuilder builder = new StringBuilder();

        builder.append(super.toString());

        builder.append(" (Definition: ");
        builder.append(modelDefinitionClass.getSimpleName());
        builder.append(" Config: ");
        builder.append(modelConfigClass.getSimpleName());

        if (valueClass != Void.class) {
            builder.append(" Value: ");
            builder.append(valueClass.getSimpleName());
        }

        if (typeInfo != TypeInfo.NONE) {
            builder.append(" ");
            builder.append(typeInfo.toString());
        }
        builder.append(")");

        return builder.toString();
    }

    /**
     * Returns all definitions which match or are refining this {@link TypedDefRef} (respecting {@link IDefRefWildcard}, short name path and {@link #getModelDefinitionClass()})
     * and are not refined by any other loaded definitions.
     *
     * @param projectContext
     * @return List of definitions.
     */
    @PublishedMethod
    public List<DEF_TYPE> getMostSpecificDefinitions(final IProjectContext projectContext) {
        return projectContext.getService(IDefRefDefinitionCache.class).getMostSpecificDefinitions(this);
    }

    /**
     * The Class TypeInfo represents TypeInformation in a TypedDefRef.
     *
     * <p>
     * {@link TypeInfo} provides TypeInformations for the standard use cases.
     * </p>
     */
    @Immutable
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    public static final class TypeInfo {

        private static Interner<TypeInfo> interner = Interners.newStrongInterner();

        /*
         * Predefined fields
         */
        @PublishedField
        public static final TypeInfo NONE = new TypeInfo();

        @PublishedField
        public static final TypeInfo UNUSED_MULTIPLICITY = TypeInfo.of(TypeInfoElement.LOWER_MULTIPLICITY_ZERO, TypeInfoElement.UPPER_MULTIPLICITY_ZERO);

        @PublishedField
        public static final TypeInfo MANDATORY_MULTIPLICITY = TypeInfo.of(TypeInfoElement.LOWER_MULTIPLICITY_ONE, TypeInfoElement.UPPER_MULTIPLICITY_ONE);

        @PublishedField
        public static final TypeInfo ONE_TO_UNLIMITED_MULTIPLICITY = TypeInfo.of(TypeInfoElement.LOWER_MULTIPLICITY_ONE, TypeInfoElement.UPPER_MULTIPLICITY_UNLIMITED);

        @PublishedField
        public static final TypeInfo OPTIONAL_MULTIPLICITY = TypeInfo.of(TypeInfoElement.LOWER_MULTIPLICITY_ZERO, TypeInfoElement.UPPER_MULTIPLICITY_ONE);

        @PublishedField
        public static final TypeInfo ZERO_TO_UNLIMITED_MULTIPLICITY = TypeInfo.of(TypeInfoElement.LOWER_MULTIPLICITY_ZERO, TypeInfoElement.UPPER_MULTIPLICITY_UNLIMITED);

        /*
         * Creator methods
         */

        private static TypeInfo intern(final TypeInfo info) {
            return interner.intern(info);
        }

        @PublishedMethod
        public static <T> TypeInfo of() {

            return NONE;
        }

        @KeepSecretFromPublishedApi
        public static TypeInfo of(final TypeInfo info) {
            return info;
        }

        @PublishedMethod
        public static TypeInfo of(final TypeInfo info, final TypeInfo info2) {

            final ImmutableMap.Builder<ITypeInfoKey<?>, Object> builder = ImmutableMap.builder();
            builder.putAll(info.map);
            builder.putAll(info2.map);
            return intern(new TypeInfo(builder.build()));
        }

        @PublishedMethod
        public static <T> TypeInfo of(final TypeInfo... infos) {
            if (infos == null || infos.length == 0) {
                return NONE;
            }

            final ImmutableMap.Builder<ITypeInfoKey<?>, Object> builder = ImmutableMap.builder();
            for (final TypeInfo elem : infos) {
                builder.putAll(elem.map);
            }
            return intern(new TypeInfo(builder.build()));
        }

        @PublishedMethod
        public static <T> TypeInfo of(final TypeInfo info, final TypeInfoElement<T> elem2) {

            final ImmutableMap.Builder<ITypeInfoKey<?>, Object> builder = ImmutableMap.builder();
            builder.putAll(info.map);
            builder.put(elem2.key, elem2.value);
            return intern(new TypeInfo(builder.build()));
        }

        @PublishedMethod
        public static TypeInfo of(final TypeInfo info, final TypeInfoElement<?> elem2, final TypeInfoElement<?> elem3) {

            final ImmutableMap.Builder<ITypeInfoKey<?>, Object> builder = ImmutableMap.builder();
            builder.putAll(info.map);
            builder.put(elem2.key, elem2.value);
            builder.put(elem3.key, elem3.value);
            return intern(new TypeInfo(builder.build()));
        }

        @PublishedMethod
        public static TypeInfo of(final TypeInfo info, final TypeInfoElement<?>... elems) {

            final ImmutableMap.Builder<ITypeInfoKey<?>, Object> builder = ImmutableMap.builder();
            builder.putAll(info.map);
            for (final TypeInfoElement<?> elem : elems) {
                builder.put(elem.key, elem.value);
            }
            return intern(new TypeInfo(builder.build()));
        }

        @SuppressWarnings({ "rawtypes", "unchecked" })
        @PublishedMethod
        public static <T> TypeInfo of(final TypeInfoElement<T> elem) {

            final ImmutableMap<ITypeInfoKey<T>, T> map = ImmutableMap.of(elem.key, elem.value);
            return intern(new TypeInfo((ImmutableMap) map));
        }

        @PublishedMethod
        public static TypeInfo of(final TypeInfoElement<?> elem1, final TypeInfoElement<?> elem2) {
            checkArgument(!elem1.key.equals(elem2.key), "The same key is not allowed twice!");

            final ImmutableMap<ITypeInfoKey<?>, Object> map = ImmutableMap.of(elem1.key, elem1.value, elem2.key, elem2.value);
            return intern(new TypeInfo(map));
        }

        @PublishedMethod
        public static TypeInfo of(final TypeInfoElement<?> elem1, final TypeInfoElement<?> elem2, final TypeInfoElement<?> elem3) {
            checkArgument(!elem1.key.equals(elem2.key), "The same key is not allowed twice!");
            checkArgument(!elem1.key.equals(elem3.key), "The same key is not allowed twice!");
            checkArgument(!elem2.key.equals(elem3.key), "The same key is not allowed twice!");

            final ImmutableMap<ITypeInfoKey<?>, Object> map = ImmutableMap.of(elem1.key, elem1.value, elem2.key, elem2.value, elem3.key, elem3.value);
            return intern(new TypeInfo(map));
        }

        @PublishedMethod
        public static TypeInfo of(final TypeInfoElement<?>... elems) {
            if (elems == null || elems.length == 0) {
                return NONE;
            }

            final Set<ITypeInfoKey<?>> set = Sets.newHashSet();
            final ImmutableMap.Builder<ITypeInfoKey<?>, Object> builder = ImmutableMap.builder();
            for (final TypeInfoElement<?> elem : elems) {

                if (set.contains(elem.key)) {
                    throw new IllegalArgumentException("The key" + elem.key + " was already assigned. You can't assign a Key twice.");
                }

                builder.put(elem.key, elem.value);
                set.add(elem.key);
            }

            return intern(new TypeInfo(builder.build()));
        }

        /**
         * Gets the the value of the specific ITypeInfoKey, or <code>null</code> if there is no TypeInformation.
         *
         * @param <T> the generic type
         * @param key the key
         * @return the type information
         */
        @SuppressWarnings("unchecked")
        @PublishedMethod
        public <T> T getTypeInfoValue(final ITypeInfoKey<T> key) {

            final Object object = map.get(key);
            if (object == null) {
                return null;
            }

            return (T) object;
        }

        /**
         * Gets the all existing type keys.
         *
         * @return the all existing type keys
         */
        @SuppressWarnings("unchecked")
        @PublishedMethod
        public Collection<ITypeInfoKey<?>> getAllExistingTypeKeys() {
            @SuppressWarnings("rawtypes")
            final Collection set = map.keySet();

            return set;
        }

        /*
         * Private section
         */
        private final ImmutableMap<ITypeInfoKey<?>, Object> map;

        private TypeInfo(final ImmutableMap<ITypeInfoKey<?>, Object> map) {
            this.map = map;
        }

        private TypeInfo() {
            this.map = ImmutableMap.of();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((map == null) ? 0 : map.hashCode());
            return result;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (!(obj instanceof TypeInfo)) {
                return false;
            }
            final TypeInfo other = (TypeInfo) obj;
            if (map == null) {
                if (other.map != null) {
                    return false;
                }
            } else if (!map.equals(other.map)) {
                return false;
            }
            return true;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String toString() {
            final StringBuilder builder = new StringBuilder();
            builder.append("TypeInfo [");
            if (map != null) {
                boolean firstElem = true;
                for (final Entry<ITypeInfoKey<?>, Object> entry : map.entrySet()) {
                    if (!firstElem) {
                        builder.append(", ");
                    }
                    firstElem = false;
                    builder.append("[");

                    String value = null;
                    if (entry.getValue() != null) {
                        value = entry.getValue().toString();
                        if (entry.getKey().equals(TypeInfoKey.UPPER_MULTIPLICITY) && entry.getValue() instanceof BigInteger) {
                            value = ModelUtil.getMultiplicityValueAsString((BigInteger) entry.getValue());
                        }
                    }

                    builder.append(entry.getKey());
                    builder.append(" = ");
                    builder.append(value);
                    builder.append("]");
                }
            }
            if (this == NONE) {
                builder.append("None");
            }
            builder.append("]");
            return builder.toString();
        }

    }

    /**
     * The Class TypeInfoElement represent one {@link ITypeInfoKey} key and <T> value pair.
     *
     * <p>
     * {@link TypeInfoElement} provides some standard key-value pairs.
     * </p>
     *
     * @param <T> the generic type
     */
    @Immutable
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    public static final class TypeInfoElement<T> {

        /*
         * Predefined Elements
         */
        @PublishedField
        public static final TypeInfoElement<BigInteger> LOWER_MULTIPLICITY_ZERO = of(TypeInfoKey.LOWER_MULTIPLICITY, BigInteger.ZERO);

        @PublishedField
        public static final TypeInfoElement<BigInteger> LOWER_MULTIPLICITY_ONE = of(TypeInfoKey.LOWER_MULTIPLICITY, BigInteger.ONE);

        @PublishedField
        public static final TypeInfoElement<BigInteger> LOWER_MULTIPLICITY_UNLIMITED = of(TypeInfoKey.LOWER_MULTIPLICITY, IModelAccess.UNLIMITED_INTEGER);

        @PublishedField
        public static final TypeInfoElement<BigInteger> UPPER_MULTIPLICITY_ZERO = of(TypeInfoKey.UPPER_MULTIPLICITY, BigInteger.ZERO);

        @PublishedField
        public static final TypeInfoElement<BigInteger> UPPER_MULTIPLICITY_ONE = of(TypeInfoKey.UPPER_MULTIPLICITY, BigInteger.ONE);

        @PublishedField
        public static final TypeInfoElement<BigInteger> UPPER_MULTIPLICITY_UNLIMITED = of(TypeInfoKey.UPPER_MULTIPLICITY, IModelAccess.UNLIMITED_INTEGER);

        @PublishedField
        public static final TypeInfoElement<Boolean> SYMBOLIC_NAME_VALUE_TRUE = of(TypeInfoKey.SYMBOLIC_NAME_VALUE, Boolean.TRUE);

        @PublishedField
        public static final TypeInfoElement<Boolean> SYMBOLIC_NAME_VALUE_FALSE = of(TypeInfoKey.SYMBOLIC_NAME_VALUE, Boolean.FALSE);

        /*
         * Creator methods
         */
        @PublishedMethod
        public static <R> TypeInfoElement<R> of(final ITypeInfoKey<R> key, final R value) {
            return new TypeInfoElement<>(key, value);
        }

        /*
         * Private section
         */
        private final ITypeInfoKey<T> key;

        private final T value;

        private TypeInfoElement(final ITypeInfoKey<T> key, final T value) {
            this.key = key;
            this.value = value;

        }

        /**
         * {@inheritDoc}
         */
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((key == null) ? 0 : key.hashCode());
            result = prime * result + ((value == null) ? 0 : value.hashCode());
            return result;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (!(obj instanceof TypeInfoElement)) {
                return false;
            }
            final TypeInfoElement<?> other = (TypeInfoElement<?>) obj;
            if (key == null) {
                if (other.key != null) {
                    return false;
                }
            } else if (!key.equals(other.key)) {
                return false;
            }
            if (value == null) {
                if (other.value != null) {
                    return false;
                }
            } else if (!value.equals(other.value)) {
                return false;
            }
            return true;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String toString() {
            final StringBuilder builder = new StringBuilder();
            builder.append("TypeInfoElement [");
            if (key != null) {
                builder.append(key);
                builder.append(" = ");
            }
            if (value != null) {
                builder.append(value);
            }
            builder.append("]");
            return builder.toString();
        }

    }

    /**
     * The Interface {@link ITypeInfoKey} is the base interface for all TypeInfoKeys used in the {@link TypeInfo}.
     *
     * <p>
     * You can implement your own {@link ITypeInfoKey} to append some specific type informations
     * </p>
     *
     * @param <T> the generic type
     */
    @Immutable
    @PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
    public interface ITypeInfoKey<T> {

    }

    /**
     * The Class {@link TypeInfoKey} provides standard TyperInformations.
     *
     * @param <T> the generic type
     */
    @Immutable
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    public static final class TypeInfoKey<T> implements ITypeInfoKey<T> {

        @PublishedField
        public static final ITypeInfoKey<BigInteger> LOWER_MULTIPLICITY = new TypeInfoKey<>("LowerMultiplicity");

        @PublishedField
        public static final ITypeInfoKey<BigInteger> UPPER_MULTIPLICITY = new TypeInfoKey<>("UpperMultiplicity");

        @PublishedField
        public static final ITypeInfoKey<Boolean> SYMBOLIC_NAME_VALUE = new TypeInfoKey<>("SymbolicNameValue");

        @PublishedField
        public static final ITypeInfoKey<BigInteger> MIN_VALUE_INT = new TypeInfoKey<>("MinValueInt");

        @PublishedField
        public static final ITypeInfoKey<BigInteger> MAX_VALUE_INT = new TypeInfoKey<>("MaxValueInt");

        @PublishedField
        public static final ITypeInfoKey<BigDecimal> MIN_VALUE_FLOAT = new TypeInfoKey<>("MinValueFloat");

        @PublishedField
        public static final ITypeInfoKey<BigDecimal> MAX_VALUE_FLOAT = new TypeInfoKey<>("MaxValueFloat");

        /**
         * {@inheritDoc}
         */
        @Override
        public String toString() {
            return name;
        }

        /*
         * Private section
         */
        private final String name;

        private TypeInfoKey(final String name) {
            this.name = name;

        }

    }

    /*
     * Trace Methods
     */
    private static void trace(final String method, final String pattern, final Object... arguments) {
        logger.trace(method + ": " + MessageFormat.format(pattern, arguments));
    }
}
