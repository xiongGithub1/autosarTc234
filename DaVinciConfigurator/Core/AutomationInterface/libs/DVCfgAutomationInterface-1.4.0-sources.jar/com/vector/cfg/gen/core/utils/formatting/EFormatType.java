package com.vector.cfg.gen.core.utils.formatting;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.formatting.formatter.NoFormatFormatter;
import com.vector.cfg.gen.core.utils.formatting.formatter.TableFormatter;
import com.vector.cfg.gen.core.utils.formatting.formatter.TwoSpacesPerArray;
import com.vector.cfg.gen.core.utils.formatting.formatter.TwoSpacesPerElement;

/**
 * An enumeration of all convenient format type for {@link IGenElement}s.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EFormatType implements IGenFormatProvider {
    /**
     * <code>NO_FORMAT</code> does not actually format the code.
     * <p>
     * Example:
     *
     * <pre>
     * <code>{1,5,0xFF,{4,5,6},1.0}</code>
     * </pre>
     *
     * </p>
     */
    NO_FORMAT,
    /**
     * <code>TWO_SPACES_PER_ELEMENT</code> formats the code with two spaces and a newLine for each element and two extra spaces for each subelement.
     *
     * <p>
     * Example:
     *
     * <pre>
     * <code>{
     *   1,
     *   5,
     *   0xFF,
     *   {
     *     4,
     *     5,
     *     6
     *   },
     *   1.0
     * }
     *
     * </code>
     * </pre>
     *
     * </p>
     *
     */
    TWO_SPACES_PER_ELEMENT,
    /**
     * <code>TWO_SPACES_PER_ARRAY</code> formats the code with two spaces and a newLine for each subelement.
     *
     * <p>
     * Example:
     *
     * <pre>
     * <code>{1, 5, 0xFF,
     *   {4, 5, 6},
     *   1.0 }
     * </code>
     * </pre>
     *
     * </p>
     */
    TWO_SPACES_PER_ARRAY,

    /**
     * <code>TABLE_FORMAT</code> formats a two dimensional array as a table. All "columns" have the same length and will be padded with spaces. A columnHeader
     * can be passed additionally.
     * <p>
     * Example:
     *
     * <pre>
     * <code>{
     *    {@literal  /}*Column1*{@literal  /}   {@literal  /}*Column2*{@literal  /}   {@literal  /}*Column3*{@literal  /}
     *   {0x00000001UL, 0x00000002UL, 0x00000003UL  },
     *   {Test,         0x00000004UL, Test          },
     *   {0x00000005UL, Test,         Test          }
     * }
     * </code>
     * </pre>
     *
     * </p>
     */
    TABLE_FORMAT;

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IGenFormatter getFormatter() {

        switch (this) {
        case NO_FORMAT:
            return new NoFormatFormatter();
        case TWO_SPACES_PER_ELEMENT:
            return new TwoSpacesPerElement();
        case TWO_SPACES_PER_ARRAY:
            return new TwoSpacesPerArray();
        case TABLE_FORMAT:
            return new TableFormatter();
        default:
            throw new IllegalStateException("The format type is unknown");
        }
    }

}