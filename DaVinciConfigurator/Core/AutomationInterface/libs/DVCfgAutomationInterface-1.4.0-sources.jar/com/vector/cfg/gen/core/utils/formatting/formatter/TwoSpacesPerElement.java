package com.vector.cfg.gen.core.utils.formatting.formatter;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.GenConstants;
import com.vector.cfg.gen.core.utils.formatting.EFormatType;
import com.vector.cfg.gen.core.utils.formatting.IListGenElement;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * See {@link EFormatType} for more details.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class TwoSpacesPerElement extends AbstractFormatter {

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(TwoSpacesPerElement.class);

    /**
     * <code>TWO_SPACES</code> defines the spaces from the line start.
     */
    private static final String TWO_SPACES = "  ";

    private final int startIndentationLevel;

    /**
     * Constructor for TwoSpacesPerElement.
     *
     * @param startIndentationLevel
     */

    @PublishedMethod
    public TwoSpacesPerElement(int startIndentationLevel) {
        this.startIndentationLevel = startIndentationLevel;

    }

    /**
     * Instantiates a new two spaces per element.
     */
    @PublishedMethod
    public TwoSpacesPerElement() {
        this(0);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreBlockStart(StringBuilder builder, int indent) {
        for (int x = 0; x < (indent + startIndentationLevel); x++) {
            builder.append(TWO_SPACES);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostBlockStart(StringBuilder builder, int indent) {
        builder.append(GenConstants.LINE_SEPARATOR);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreBlockEnd(StringBuilder builder, int indent) {
        for (int x = 0; x < (indent + startIndentationLevel); x++) {
            builder.append(TWO_SPACES);
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostBlockEnd(StringBuilder builder, int indent) {
        builder.append(GenConstants.LINE_SEPARATOR);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreElement(StringBuilder builder, int indent) {
        for (int x = 0; x < (indent + startIndentationLevel); x++) {
            builder.append(TWO_SPACES);
        }
        // builder.append(" ");
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostElement(StringBuilder builder, int indent) {
        builder.append(GenConstants.LINE_SEPARATOR);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostHeader(StringBuilder builder, int indent, IListGenElement element) {
        builder.append(GenConstants.LINE_SEPARATOR);
    }

}
