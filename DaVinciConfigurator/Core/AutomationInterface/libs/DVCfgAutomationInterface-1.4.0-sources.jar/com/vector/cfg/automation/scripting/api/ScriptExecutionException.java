package com.vector.cfg.automation.scripting.api;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.List;

import org.codehaus.groovy.control.MultipleCompilationErrorsException;
import org.codehaus.groovy.control.messages.SyntaxErrorMessage;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.IScriptExecutionContext;
import com.vector.cfg.automation.scripting.base.IScriptTask;
import com.vector.cfg.automation.scripting.base.ScriptingException;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.exceptions.InterruptedRuntimeException;

import groovy.lang.MissingMethodException;
import groovy.lang.MissingPropertyException;

/**
 * {@link ScriptExecutionException} is the standard type thrown by an {@link IScriptTask} execution. The
 * {@link IScriptTask#call(com.vector.cfg.util.servicecontext.IServiceContext, Object...)} method will throw a subclass of {@link ScriptExecutionException} to indicate failure
 * of the execution.
 *
 * <p>
 * Every thrown exception from the script task client code is wrapped into an instance of {@link ScriptExecutionException}, before handed to the caller.
 * </p>
 *
 * <p>
 * The exception provides information of the:
 * <ul>
 * <li>Where</li>
 * <li>Stackframe</li>
 * <li>What went wrong</li>
 * <li>Which script</li>
 * <li>What script file</li>
 * </ul>
 * </p>
 *
 * <p>
 * A client code should use subtypes of <code>ScriptClientExecutionException</code> to implement own exception types with the same behavior, instead of subclassing the class
 * directly.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @See {@link ScriptingException}
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public class ScriptExecutionException extends ScriptingException implements IDebugable {
    private static final long serialVersionUID = -3650747009786491426L;

    @PublishedMethod
    public ScriptExecutionException(String message, Throwable cause) {
        super(message, cause);

    }

    @PublishedMethod
    public ScriptExecutionException(Throwable cause) {
        super(cause);

    }

    @PublishedMethod
    public ScriptExecutionException(String message) {
        super(message);
    }

    @PublishedMethod
    public ScriptExecutionException(IScriptExecutionContext scriptExecutionContext, String message) {
        super(scriptExecutionContext, message);
    }

    @PublishedMethod
    public ScriptExecutionException(IScriptExecutionContext scriptExecutionContext, String message, Throwable cause) {
        super(scriptExecutionContext, message, cause);

    }

    @PublishedMethod
    @Override
    protected boolean buildWhereFromCompileException(StringBuilder builder) {
        final Throwable cause2 = getCause();
        if (cause2 instanceof MultipleCompilationErrorsException) {
            try {
                final MultipleCompilationErrorsException compErrors = (MultipleCompilationErrorsException) cause2;
                final List<?> errors = compErrors.getErrorCollector().getErrors();
                String fileNames = "";
                for (final Object err : errors) {
                    if (err instanceof SyntaxErrorMessage) {
                        final SyntaxErrorMessage synEx = (SyntaxErrorMessage) err;

                        fileNames += nlStr();

                        fileNames += tabStr();
                        fileNames += Paths.get(new URL(synEx.getCause().getSourceLocator()).toURI()).toAbsolutePath().toString();
                        fileNames += ":";
                        fileNames += synEx.getCause().getLine();
                    }
                }
                if (!fileNames.isEmpty()) {
                    builder.append(nlStr());
                    builder.append(whereStr());
                    builder.append(fileNames);
                    return true;
                }
            } catch (final RuntimeException | MalformedURLException | URISyntaxException ex) {
                // If something goes wrong here ignore the where section
                InterruptedRuntimeException.throwExceptionIfRootCauseWasInterruptedException(ex);
            }
        }
        return false;
    }

    @Override
    @PublishedMethod
    protected boolean isKnownException(Throwable cause) {
        if (super.isKnownException(cause)) {
            return true;
        }
        if (cause instanceof MissingPropertyException) {
            return true;
        }
        if (cause instanceof MissingMethodException) {
            return true;
        }
        if (cause instanceof org.codehaus.groovy.runtime.powerassert.PowerAssertionError) {
            return true;
        }
        return false;
    }

}
