package com.vector.cfg.gen.core.moduleinterface.genservices;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.genservices.exceptions.GenServiceContributionException;
import com.vector.cfg.model.access.DefRef;

/**
 * You can add GenServices to the IGenServiceRegistry. See {@link IGenServiceContributor} for more details.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenServiceRegistry {

    /**
     * Adds a GenService to the passed Generator. The Generator is specified by the passed {@link DefRef} moduleDefRef.
     *
     * <p>
     * The implementation (impl) could be used for more serviceInterfaces (additionalServiceInterfaces). The implementation must implement all specified
     * ServiceInterfaces
     * </p>
     *
     * <p>
     * Attention: All registered Services must be <b>threadsafe</b>, because is it not guaranteed that the services are called from an certain thread!
     * </p>
     *
     * @param <T> the generic type
     * @param moduleDefRef the ModuleDefRef of the Generator
     * @param impl the implementation object of for the Service interfaces.
     * @param serviceInterface the service interface
     * @param additionalServiceInterfaces the additional service interfaces
     * @throws GenServiceContributionException If any GenService could not be registered
     *
     * @exception NullPointerException <ul>
     * <li>if impl is null</li>
     * <li>if moduleDefRef is null</li>
     * <li>if serviceInterface is null</li>
     * </ul>
     * @exception IllegalArgumentException <ul>
     * <li>if moduleDefRef is no moduleDefinition</li>
     * <li>if any serviceInterface is in no interface</li>
     * <li>if the impl is no instance of any passed serviceInterface</li>
     * </ul>
     * @exception GenServiceContributionException <ul>
     * <li>if there is already a Service with the same DefRef and ServiceInterface</li>
     * </ul>
     *
     */
    @PublishedMethod
    <T> void addGenService(DefRef moduleDefRef, T impl, Class<T> serviceInterface, Class<?>... additionalServiceInterfaces) throws GenServiceContributionException;

}
