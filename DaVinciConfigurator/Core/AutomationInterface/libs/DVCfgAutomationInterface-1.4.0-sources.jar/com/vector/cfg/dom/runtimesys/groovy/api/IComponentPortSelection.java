package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.connection.IConnector;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IComponentPortSelection"><!--Label:IComponentPortSelection-->{@link IComponentPortSelection} represents a selection of {@link IComponentPort}s and the
 * possible operations on these component ports.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IComponentPortSelection {

    /**
     * <div class="extdoc" id="autoMapTo"><!--Label:IComponentPortSelection.autoMapTo-->{@link #autoMapTo(Closure)} tries to auto-map the selection of component ports according
     * the component connection assistant rules but offers more control for the auto-mapping: Inside the closure additional predicates for narrowing down the target component
     * ports can be defined and code to evaluate and change the auto-mapper results can be provided.
     * <p>
     * Narrowing down the target component ports may be useful to gain better matches for the auto-mapper: In case several target component ports match equally, no auto-mapping
     * is performed. So reducing the target component ports my improve the results of the auto-mapping.
     * </p>
     * <p>
     * The component port selection will produce trace, info and warning logs. To see them, activate the
     * '{@link com.vector.cfg.dom.runtimesys.groovy.api.IComponentPortSelection}' logger with the appropriate log level.
     * </p>
     * </div>
     *
     * @param code The code to provide target predicates or evaluate the matches.
     * @return A list of created connectors (mappings).
     */
    @PublishedMethod
    <T extends IConnector> List<T> autoMapTo(@Nonnull @VDelegatesToWithClosureParam(IComponentPortAutoMapper.class) Closure<?> code);

    /**
     * <div class="extdoc" id="autoMap"><!--Label:IComponentPortSelection.autoMap-->{@link #autoMap()} tries to auto-map the selection of component ports according the component
     * connection assistant default rules.</div>
     *
     * @return A list of created connectors (mappings).
     */
    @PublishedMethod
    <T extends IConnector> List<T> autoMap();

    /**
     * Allows access to the single component ports in the {@link IComponentPortSelection}.
     *
     * @return The collection of selected component ports.
     */
    @PublishedMethod
    <T extends IComponentPort> Collection<T> getComponentPorts();

}
