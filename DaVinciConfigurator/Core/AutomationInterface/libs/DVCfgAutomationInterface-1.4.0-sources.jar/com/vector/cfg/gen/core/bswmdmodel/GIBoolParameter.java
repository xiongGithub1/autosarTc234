package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasIllegalValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasNoValueException;
import com.vector.cfg.gen.core.utils.formatting.primitives.BoolGenElement;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucBooleanDefinition;

/**
 * Base interface of boolean bswmd model parameter.
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIBoolParameter extends GIParameter<Boolean> {
    // CHECKSTYLE:ON

    /**
     * Returns the parameters value as {@link Boolean}.
     *
     * @return The value object
     *
     * @exception BswmdModelParameterHasNoValueException
     * <ul>
     * <li>if the value of the parameter is null</li>
     * </ul>
     * @exception BswmdModelParameterHasIllegalValueException
     * <ul>
     * <li>if the value of the parameter is illegal</li>
     * </ul>
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    Boolean getValue();

    /**
     * Returns the parameters value, or the parameter defaultValue, if the parameter does not exist or has no value.
     *
     * <p>
     * <code>null</code> as defaultValue is permitted!
     * </p>
     *
     * @param defaultValue the defaultValue, when the parameter does not contain a value.
     * @return The value object, or the defaultValue.
     */
    @PublishedMethod
    Boolean getValueOrDefault(Boolean defaultValue);

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    BoolGenElement formatValue();

    /**
     * Convenience method to set the value of the {@link GIBoolParameter}.
     *
     * See {@link GIParameter#setValueMdf(Boolean)} for more details.
     *
     * @param newValue
     */
    @PublishedMethod
    void setValue(boolean newValue);

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucBooleanDefinition getEcucDefinition();

}
