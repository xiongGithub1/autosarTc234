package com.vector.cfg.automation.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.automation.scripting.api.IScriptCreationApi;

/**
 * {@link IScriptCreationApiWithFields} collects the {@link IScriptTaskTypeApi} and the {@link IScriptCreationApi} to one common interface. This interface is active, when a
 * script is loaded.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptCreationApiWithFields extends IScriptCreationApi, IScriptTaskTypeApi {

}
