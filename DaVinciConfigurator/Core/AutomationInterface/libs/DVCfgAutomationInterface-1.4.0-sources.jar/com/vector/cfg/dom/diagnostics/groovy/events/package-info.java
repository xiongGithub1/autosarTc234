/**
 * The diagnostics domain events API is specifically designed to support diagnostic event related use cases.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.dom.diagnostics.groovy.events;