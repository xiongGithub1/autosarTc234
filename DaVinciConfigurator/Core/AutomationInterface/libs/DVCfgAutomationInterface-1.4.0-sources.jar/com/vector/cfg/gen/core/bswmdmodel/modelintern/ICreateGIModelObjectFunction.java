package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIHasContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 * A functional interface for {@link GIModelObject} object creation. A instance of this interface is created by a lambda expression.
 * <p>
 * e.g.:
 * <p>
 * Container: <code>
 * (defRef, cfgElement, modelAccess, parent) -> TestContainer.create(modelAccess, (MIContainer) cfgElement);
 * </code>
 * </p>
 * <p>
 * Parameter: <code>
 * (defRef, cfgElement, modelAccess, parent) -> GeneratorModelParameterFactory.createInteger(defRef, (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, true);
 * </code>
 * </p>
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@FunctionalInterface
public interface ICreateGIModelObjectFunction<VALUE extends GIModelObject> {

    @PublishedMethod
    VALUE create(DefRef defRef, MIHasDefinition cfgElement, IInternalGeneratorModelAccess modelAccess, GIHasContainer parent);
}
