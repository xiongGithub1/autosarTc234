package com.vector.cfg.gen.core.bswmdmodel.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;

import groovy.lang.MissingPropertyException;

/**
 * T{@link IBswmdModelDefRefsApi} provides methods to retrieve generated {@link DefRef} instances from the SIP without knowing the correct java/groovy imports.
 *
 * <div class="extdoc" id="Common"> The <code>sipDefRef</code> API provides access to retrieve generated {@link DefRef} instances from the SIP without knowing the correct
 * Java/Groovy imports. This is mainly useful in script files, where no IDE helps with the imports.
 *
 * <p>
 * <b>If you are using an Automation Script Project you can ignore this API</b> and use the {@link DefRef}s provided by the generated classes, which is superior to this API,
 * because they are typesafe and compile time checked. <!--LaTeX: See \vref{sec:BswmdModelDefRefs} for details.-->
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswmdModelDefRefsApi {

    /**
     * Returns the {@link DefRef} by the passed shortName.
     *
     * <p>
     * If the shortName contains a '/' the method tries to retrieve the DefRef by the full AUTOSAR definition path.
     * </p>
     *
     * <p>
     * If the shortName does not contain any '/' the method tries to find the definition with the passed short name. The name must be unique in the whole SIP.
     * </p>
     *
     * @param defRefString the definition string or the short name of the definition
     * @return the {@link DefRef}
     * @exception MissingPropertyException
     * <ul>
     * <li>If the shortName is not unique in the SIP. Then please try to specify the full definition path.</li>
     * <li>If the shortName was not found in the SIP.</li>
     * </ul>
     */
    @PublishedMethod
    DefRef getDefRef(String defRefString);

    /**
     * Returns the {@link DefRef} by the passed shortName.
     *
     * <p>
     * If the shortName contains a '/' the method tries to retrieve the DefRef by the full AUTOSAR definition path.
     * </p>
     *
     * <p>
     * If the shortName does not contain any '/' the method tries to find the definition with the passed short name. The name must be unique in the whole SIP.
     * </p>
     *
     * @param defRefString the definition string or the short name of the definition
     * @return the {@link DefRef}
     * @exception MissingPropertyException
     * <ul>
     * <li>If the shortName is not unique in the SIP. Then please try to specify the full definition path.</li>
     * <li>If the shortName was not found in the SIP.</li>
     * </ul>
     */
    @PublishedMethod
    Object getProperty(String defRefString);

    /**
     * Returns the {@link DefRef} by the passed defRefString.
     *
     * <p>
     * If the defRefString contains a '/' the method tries to retrieve the DefRef by the full AUTOSAR definition path.
     * </p>
     *
     * <p>
     * If the shortName does not contain any '/' the method tries to find the definition with the passed short name. The name must be unique in the whole SIP.
     * </p>
     *
     * @param defRefString the definition string or the short name of the definition
     * @return the {@link DefRef}
     * @exception MissingPropertyException
     * <ul>
     * <li>If the shortName is not unique in the SIP. Then please try to specify the full definition path.</li>
     * <li>If the shortName was not found in the SIP.</li>
     * </ul>
     */
    @PublishedMethod
    DefRef getAt(String defRefString);
}
