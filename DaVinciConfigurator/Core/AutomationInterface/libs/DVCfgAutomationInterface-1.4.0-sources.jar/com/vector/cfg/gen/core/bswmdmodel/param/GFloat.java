package com.vector.cfg.gen.core.bswmdmodel.param;

import java.math.BigDecimal;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIFloatParameter;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.BswmdModelInternalElementFactory;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractParam;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.gen.core.utils.formatting.primitives.FloatGenElement;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucFloatDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucFloatParameter;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.varianthandling.attributevaluevariationpoints.MINumericalValueVariationPoint;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFloatParamDef;

/**
 * Float parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GFloat extends GAbstractParam<BigDecimal> implements GIFloatParameter {

    private BigDecimal value;

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public GFloat(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MINumericalValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MINumericalValue getMdfObject() {
        return (MINumericalValue) super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MINumericalValue getMdfObjectUnsafe() {
        return (MINumericalValue) super.getMdfObjectUnsafe();
    }

    private MINumericalValueVariationPoint getValueVariationPoint() {
        try {
            switchView();

            if (getMdfObject() != null) {
                return getMdfObject().getValue();
            }
            return null;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Double getValue() {
        try {
            switchView();

            final BigDecimal valueLoc = getBigDecimalValue();
            getModelVerifier().assertFloatParameterValueInJavaDoubleRange(this, valueLoc);

            return valueLoc.doubleValue();

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Double getValueOrDefault(Double defaultValue) {
        if (hasValue()) {
            return getValue();
        }

        return defaultValue;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @ReworkThisAtNextBreakingChange("Remove method - implemented in base type")
    public boolean hasValue() {
        return super.hasValue();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public BigDecimal getValueMdf() {
        return getBigDecimalValue();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public BigDecimal getBigDecimalValue() {
        if (isValueChecked()) {
            return value;
        }
        try {
            switchView();

            getModelVerifier().assertParameterValueNotNull(this, getValueVariationPoint());
            getModelVerifier().assertParameterHasLegalValue(this, "Float");

            final MINumericalValue mdfParam = getMdfObject();
            value = getGeneratorModelAccess().getMdfModelAccess().getAsFloat(mdfParam);

            setValueChecked();
            return value;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public FloatGenElement formatValue() {
        return F.formatFloat(this);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(BigDecimal valueOf) {

        BswmdModelInternalElementFactory.setValueMdf(this, () -> getGeneratorModelAccess().getMdfModelAccess().setAsFloat(getMdfObject(), valueOf));
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(double valueLoc) {

        BswmdModelInternalElementFactory.setValueMdf(this, () -> getGeneratorModelAccess().getMdfModelAccess().setAsFloat(getMdfObject(), valueLoc));
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValue(double newValue) {
        this.setValueMdf(newValue);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIFloatParamDef getDefinition() {
        return (MIFloatParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucFloatDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucFloatParameter getEcuConfiguration() {

        final IEcucParameter cfg = super.getEcuConfiguration();
        return (IEcucFloatParameter) cfg;
    }

}
