package com.vector.cfg.automation.scripting.api.project;

import java.nio.file.Path;

import com.google.inject.ConfigurationException;
import com.google.inject.ProvisionException;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.ScriptExecutionException;
import com.vector.cfg.util.IDisposable;
import com.vector.cfg.util.scripting.dynamic.DynamicTarget;
import com.vector.cfg.util.scripting.dynamic.IDynamicObjectAware;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.util.servicecontext.IServiceContext;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="Common"> Projects in the AutomationInterface are represented by {@link IProject} instances. These instances can be created by:
 * <ul>
 * <li>Creating a new project</li>
 * <li>Loading an existing project</li>
 * </ul>
 * <p>
 * You can only access {@link IProject} instances by using a {@link Closure} block at <code>IProjectHandlingApi</code> or {@link IProjectRef} class. This shall prevent memory
 * leaks, by not closing open projects.
 * </p>
 * </div>
 *
 * <p>
 * All methods will throw an {@link IllegalStateException}, if the {@link IProject} was already disposed (closed). You can not call any methods, when the project was closed.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IProjectRef
 */
@DynamicTarget({
        "com.vector.cfg.model.groovy.api.IModelApiEntryPoint",
        "com.vector.cfg.persistency.groovy.api.IPersistencyApiEntryPoint",
        "com.vector.cfg.gen.core.bswmdmodel.groovy.api.IBswmdModelApiEntryPoint",
        "com.vector.cfg.model.groovy.api.ITransactionApiEntryPoint",
        "com.vector.cfg.model.groovy.api.IVarianceApiEntryPoint",
        "com.vector.cfg.consistency.groovy.api.IValidationApiEntryPoint",
        "com.vector.cfg.gen.core.genusage.groovy.api.IGenerationApiEntryPoint",
        "com.vector.cfg.automation.api.domain.IDomainApiEntryPoint",

})
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IProject extends IDynamicObjectAware, AutoCloseable, IDisposable {

    /**
     * Returns the {@link Path} to the Dpa file of this Project as absolute path.
     *
     * @return the project path to the Dpa file
     */
    @PublishedMethod
    Path getDpaProjectFilePath();

    /**
     * Return the project name.
     *
     * @return the project name
     */
    @PublishedMethod
    String getProjectName();

    /**
     * Returns the requested service instance by the passed {@link Class}.
     *
     * @param <T> the type of the instance to retrieve
     * @param type the class of the requested instance.
     * @return service instance
     * @throws IllegalArgumentException - if the argument is <code>null</code>
     * @throws ConfigurationException if this {@link IServiceContext} cannot find or create the provider.
     * @throws ProvisionException if there was a runtime failure while providing an instance.
     */
    @PublishedMethod
    <T> T getInstance(Class<T> instanceClass);

    /**
     * Saves this {@link IProject}.
     *
     * <div class="extdoc" id="saveProject"><!--Label:IProject.saveProject-->{@link IProject#saveProject()} saves the current state including all model changes of the project to
     * disc.
     *
     * </div>
     * 
     * @exception ScriptExecutionException if save failed.
     */
    @PublishedMethod
    void saveProject();

    /**
     * Return this {@link IProject} instance of the active project.
     *
     * @return the project
     */
    @PublishedMethod
    IProject getProject();

    /**
     * Activates this instance as the current active Project inside of the {@link Closure}. See <code>IProjectHandlingApi</code> for details.
     *
     * @param <T> the return type of the closure
     * @param code the code
     * @return the returned value of the closure
     */
    @PublishedMethod
    <T> T with(@VDelegatesToWithClosureParam(IProject.class) Closure<T> code);

    /**
     * Closes this {@link IProject}. After this call any other call to the {@link IProject} will throw an {@link IllegalStateException}. It is not required to close the project,
     * because it is automatically closed, when the project scope is left.
     */
    @Override
    @PublishedMethod
    void close();
}
