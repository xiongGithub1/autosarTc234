package com.vector.cfg.core.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class InvalidSipLicenseException extends RuntimeException {

    /**
     * <code>serialVersionUID</code> describes.
     */
    private static final long serialVersionUID = 6906907630440716111L;

    /**
     * Constructor.
     *
     * @param buildMessage
     */
    @PublishedMethod
    public InvalidSipLicenseException(final String message) {
        super(message);
    }

}
