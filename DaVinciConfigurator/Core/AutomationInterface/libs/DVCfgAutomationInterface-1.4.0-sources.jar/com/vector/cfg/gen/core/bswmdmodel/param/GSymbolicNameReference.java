package com.vector.cfg.gen.core.bswmdmodel.param;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.gen.core.bswmdmodel.GISymbolicNameReference;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.gen.core.utils.formatting.primitives.StringGenElement;
import com.vector.cfg.gen.core.utils.templateutils.SymbolicNameUtil;
import com.vector.cfg.gen.core.utils.templateutils.SymbolicNameUtil.Version;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucSymbolicNameRefDefinition;
import com.vector.cfg.model.access.ecuconfiguration.reference.IEcucSimpleReferenceParameter;
import com.vector.cfg.model.access.ecuconfiguration.reference.IEcucSymbolicNameReferenceParameter;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MISymbolicNameReferenceParamDef;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * SymbolicNameReference parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GSymbolicNameReference extends GReference implements GISymbolicNameReference {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GSymbolicNameReference.class);

    private MIParameterValue targetParameter = null;

    /**
     * Constructor.
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GSymbolicNameReference(DefRef defRef, MIReferenceValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, boolean onlyOneElement) {
        super(defRef, parameter, modelAccess, parent, onlyOneElement);

    }

    /**
     * Instantiates a new g symbolic name reference.
     *
     * @param defRef the DefRef
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     */
    @PublishedMethod
    public GSymbolicNameReference(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MIReferenceValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);

    }

    @Override
    @PublishedMethod
    protected void initRef() {
        super.initRef();
        final MIReferenceValue mdfObjLoc = getMdfObject();
        if (mdfObjLoc != null) {
            final MIReferrable ref = getTargetUnsafe();
            if (ref != null) {
                if (ref instanceof MIContainer) {
                    targetParameter = getGeneratorModelAccess().getMdfModelAccess().getSymbolicNameParameter((MIContainer) ref);
                }
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIReferenceValue getMdfObject() {
        return super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public boolean hasRefTargetParameter() {
        if (!hasRefTarget()) {
            return false;
        }
        return targetParameter != null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MIParameterValue getRefTargetParameterMdf() {
        try {
            switchView();

            // Delegate to getTarget to test the existence of the Reference
            getRefTargetMdf();
            getModelVerifier().assertReferenceTargetParameterNotNull(this, targetParameter);
            return targetParameter;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    public <T> GIParameter<T> getRefTargetParameter() {
        return getGeneratorModelAccess().getFactory().getInstance(GIParameter.class, getRefTargetParameterMdf());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MISymbolicNameReferenceParamDef getDefinition() {
        return (MISymbolicNameReferenceParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucSymbolicNameRefDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucSymbolicNameReferenceParameter getEcuConfiguration() {

        final IEcucSimpleReferenceParameter cfg = super.getEcuConfiguration();
        return (IEcucSymbolicNameReferenceParameter) cfg;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public StringGenElement getRefTargetAsSymbolicName() {

        try {
            switchView();
            final StringGenElement genElement = SymbolicNameUtil.generateSymName(getMdfObject(), Version.AR4);
            return genElement;
        } finally {
            restoreView();
        }
    }

}
