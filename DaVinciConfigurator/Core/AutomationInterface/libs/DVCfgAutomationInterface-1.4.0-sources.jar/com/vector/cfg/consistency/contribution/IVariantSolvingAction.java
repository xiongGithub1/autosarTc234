package com.vector.cfg.consistency.contribution;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.view.config.IModelView;

/**
 * A {@link IVariantSolvingAction} has to ensure, that the internal implementation of this {@link ISolvingAction} switches to the correct {@link IModelView}
 * during {@link #run()} on it's own!
 *
 * <p>
 * Attention: So every implementation must switch to the correct {@link IModelView} internally!
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IVariantSolvingAction extends ISolvingAction {

}
