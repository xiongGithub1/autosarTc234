package com.vector.cfg.automation.api.project;

import java.nio.file.Path;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.ScriptConverters;
import com.vector.cfg.business.Constraints;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link ICreateProjectApi} provides means for parameterizing the creation of a new project.
 *
 * <div class="extdoc" id="ICreateProjectApi"><!--Label:ICreateProjectApi-->The {@link ICreateProjectApi} contains the methods to parameterize the creation of a new project.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface ICreateProjectApi {

    /**
     * See {@link EEcucFileStructure#SINGLE_FILE}.
     */
    @PublishedField
    EEcucFileStructure SINGLE_FILE = EEcucFileStructure.SINGLE_FILE;

    /**
     * See {@link EEcucFileStructure#ONE_FILE_PER_MODULE}.
     */
    @PublishedField
    EEcucFileStructure ONE_FILE_PER_MODULE = EEcucFileStructure.ONE_FILE_PER_MODULE;

    /**
     * See {@link EEcucFileStructure#ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE}.
     */
    @PublishedField
    EEcucFileStructure ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE = EEcucFileStructure.ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE;

    /**
     * See {@link ESelectiveImport#ALL}.
     */
    @PublishedField
    ESelectiveImport ALL = ESelectiveImport.ALL;

    /**
     * See {@link ESelectiveImport#COMMUNICATION_ONLY}.
     */
    @PublishedField
    ESelectiveImport COMMUNICATION_ONLY = ESelectiveImport.COMMUNICATION_ONLY;

    /**
     * Alias for {@link #setProjectName(String)}.
     */
    @PublishedMethod
    void projectName(@Nonnull String projectName);

    /**
     * Sets the name for the newly created project.
     *
     * <div class="extdoc" id="setProjectName"><!--Label:ICreateProjectApi.setProjectName-->
     * <h5>Project Name</h5> Specify the name newly created project with {@link #setProjectName(String)}. The name given here is postfixed with ".dpa" for the new project's .dpa
     * file.
     *
     * <p>
     * The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_VALID_PROJECT_NAME} <!--Ref:Constraints.IS_VALID_PROJECT_NAME--></li>
     * </ul>
     * </p>
     * </div>
     *
     * @param projectName the name of the new project
     */
    @PublishedMethod
    void setProjectName(@Nonnull String projectName);

    /**
     * Alias for {@link #setProjectFolder(Object)}.
     */
    @PublishedMethod
    void projectFolder(@Nonnull Object projectFolder);

    /**
     * Sets the folder in which to create the new project.
     *
     * <div class="extdoc" id="setProjectFolder"><!--Label:ICreateProjectApi.setProjectFolder-->
     * <h5>Project Folder</h5> Specify the folder in which to create the new project in with {@link #setProjectFolder(Object)}. The value given here is converted to {@link Path}
     * using the converter {@link ScriptConverters#TO_SCRIPT_PATH} <!--Ref:ScriptConverters.TO_SCRIPT_PATH-->.
     *
     * <p>
     * The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </p>
     * </div>
     *
     * @param projectFolder the folder in which to create the new project
     */
    @PublishedMethod
    void setProjectFolder(@Nonnull Object projectFolder);

    /**
     * Use {@link #getGeneral()} to specify the new project's general settings.
     *
     *
     * <div class="extdoc" id="getGeneral"><!--Label:ICreateProjectApi.getGeneral-->Use {@link #getGeneral()} or {@link #general(Closure)} to specify the new project's general
     * settings. The provided settings are defined in {@link ICreateProjectGeneralApi}.
     *
     * </div>
     */
    @PublishedMethod
    ICreateProjectGeneralApi getGeneral();

    /**
     * Use {@link #general(Closure)} to specify the new project's general settings with a {@link Closure}.
     *
     *
     * @param code code providing the general settings for the new project
     * @sse {@link #getGeneral()}
     */
    @PublishedMethod
    void general(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectGeneralApi.class) Closure<?> code);

    /**
     * Use {@link #getTarget()} to specify the new project's target settings.
     *
     * <div class="extdoc" id="getTarget"><!--Label:ICreateProjectApi.getTarget-->Use {@link #getTarget()} or {@link #target(Closure)} to specify the new project's target
     * settings for compiler, derivatives and pin layouts.</div>
     */
    @PublishedMethod
    ICreateProjectTargetApi getTarget();

    /**
     * Use {@link #target(Closure)} to specify the new project's target settings in a scope-like way.
     *
     * @param code code providing the target settings for the new project
     * @see #getTarget()
     */
    @PublishedMethod
    void target(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectTargetApi.class) Closure<?> code);

    /**
     * Use {@link #getPostBuild()} to specify the new project's post build settings.
     *
     * <div class="extdoc" id="getPostBuild"><!--Label:ICreateProjectApi.getPostBuild-->Use {@link #getPostBuild()} or {@link #postBuild(Closure)} to specify the new project's
     * post build settings for Post-build selectable and or loadable projects.</div>
     */
    @PublishedMethod
    ICreateProjectPostBuildApi getPostBuild();

    /**
     * Use {@link #postBuild(Closure)} to specify the new project's post build settings in a scope-like way.
     *
     *
     * @param code code providing the target settings for the new project
     * @see ICreateProjectApi#getPostBuild()
     */
    @PublishedMethod
    void postBuild(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectPostBuildApi.class) Closure<?> code);

    /**
     * Use {@link #folders(Closure)} to specify the new project's folders settings.
     *
     * <div class="extdoc" id="getFolders"><!--Label:ICreateProjectApi.getFolders-->Use {@link #getFolders()} or {@link #folders(Closure)} to specify the new project's folders
     * settings.</div>
     */
    @PublishedMethod
    ICreateProjectFolderApi getFolders();

    /**
     * Use {@link #folders(Closure)} to specify the new project's folders settings in a scope-like way.
     *
     * @param code code providing the folders settings for the new project
     * @see #getFolders()
     */
    @PublishedMethod
    void folders(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectFolderApi.class) Closure<?> code);

    /**
     * Use {@link #daVinciDeveloper(Closure)} to specify the new project's DaVinci Developer settings.
     *
     * <div class="extdoc" id="getDaVinciDeveloper"><!--Label:ICreateProjectApi.getDaVinciDeveloper-->Use {@link #getDaVinciDeveloper()} to specify the new project's DaVinci
     * Developer settings. </div>
     */
    @PublishedMethod
    ICreateProjectDaVinciDeveloperApi getDaVinciDeveloper();

    /**
     * Use {@link #daVinciDeveloper(Closure)} to specify the new project's DaVinci Developer settings in a scope-like way.
     *
     * @param code code providing the DaVinci Developer settings for the new project
     * @see #getDaVinciDeveloper()
     */
    @PublishedMethod
    void daVinciDeveloper(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectDaVinciDeveloperApi.class) Closure<?> code);

    /**
     * Use {@link #virtualTargetApi(Closure)} to specify the new project's vVIRTUALtarget settings.
     *
     * <div class="extdoc" id="getVirtualTarget"><!--Label:ICreateProjectApi.getVirtualTarget-->Use {@link #getVirtualTarget()} to specify the new project's vVIRTUALtarget
     * settings. The vVIRTUALtarget support may not be available depending on the purchased license. </div>
     */
    @PublishedMethod
    ICreateProjectVirtualTargetApi getVirtualTarget();

    /**
     * Use {@link #virtualTargetApi(Closure)} to specify the new project's vVIRTUALtarget settings in a scope-like way.
     *
     * @param code code providing the vVIRTUALtarget settings for the new project
     * @see #getVirtualTarget()
     */
    @PublishedMethod
    void virtualTarget(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectVirtualTargetApi.class) Closure<?> code);

}
