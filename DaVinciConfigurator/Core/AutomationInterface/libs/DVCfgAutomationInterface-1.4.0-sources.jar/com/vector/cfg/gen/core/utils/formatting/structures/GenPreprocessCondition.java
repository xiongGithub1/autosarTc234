package com.vector.cfg.gen.core.utils.formatting.structures;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.GenConstants;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.formatter.TwoSpacesPerArray;
import com.vector.cfg.gen.core.utils.formatting.formatter.TwoSpacesPerElement;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractGenElement;

/**
 * <div class="extdoc" id="GenPreprocessCondition"><h3>Preprocessor conditionals</h3><!--LaTeX:\label{sec:GenPreprocessCondition}--> To generate preprocessor
 * conditionals the class {@link GenPreprocessCondition} can be used. This format element can also be used inside of structures like GenArrays.
 * <p>
 * The following conditionals are available:
 * <ul>
 * <li><code>#if</code></li>
 * <li><code>#ifdef</code></li>
 * <li><code>#ifndef</code></li>
 * <li><code>#else</code></li>
 * <li><code>#elif</code></li>
 * <li><code>#endif</code></li>
 * </ul>
 * </p>
 *
 * <p>
 * For each conditional a own <code>create</code> method is available (e.g. <code>createIf(String expression)</code>).
 * </p>
 *
 * <b>Example:</b>
 *
 * <pre>
 * <code class="Java" id="Create and generate a if conditional">
 * final GenPreprocessCondition preProcessIf = GenPreprocessCondition.createIf("expression");
 *
 * String output = preProcessIf.generate();
 * </code>
 * </pre>
 *
 * <!--LaTeX:For more details and options see \vref{cha:QuickReferences_Pdf}. --> </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenPreprocessCondition extends AbstractGenElement<GenPreprocessCondition> {

    private final String directive;

    private final String expression;

    /**
     * Instantiates a new gen preprocessor condition.
     *
     * @param directive the directive
     * @param expression the expression
     */
    private GenPreprocessCondition(String directive, String expression) {
        super();
        this.directive = directive;
        this.expression = expression;
    }

    /**
     * Creates a #if instruction.
     *
     * <p>
     * If the last character of expression is "\" (a backslash), the backslash is stripped.
     * </p>
     *
     * @param expression the expression
     * @throws IllegalArgumentException if expression is null
     * @return the gen preprocess condition
     */
    @PublishedMethod
    public static GenPreprocessCondition createIf(String expression) {
        return createInternal(GenConstants.C_IF, expression);
    }

    /**
     * Creates a #ifdef instruction.
     *
     * @param expression the expression
     * @throws IllegalArgumentException if expression is null
     * @return the gen preprocess condition
     */
    @PublishedMethod
    public static GenPreprocessCondition createIfdef(String expression) {
        return createInternal(GenConstants.C_IFDEF, expression);
    }

    /**
     * Creates a #ifndef instruction.
     *
     * <p>
     * If the last character of expression is "\" (a backslash), the backslash is stripped.
     * </p>
     *
     * @param expression the expression
     * @throws IllegalArgumentException if expression is null
     * @return the gen preprocess condition
     */
    @PublishedMethod
    public static GenPreprocessCondition createIfndef(String expression) {
        return createInternal(GenConstants.C_IFNDEF, expression);
    }

    /**
     * Creates a #elif instruction.
     *
     * <p>
     * If the last character of expression is "\" (a backslash), the backslash is stripped.
     * </p>
     *
     * @param expression the expression
     * @throws IllegalArgumentException if expression is null
     * @return the gen preprocess condition
     */
    @PublishedMethod
    public static GenPreprocessCondition createElif(String expression) {
        return createInternal(GenConstants.C_ELIF, expression);
    }

    /**
     * Creates a #else instruction.
     *
     * @return the gen preprocess condition
     */
    @PublishedMethod
    public static GenPreprocessCondition createElse() {
        return createInternal(GenConstants.C_ELSE, "");
    }

    /**
     * Creates a #endif instruction.
     *
     * @return the gen preprocess condition
     */
    @PublishedMethod
    public static GenPreprocessCondition createEndif() {
        return createInternal(GenConstants.C_ENDIF, "");
    }

    private static GenPreprocessCondition createInternal(String directive, String expression) {

        if (expression == null) {
            throw new IllegalArgumentException("expression is null");
        }

        return new GenPreprocessCondition(directive, stripLastBackslash(expression));
    }

    private static String stripLastBackslash(String expression) {

        if (expression.endsWith("\\")) {
            expression = stripLastBackslash(expression.substring(0, expression.length() - 1));
        }

        return expression;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public GenPreprocessCondition prefixComment(String commentParam) {

        throw new UnsupportedOperationException("A Preprocessor condition does not support prefix comments.");
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void generateInternal(StringBuilder builder, IGenFormatter formatter, int indent, boolean isRootElement) {

        if (formatter instanceof TwoSpacesPerElement) {
            formatter.formatPreBlockStart(builder, indent);
        } else if (formatter instanceof TwoSpacesPerArray) {
            formatter.formatPreBlockStart(builder, 0);
        } else {
            builder.append(GenConstants.LINE_SEPARATOR);
        }

        builder.append(this.directive);

        if (expression.length() > 0) {
            builder.append(" ");
            builder.append(this.expression);
        }

        if (this.getPostfixComment() != null) {
            generatePostfixComment(builder);
        }

        builder.append(GenConstants.LINE_SEPARATOR);
    }
}
