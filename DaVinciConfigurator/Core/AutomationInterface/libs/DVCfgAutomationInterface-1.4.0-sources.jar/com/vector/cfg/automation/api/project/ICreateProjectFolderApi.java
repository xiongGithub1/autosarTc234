package com.vector.cfg.automation.api.project;

import java.nio.file.Path;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.ScriptConverters;
import com.vector.cfg.business.Constraints;

/**
 * {@link ICreateProjectFolderApi} provides means for specifying the new project's folders settings.
 *
 * <div class="extdoc" id="ICreateProjectFolderApi"><!--Label:ICreateProjectFolderApi-->{@link ICreateProjectFolderApi} contains the methods to specify the new project's folders
 * settings.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface ICreateProjectFolderApi {

    /**
     * Alias for {@link #setEcucFileStructure(EEcucFileStructure)}.
     *
     * @param ecucFileStructure the ecuc file structure
     */
    @PublishedMethod
    void ecucFileStructure(@Nonnull EEcucFileStructure ecucFileStructure);

    /**
     * Sets the ECUC file structure for the new project.
     *
     * <div class="extdoc" id="setEcucFileStructure"><!--Label:ICreateProjectFolderApi.setEcucFileStructure-->Set the ECUC file structure to use for the new project with the
     * method {@link #setEcucFileStructure(EEcucFileStructure)}. This is an optional parameter defaulting to {@link EEcucFileStructure#SINGLE_FILE} if the parameter is not
     * provided explicitly.
     *
     * </div>
     *
     * @param ecucFileStructure the ECUC file structure for the new project
     */
    @PublishedMethod
    void setEcucFileStructure(@Nonnull EEcucFileStructure ecucFileStructure);

    /**
     * Alias for {@link #setModuleFilesFolder(Object)}.
     *
     * @param moduleFilesFolder the module files folder
     */
    @PublishedMethod
    void moduleFilesFolder(@Nonnull Object moduleFilesFolder);

    /**
     * Sets the module files folder for the new project.
     *
     * <div class="extdoc" id="setModuleFilesFolder"><!--Label:ICreateProjectFolderApi.setModuleFilesFolder-->
     * <h5>Module Files Folder</h5> Set the module files folder for the new project with {@link #setModuleFilesFolder(Object)}. This is an optional parameter defaulting to
     * ".\Appl\GenData" if the parameter is not provided explicitly. The value given here is converted to {@link Path} using {@link ScriptConverters#TO_PATH}
     * <!--Ref:ScriptConverters.TO_PATH-->. Normally a relative path (to be interpreted relative to the project folder) should be given here.
     *
     * <p>
     * The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </p>
     * </div>
     *
     * @param moduleFilesFolder the module files folder for the new project
     */
    @PublishedMethod
    void setModuleFilesFolder(@Nonnull Object moduleFilesFolder);

    /**
     * Alias for {@link #setTemplatesFolder(Object)}.
     *
     * @param templatesFolder the templates folder
     */
    @PublishedMethod
    void templatesFolder(@Nonnull Object templatesFolder);

    /**
     * Sets the templates folder for the new project.
     *
     * <div class="extdoc" id="setTemplatesFolder"><!--Label:ICreateProjectFolderApi.setTemplatesFolder-->
     * <h5>Templates Folder</h5> Set the templates folder for the new project with {@link #setTemplatesFolder(Object)}. This is an optional parameter defaulting to
     * ".\Appl\Source" if the parameter is not provided explicitly.
     * <p>
     * The value given here is converted to {@link Path} using {@link ScriptConverters#TO_PATH} <!--Ref:ScriptConverters.TO_PATH-->. Normally a relative path (to be interpreted
     * relative to the project folder) should be given here.
     * </p>
     *
     * <p>
     * The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </p>
     * </div>
     *
     * @param templatesFolder the templates folder for the new project
     */
    @PublishedMethod
    void setTemplatesFolder(@Nonnull Object templatesFolder);

    /**
     * Alias for {@link #setServiceComponentFilesFolder(Object)}.
     *
     * @param serviceComponentFilesFolder the service component files folder
     */
    @PublishedMethod
    void serviceComponentFilesFolder(@Nonnull Object serviceComponentFilesFolder);

    /**
     * Sets the service component files folder for the new project.
     *
     * <div class="extdoc" id="setServiceComponentFilesFolder"><!--Label:ICreateProjectFolderApi.setServiceComponentFilesFolder-->
     * <h5>Service Components Folder</h5> Set the service component files folder for the new project with {@link #setServiceComponentFilesFolder(Object)}. This is an optional
     * parameter defaulting to ".\Config\ServiceComponents" if the parameter is not provided explicitly.
     * <p>
     * The value given here is converted to {@link Path} using {@link ScriptConverters#TO_PATH} <!--Ref:ScriptConverters.TO_PATH-->. Normally a relative path (to be interpreted
     * relative to the project folder) should be given here.
     * </p>
     * <p>
     * The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </p>
     * </div>
     *
     * @param serviceComponentFilesFolder the service component files folder for the new project
     */
    @PublishedMethod
    void setServiceComponentFilesFolder(@Nonnull Object serviceComponentFilesFolder);

    /**
     * Alias for {@link #setApplicationComponentFilesFolder(Object)}.
     *
     * @param applicationComponentFilesFolder the application component files folder
     */
    @PublishedMethod
    void applicationComponentFilesFolder(@Nonnull Object applicationComponentFilesFolder);

    /**
     * Sets the application component files folder for the new project.
     *
     * <div class="extdoc" id="setApplicationComponentFilesFolder"><!--Label:ICreateProjectFolderApi.setApplicationComponentFilesFolder-->
     * <h5>Application Components Folder</h5> Set the application component files folder for the new project with {@link #setApplicationComponentFilesFolder(Object)}. This is an
     * optional parameter defaulting to ".\Config\ApplicationComponents" if the parameter is not provided explicitly.
     * <p>
     * The value given here is converted to {@link Path} using {@link ScriptConverters#TO_PATH} <!--Ref:ScriptConverters.TO_PATH-->. Normally a relative path (to be interpreted
     * relative to the project folder) should be given here.
     * </p>
     * <p>
     * The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </p>
     * </div>
     *
     * @param applicationComponentFilesFolder the application component files folder for the new project
     */
    @PublishedMethod
    void setApplicationComponentFilesFolder(@Nonnull Object applicationComponentFilesFolder);

    /**
     * Alias for {@link #setLogFilesFolder(Object)}.
     *
     * @param logFilesFolder the log files folder
     */
    @PublishedMethod
    void logFilesFolder(@Nonnull Object logFilesFolder);

    /**
     * Sets the log files folder for the new project.
     *
     * <div class="extdoc" id="setLogFilesFolder"><!--Label:ICreateProjectFolderApi.setLogFilesFolder-->
     * <h5>Log Files Folder</h5> Set the log files folder for the new project with {@link #setLogFilesFolder(Object)}. This is an optional parameter defaulting to ".\Config\Log"
     * if the parameter is not provided explicitly.
     * <p>
     * The value given here is converted to {@link Path} using {@link ScriptConverters#TO_PATH} <!--Ref:ScriptConverters.TO_PATH-->. Normally a relative path (to be interpreted
     * relative to the project folder) should be given here.
     * </p>
     * <p>
     * The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </p>
     * </div>
     *
     * @param logFilesFolder the log files folder for the new project
     */
    @PublishedMethod
    void setLogFilesFolder(@Nonnull Object logFilesFolder);

    /**
     * Alias for {@link #setMeasurementAndCalibrationFilesFolder(Object)}.
     */
    @PublishedMethod
    void measurementAndCalibrationFilesFolder(@Nonnull Object measurementAndCalibrationFilesFolder);

    /**
     * Sets the measurement and calibration files folder for the new project.
     *
     * <div class="extdoc" id="setMeasurementAndCalibrationFilesFolder"><!--Label:ICreateProjectFolderApi.setMeasurementAndCalibrationFilesFolder-->
     * <h5>Measurement And Calibration Files Folder</h5>Set the measurement and calibration files folder for the new project with
     * {@link #setMeasurementAndCalibrationFilesFolder(Object)}. This is an optional parameter defaulting to ".\Config\McData" if the parameter is not provided explicitly.
     * <p>
     * The folder object passed to the method is converted to {@link Path} using {@link ScriptConverters#TO_PATH} <!--Ref:ScriptConverters.TO_PATH-->. Normally a relative path
     * (to be interpreted relative to the project folder) should be given here.
     * </p>
     * <p>
     * The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </p>
     * </div>
     *
     * @param measurementAndCalibrationFilesFolder the measurement and calibration files folder for the new project
     */
    @PublishedMethod
    void setMeasurementAndCalibrationFilesFolder(@Nonnull Object measurementAndCalibrationFilesFolder);

    /**
     * Alias for {@link #setAutosarFilesFolder(Object)}.
     */
    @PublishedMethod
    void autosarFilesFolder(@Nonnull Object autosarFilesFolder);

    /**
     * Sets the AUTOSAR files folder for the new project.
     *
     * <div class="extdoc" id="setAutosarFilesFolder"><!--Label:ICreateProjectFolderApi.setAutosarFilesFolder-->
     * <h5>AUTOSAR Files Folder</h5>Set the AUTOSAR files folder for the new project with {@link #setAutosarFilesFolder(Object)}. This is an optional parameter defaulting to
     * ".\Config\AUTOSAR" if the parameter is not provided explicitly.
     * <p>
     * The value given here is converted to {@link Path} using {@link ScriptConverters#TO_PATH} <!--Ref:ScriptConverters.TO_PATH-->. Normally a relative path (to be interpreted
     * relative to the project folder) should be given here.
     * </p>
     * <p>
     * The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </p>
     * </div>
     *
     * @param autosarFilesFolder the AUTOSAR files folder for the new project
     */
    @PublishedMethod
    void setAutosarFilesFolder(@Nonnull Object autosarFilesFolder);

}
