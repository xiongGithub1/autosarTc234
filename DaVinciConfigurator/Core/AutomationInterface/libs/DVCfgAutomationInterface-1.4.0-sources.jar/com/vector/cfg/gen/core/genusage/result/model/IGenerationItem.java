package com.vector.cfg.gen.core.genusage.result.model;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.EGenerationPhaseType;

/**
 * This interface represents an generator or an external generation step.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGenerationItem extends IGenModelElement {

    /**
     * Returns the name of the generator.<br/>
     * In detail: Uses the MSN in case of a "requiresModuleDefinition generator" else the GeneratorName from IGeneratorPackage.getGeneratorName().<br/>
     *
     * @return the name
     */
    @PublishedMethod
    String getName();

    /**
     * Gets the current state.
     *
     * @return the current state
     */
    @PublishedMethod
    ECurrentState getCurrentState();

    /**
     * Gets the phase.
     *
     * @param phaseType the phase type
     * @return the phase
     */
    @PublishedMethod
    IPhase getPhase(EGenerationPhaseType phaseType);

    /**
     * Gets the phases.
     *
     * @return the phases
     */
    @PublishedMethod
    Collection<IPhase> getPhases();

    /**
     * Gets the error message.
     *
     * @return the error message
     */
    @PublishedMethod
    String getErrorMessage();
}
