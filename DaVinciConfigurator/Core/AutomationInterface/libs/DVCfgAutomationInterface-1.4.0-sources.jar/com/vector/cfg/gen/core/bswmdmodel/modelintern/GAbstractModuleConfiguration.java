package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIConfigVariantInfo;
import com.vector.cfg.gen.core.bswmdmodel.GIHasContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModuleConfiguration;
import com.vector.cfg.gen.core.utils.templateutils.TemplateUtil;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucModuleDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;
import com.vector.cfg.model.state.IModuleConfigurationStatePublished;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.version.IVersion;

/**
 * The abstract base class for bswmd model module configurations.
 *
 * <p>
 * Attention: Please use {@link GIModuleConfiguration} interface in client code.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@NotThreadSafe
public abstract class GAbstractModuleConfiguration extends GAbstractHasContainer implements GIModuleConfiguration {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GAbstractModuleConfiguration.class);

    private GIConfigVariantInfo variantInfo;

    /** Reference to the related definition object in the MDF model. */
    private final MIModuleDef mdfDefinition;

    /** Reference to the related configuration object in the MDF model. */
    private final MIModuleConfiguration mdfObject;

    /**
     * Constructor for GAbstractModuleConfiguration.
     *
     * @param generatorModelAccess the generator model access
     * @param configuration the configuration
     * @param defToCheck the def to check
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GAbstractModuleConfiguration(IInternalGeneratorModelAccess generatorModelAccess, MIModuleConfiguration configuration, DefRef defToCheck) {
        super(generatorModelAccess, configuration);
        this.mdfObject = configuration;
        this.mdfDefinition = ModelUtil.getDefinition(configuration);

        generatorModelAccess.getModelVerifier().assertMdfConfigElementHasCorrectDefinition(configuration, mdfDefinition, defToCheck);
    }

    /**
     * Constructor for GAbstractModuleConfiguration.
     *
     * @param generatorModelAccess the generator model access
     * @param configuration the configuration
     * @param defToCheck the def to check
     */
    @PublishedMethod
    protected GAbstractModuleConfiguration(IInternalGeneratorModelAccess generatorModelAccess, DefRef defRef, MIModuleConfiguration configuration) {
        super(generatorModelAccess, defRef, configuration);
        this.mdfObject = configuration;
        this.mdfDefinition = ModelUtil.getDefinition(configuration);

        generatorModelAccess.getModelVerifier().assertMdfConfigElementHasCorrectDefinition(configuration, mdfDefinition, defRef);
    }

    @PublishedMethod
    @Override
    protected GIHasContainer getParentInternal() {
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public GIConfigVariantInfo getConfigVariantInfo() {

        if (variantInfo == null) {
            try {
                switchView();

                variantInfo = new GVariantInfo(this);
            } finally {
                restoreView();
            }
        }

        return variantInfo;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void invalidateCache() {
        super.invalidateCache();
        variantInfo = null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IModuleConfigurationStatePublished getCeState() {
        return (IModuleConfigurationStatePublished) super.getCeState();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IVersion getBswImplementationArVersion() {

        try {
            switchView();

            final IVersion version = ModelUtil.getArVersionOfBswImplementation(getMdfObject());
            getModelVerifier().assertArVersionOfBswImplementationIsDefined(this, version);

            return version;
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IVersion getArDefinitionSchemaVersion() {
        try {
            switchView();

            final IVersion version = ModelUtil.getSchemaVersionOfMDFObject(getDefinition());
            getModelVerifier().assertArSchemaVersionOfDefinitionIsDefined(this, version);

            return version;
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IVersion getBswImplementationSwVersion() {
        try {
            switchView();

            final IVersion version = ModelUtil.getSwVersionOfBswImplementation(getMdfObject());
            getModelVerifier().assertSwVersionOfBswImplementationIsDefined(this, version);

            return version;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getModuleNameWithAPIInfix() {
        try {
            switchView();

            return TemplateUtil.getModuleNameWithAPIInfix(this);

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIModuleDef getDefinition() {
        return mdfDefinition;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIModuleConfiguration getMdfObject() {
        return mdfObject;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucModuleDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucModuleConfiguration getEcuConfiguration() {

        return getGeneratorModelAccess().getEcuConfigurationAccess().cfg(getMdfObject());
    }

}
