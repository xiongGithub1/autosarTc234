package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import java.util.Collection;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIExceptionCreator;
import com.vector.cfg.gen.core.bswmdmodel.GIHasContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIReference;
import com.vector.cfg.gen.core.bswmdmodel.GIReferenceToContainer;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IReferenceAccess;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucContainerDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucContainer;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.operations.IModelOperations;
import com.vector.cfg.model.state.IContainerStatePublished;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * The abstract base class for bswmd model containers.
 *
 * <p>
 * Attention: Please use {@link GIContainer} interface in client code.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class GAbstractContainer extends GAbstractHasContainer implements GIContainer {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GAbstractContainer.class);

    private final MIContainerDef mdfDefinition;

    private final MIContainer mdfConfig;

    /**
     * Constructor for GAbstractContainer.
     *
     * @param generatorModelAccess the generator model access
     * @param containerCfg the container cfg
     * @param defToCheck the def to check
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GAbstractContainer(IInternalGeneratorModelAccess generatorModelAccess, MIContainer containerCfg, DefRef defToCheck) {
        super(generatorModelAccess, containerCfg);
        this.mdfConfig = containerCfg;
        mdfDefinition = ModelUtil.getDefinition(containerCfg);

        generatorModelAccess.getModelVerifier().assertMdfConfigElementHasCorrectDefinition(containerCfg, mdfDefinition, defToCheck);
    }

    /**
     * Constructor for GAbstractContainer.
     *
     * @param generatorModelAccess the generator model access
     * @param containerCfg the container cfg
     * @param defToCheck the def to check
     */
    @PublishedMethod
    protected GAbstractContainer(IInternalGeneratorModelAccess generatorModelAccess, DefRef defRef, MIContainer containerCfg) {
        super(generatorModelAccess, defRef, containerCfg);
        this.mdfConfig = containerCfg;
        mdfDefinition = ModelUtil.getDefinition(containerCfg);
        generatorModelAccess.getModelVerifier().assertMdfConfigElementHasCorrectDefinition(containerCfg, mdfDefinition, defRef);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIContainerDef getDefinition() {
        return mdfDefinition;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIContainer getMdfObject() {
        return mdfConfig;
    }

    private GIExceptionCreator getExCreator() {
        return getGenModelAccessInternal().getExceptionCreator();
    }

    @PublishedMethod
    @Override
    protected GIHasContainer getParentInternal() {
        return getParent();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IContainerStatePublished getCeState() {
        return (IContainerStatePublished) super.getCeState();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean existsParameter(String defName) {
        return existsParameter(DefRef.create(this.getDefRef(), defName));
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean existsReference(String defName) {
        return existsReference(DefRef.create(this.getDefRef(), defName));

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IEcucContainerDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IEcucContainer getEcuConfiguration() {

        return getGeneratorModelAccess().getEcuConfigurationAccess().cfg(getMdfObject());
    }

    /**
     * Clones the container with all children.<br>
     */
    @PublishedMethod
    protected MIObject duplicateInternal() {

        final IModelOperations modelOperations = BswmdModelInternalElementFactory.getModelOperations(this);

        return modelOperations.deepCloneMDFObject(this.getMdfObject(), this.getParent().getMdfObject());
    }

    /*
     * ----------------------------------------------------------------------------------------------------------------------------
     * getParameter() section
     * ----------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public GIParameter<?> getParameter(DefRef defRef) {
        try {
            switchView();

            final List<GIParameter<?>> parameters = getParameters(defRef);
            getModelVerifier().assertParameterIsExactyOneElement(this, parameters, defRef);

            return parameters.get(0);
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE> GIParameter<VALUE> getParameter(TypedDefRef<DEF, CFG, VALUE> defRef) {
        try {
            switchView();

            final List<GIParameter<VALUE>> parameters = getParameters(defRef);
            getModelVerifier().assertParameterIsExactyOneElement(this, parameters, defRef);

            return parameters.get(0);
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE, WRAPPER extends GIParameter<VALUE>>WRAPPER getParameter(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef) {

        final GIParameter<VALUE> parameter = getParameter((TypedDefRef<DEF, CFG, VALUE>) defRef);

        verifyWrapperClass(defRef, parameter);

        final WRAPPER paramWrapper = defRef.getModelWrapperClass().cast(parameter);
        return paramWrapper;
    }

    /*
     * ----------------------------------------------------------------------------------------------------------------------------
     * getParameters() section
     * ----------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<GIParameter<?>> getParameters() {
        try {
            switchView();

            final List<GIParameter<?>> refList = Lists.newArrayList();
            final IInternalGeneratorModelAccess modelAccess = getGenModelAccessInternal();
            for (final MIParameterValue mdfParam : getMdfObject().getParameter()) {

                if (mdfParam instanceof MINumericalValue || mdfParam instanceof MITextualValue) {
                    final GIParameter<?> ref = (GIParameter<?>) modelAccess.getGenModelObjectByMDFObject(mdfParam);
                    refList.add(ref);
                }
                /*
                 * Other elements like Reference parameters are ignored in this method, because we have no DefRef to filter the request.
                 */

            }
            return refList;
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<GIParameter<?>> getParameters(String defName) {
        return getParameters(DefRef.create(this.getDefRef(), defName));
    }

    /*
     * ----------------------------------------------------------------------------------------------------------------------------
     * getReference() section
     * ----------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public GIReference<?> getReference(DefRef defRef) {
        try {
            switchView();

            final List<GIReference<?>> references = getReferences(defRef);
            getModelVerifier().assertReferenceIsExactyOneElement(this, references, defRef);

            return references.get(0);

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE extends MIReferrable> GIReference<VALUE> getReference(TypedDefRef<DEF, CFG, VALUE> defRef) {
        try {
            switchView();

            final List<GIReference<VALUE>> references = getReferences(defRef);
            getModelVerifier().assertReferenceIsExactyOneElement(this, references, defRef);

            return references.get(0);

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE extends MIReferrable, WRAPPER extends GIReference<?>>WRAPPER getReference(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef) {

        try {
            switchView();

            final GIReference<?> ref = getReference((TypedDefRef<DEF, CFG, VALUE>) defRef);

            verifyWrapperClass(defRef, ref);

            final WRAPPER bswmdRef = defRef.getModelWrapperClass().cast(ref);
            return bswmdRef;
        } finally {
            restoreView();
        }

    }

    /*
     * ----------------------------------------------------------------------------------------------------------------------------
     * getReferenceToContainer() section
     * ----------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE extends MIContainer> GIReferenceToContainer getReferenceToContainer(
            TypedDefRef<DEF, CFG, VALUE> defRef) {

        final GIReference<VALUE> reference = getReference(defRef);
        return (GIReferenceToContainer) reference;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE extends MIContainer, WRAPPER extends GIReferenceToContainer> WRAPPER getReferenceToContainer(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef) {

        try {
            switchView();

            final GIReference<?> ref = getReference(defRef);

            verifyWrapperClass(defRef, ref);

            final WRAPPER bswmdRef = defRef.getModelWrapperClass().cast(ref);

            return bswmdRef;
        } finally {
            restoreView();
        }

    }

    /*
     * ----------------------------------------------------------------------------------------------------------------------------
     * getReferences() section
     * ----------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<GIReference<?>> getReferences() {
        try {
            switchView();

            final List<GIReference<?>> refList = Lists.newArrayList();
            final IInternalGeneratorModelAccess modelAccess = getGenModelAccessInternal();
            for (final MIParameterValue mdfParam : getMdfObject().getParameter()) {

                if (mdfParam instanceof MIReferenceValue || mdfParam instanceof MIInstanceReferenceValue) {
                    final GIReference<?> ref = (GIReference<?>) modelAccess.getGenModelObjectByMDFObject(mdfParam);
                    refList.add(ref);
                }
                /*
                 * Other elements like Textual parameters are ignored in this method, because we have no DefRef to filter the request.
                 */

            }
            return refList;
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final List<GIReference<?>> getReferences(String defName) {
        return getReferences(DefRef.create(this.getDefRef(), defName));

    }

    /*
     * ----------------------------------------------------------------------------------------------------------------------------
     * getReferencesPointingToMe() section
     * ----------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public List<GIReferenceToContainer> getReferencesPointingToMe() {
        try {
            switchView();

            final List<GIReferenceToContainer> bswmdRefList = Lists.newArrayList();
            final Collection<MIReferenceValue> refs = getRefAccess()
                    .getReferenceParametersPointingTo(getMdfObject());
            final IInternalGeneratorModelAccess modelAccess = getGenModelAccessInternal();
            for (final MIReferenceValue mdfRef : refs) {
                final GIReferenceToContainer bswmdRef = (GIReferenceToContainer) modelAccess.getGenModelObjectByMDFObject(mdfRef);
                bswmdRefList.add(bswmdRef);
            }
            return bswmdRefList;
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<GIReferenceToContainer> getReferencesPointingToMe(DefRef definitionOfReferenceParameter) {
        try {
            switchView();

            final List<GIReferenceToContainer> bswmdRefList = Lists.newArrayList();
            final List<MIReferenceValue> refs = getRefAccess().getReferenceParametersPointingTo(getMdfObject(), definitionOfReferenceParameter);
            final IInternalGeneratorModelAccess modelAccess = getGenModelAccessInternal();
            for (final MIReferenceValue mdfRef : refs) {
                if (definitionOfReferenceParameter.isDefinitionOf(mdfRef)) {
                    final GIReferenceToContainer bswmdRef = (GIReferenceToContainer) modelAccess.getGenModelObjectByMDFObject(mdfRef, definitionOfReferenceParameter);
                    bswmdRefList.add(bswmdRef);
                } else {
                    throw getExCreator().issueInvalidRequestExceptionWithText(this,
                            MixedText.format("The element '{0}' pointing to '{1}' does not conform the requested definition {2}.", mdfRef, this, definitionOfReferenceParameter),
                            ImmutableList.of(mdfRef));
                }
            }
            return bswmdRefList;
        } finally {
            restoreView();
        }
    }

    private IReferenceAccess getRefAccess() {
        return getGenModelAccessInternal().getProjectContext().getService(IReferenceAccess.class);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE, WRAPPER, T extends WRAPPER> List<T> getReferencesPointingToMe(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef) {
        try {
            switchView();

            final TypedDefRef<DEF, CFG, VALUE> defCasted = defRef;
            final List<GIReferenceToContainer> refs = getReferencesPointingToMe(defCasted);

            verifyWrapperClassWithList(defRef, refs);

            @SuppressWarnings("unchecked")
            final List<T> wrapList = (List<T>) refs;

            return wrapList;
        } finally {
            restoreView();
        }
    }

}
