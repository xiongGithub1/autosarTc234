package com.vector.cfg.dom.com.groovy.can;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * Via {@link IOptimizeAcceptanceFiltersApi} the automatic Can acceptance filter optimization can be parameterized.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IOptimizeAcceptanceFiltersApi {

    /**
     * Alias for {@link #setFullCan(boolean)}.
     *
     * @param fullCan
     * @return this {@link IOptimizeAcceptanceFiltersApi} instance (for chaining API calls)
     */
    @PublishedMethod
    IOptimizeAcceptanceFiltersApi fullCan(boolean fullCan);

    /**
     * Using {@link #setFullCan(boolean)} it can be specified whether the optimization shall take full can objects into account or
     * not.<div class="extdoc" id="setFullCan"><!--Label:IOptimizeAcceptanceFiltersApi.setFullCan-->Using {@link #setFullCan(boolean)} it can be specified whether the
     * optimization shall take full can objects into account or not.</div>
     *
     * @return this {@link ICanFilterMask}'s filter type
     */
    @PublishedMethod
    void setFullCan(boolean fullCan);

}
