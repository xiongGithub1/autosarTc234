package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.Optional;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.dom.runtimesys.api.assistant.connection.ITargetComponentPort;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * <div class="extdoc" id="IComponentPortAutoMapper"><!--Label:IComponentPortAutoMapper-->{@link IComponentPortAutoMapper} provides an Api to control and evaluate the
 * auto-mapping. </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IComponentPortAutoMapper {

    /**
     * <div class="extdoc" id="selectTargetPorts"><!--Label:IComponentPortAutoMapper.selectTargetPorts-->{@link #selectTargetPorts(Closure)} allows to define predicates to
     * narrow down the target ports for the auto-mapping. The predicates are used to filter the possible target component ports which were computed from the source component
     * port selection.</div>
     *
     * @param code The code to define predicates.
     */
    @PublishedMethod
    void selectTargetPorts(@Nonnull @VDelegatesToWithClosureParam(ITargetComponentPortSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="evaluateMatches"><!--Label:IComponentPortAutoMapper.evaluateMatches-->{@link #evaluateMatches(Closure)} allows to evaluate and change the results
     * of the auto-mapping. It corresponds to the confirm page of the component connection assistant.
     * <p>
     * For each source component port the provided closure is called: Parameters are the source component port, the optional matched target component port (or null), and a list
     * of all potential target component ports (respecting the {@link #selectTargetPorts(Closure)} predicates). The return value must be a list of target component ports.
     * </p>
     * </div>
     *
     * @param code The code to evaluate the matches of the auto-mapping.
     */
    @PublishedMethod
    void evaluateMatches(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.dom.runtimesys.api.assistant.connection.ISourceComponentPort,com.vector.cfg.dom.runtimesys.api.assistant.connection.ITargetComponentPort,java.util.List<com.vector.cfg.dom.runtimesys.api.assistant.connection.ITargetComponentPort>") @Nonnull Closure<List<ITargetComponentPort>> code);

    /**
     * <div class="extdoc" id="forceConnectionWhen1To1"><!--Label:IComponentPortAutoMapper.forceConnectionWhen1To1-->{@link #forceConnectionWhen1To1()} allows to force a mapping
     * even the usual auto-mapping rules will not match. Precondition is that the collections of source component ports and target component ports only contain one component
     * port each. Otherwise no mapping is done. </div>
     */
    @PublishedMethod
    void forceConnectionWhen1To1();

    @KeepSecretFromPublishedApi
    boolean isForceConnectionWhen1to1();

    @KeepSecretFromPublishedApi
    Optional<Closure<List<ITargetComponentPort>>> getEvaluateMatchesCode();

    @KeepSecretFromPublishedApi
    Optional<Closure<?>> getSelectTargetPortsCode();

}
