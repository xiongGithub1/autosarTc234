package com.vector.cfg.dom.runtimesys.api.assistant.connection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;

/**
 * {@link ISourceComponentPort}) is a specialization of {@link IComponentPort} and contains specific methods regarding the source of a connection.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISourceComponentPort extends IComponentPort {

}
