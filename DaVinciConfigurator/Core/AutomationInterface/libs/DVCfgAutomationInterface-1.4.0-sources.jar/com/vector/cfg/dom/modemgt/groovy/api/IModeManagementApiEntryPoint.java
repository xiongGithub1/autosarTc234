package com.vector.cfg.dom.modemgt.groovy.api;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IModeManagementApiEntryPoint} is the entry point for accessing the mode management domain interfaces.
 * <div class="extdoc" id="IModeManagementApiEntryPoint"><!--Label:IModeManagementApiEntryPoint-->The mode management domain API is specifically designed to support mode
 * management related use cases. It is available from the {@code IDomainApi} <!--Ref:IDomainApi--> in the form of the {@link IModeManagementApi} interface.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IModeManagementApiEntryPoint {

    /**
     * {@link #getModeManagement()} allows accessing the {@link IModeManagementApi} like a property.
     * <div class="extdoc" id="getModeManagement"><!--Label:IModeManagementApiEntryPoint.getModeManagement-->{@link #getModeManagement()} allows accessing the
     * {@link IModeManagementApi} like a property.</div>
     *
     * @return the {@link IModeManagementApi}
     */
    @PublishedMethod
    IModeManagementApi getModeManagement();

    /**
     * {@link #modeManagement(Closure)} allows accessing the {@link IModeManagementApi} in a scope-like way.
     * <div class="extdoc" id="modeManagement"><!--Label:IModeManagementApiEntryPoint.modeManagement-->{@link #modeManagement(Closure)} allows accessing the
     * {@link IModeManagementApi} in a scope-like way.</div>
     *
     * @param code the code (a {@link Closure}) working with the {@link IModeManagementApi}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T modeManagement(@Nonnull @VDelegatesToWithClosureParam(IModeManagementApi.class) Closure<T> code);

}
