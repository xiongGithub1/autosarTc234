package com.vector.cfg.model.access.ecucdefinition.elements;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationClass;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationVariant;
import com.vector.cfg.model.state.IParameterStatePublished;

/**
 * <div class="extdoc" id="Common"> <b>{@link IEcucCommonAttributes}</b> is the base interface of all parameter and reference definition wrappers. It provides the following
 * method(s): </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucCommonAttributes extends IEcucDefinition {

    /**
     * <div class="extdoc" id="getMultiplicityConfigurationClass"> The {@link #getMultiplicityConfigurationClass(EEcucConfigurationVariant)} method returns the multiplicity
     * configuration class for the specified module implementation variant. The returned value defines in which configuration phase the number of parameter instances latest may
     * change if the module implements the specified variant.
     * <p>
     * Supported values for the variant are
     * <ul>
     * <li>{@link EEcucConfigurationVariant#VARIANT_PRE_COMPILE}</li>
     * <li>{@link EEcucConfigurationVariant#VARIANT_LINK_TIME}</li>
     * <li>{@link EEcucConfigurationVariant#VARIANT_POST_BUILD_LOADABLE}</li>
     * </ul>
     * Other values lead to an {@link IllegalArgumentException}.
     * </p>
     * <p>
     * This method doesn't take the multiplicity into account. It only investigates the multiplicity configuration class as specified in the related parameter definition. So it
     * still may return {@link EEcucConfigurationClass#POST_BUILD} even if the multiplicity is 1:1 for example. The post-build loadable use case differs here from post-build
     * selectable (see {@link #supportsVariantMultiplicity()}) because the changeability in the post-build phase is being inherited from parent objects. So, if you want to find
     * out if a parameter actually permits changes in the post-build phase, you should use {@link IParameterStatePublished}.
     * </p>
     * <p>
     * This method is for post-build loadable only!
     * </p>
     * <p>
     * <b>Remark about AUTOSAR versions:</b> Prior to AUTOSAR 4.2.1 the parameter definitions contain the <code>implementationConfigClass</code> table to define post-build
     * loadable support. This method internally investigates the <code>implementationConfigClass</code> in this case but the <code>multiplicityConfigClass</code> table for
     * AUROSAR 4.2.1 and newer versions.
     * </p>
     * </div>
     *
     * @param variant
     * @return
     * @throws IllegalArgumentException if the variant argument has not one of the permitted values specified above
     */
    @PublishedMethod
    EEcucConfigurationClass getMultiplicityConfigurationClass(EEcucConfigurationVariant variant);

    /**
     * <div class="extdoc" id="getValueConfigurationClass"> The {@link #getValueConfigurationClass(EEcucConfigurationVariant)} method returns the value configuration class for
     * the specified module implementation variant. The returned value defines in which configuration phase the value of parameter instances latest may change if the module
     * implements the specified variant.
     * <p>
     * Supported values for the variant are
     * <ul>
     * <li>{@link EEcucConfigurationVariant#VARIANT_PRE_COMPILE}</li>
     * <li>{@link EEcucConfigurationVariant#VARIANT_LINK_TIME}</li>
     * <li>{@link EEcucConfigurationVariant#VARIANT_POST_BUILD_LOADABLE}</li>
     * </ul>
     * Other values lead to an {@link IllegalArgumentException}.
     * </p>
     * <p>
     * This method never returns {@link EEcucConfigurationClass#LINK}.
     * </p>
     * <p>
     * This method is for post-build loadable only!
     * </p>
     * <p>
     * <b>Remark about AUTOSAR versions:</b> Prior to AUTOSAR 4.2.1 the parameter definitions contain the <code>implementationConfigClass</code> table to define post-build
     * loadable support. This method internally investigates the <code>implementationConfigClass</code> in this case but the <code>valueConfigClass</code> table for AUROSAR
     * 4.2.1 and newer versions.
     * </p>
     * </div>
     *
     * @param variant
     * @return
     */
    @PublishedMethod
    EEcucConfigurationClass getValueConfigurationClass(EEcucConfigurationVariant variant);

    /**
     * <div class="extdoc" id="supportsVariantMultiplicity"> The {@link #supportsVariantMultiplicity()} method returns <code>true</code> if this parameter type supports variant
     * multiplicity. If <code>true</code> is returned this means that different variants may contain different number of instances of this parameter type.
     * <p>
     * This method takes the multiplicity into account. So, if the parameter definition specifies the multiplicity with lower == upper, it always returns <code>false</code>.
     * Concerning post-build selectable it never makes sense to permit variance if lower and upper multiplicity are equal.
     * </p>
     * <p>
     * This method is for post-build selectable only!
     * </p>
     * <p>
     * <b>Remark about AUTOSAR versions:</b> Prior to AUTOSAR 4.2.1 the parameter definitions contain the <code>implementationConfigClass</code> table to define post-build
     * selectable support. This method internally investigates the <code>implementationConfigClass</code> in this case but the <code>postBuildVariantMultiplicity</code> flag for
     * AUROSAR 4.2.1 and newer versions.
     * </p>
     * </div>
     *
     * @return
     */
    @PublishedMethod
    boolean supportsVariantMultiplicity();

    /**
     * <div class="extdoc" id="supportsVariantValue"> The {@link #supportsVariantValue()} method returns <code>true</code> if this parameter type supports a variant value. If
     * <code>true</code> is returned this means that different variants may contain different values in instances of this parameter type.
     * <p>
     * This method is for post-build selectable only!
     * </p>
     * <p>
     * <b>Remark about AUTOSAR versions:</b> Prior to AUTOSAR 4.2.1 the parameter definitions contain the <code>implementationConfigClass</code> table to define post-build
     * selectable support. This method internally investigates the <code>implementationConfigClass</code> in this case but the <code>postBuildVariantValue</code> flag for
     * AUROSAR 4.2.1 and newer versions.
     * </p>
     * </div>
     *
     * @return
     */
    @PublishedMethod
    boolean supportsVariantValue();

    /**
     * Returns the requires index flag. This never returns <code>null</code>. It implements the AUTOSAR standard semantic for requiresIndex: If the request flag is not defined
     * in the model, this method returns false.
     *
     * @param obj
     * @return The requires index flag but never <code>null</code>
     */
    @PublishedMethod
    boolean requiresIndex();

    /**
     * Returns true if this parameter type is classified as PUBLISHED-INFORMATION and false otherwise.
     * <p>
     * This is evaluated according AUTOSAR prior 4.2.1 via the <code>implementationConfigClass</code>, and otherwise via the <code>valueConfigClass</code> and
     * <code>multiplicityConfigClass</code>.
     * </p>
     *
     * @return
     */
    @PublishedMethod
    boolean isPublishedInformation();
}
