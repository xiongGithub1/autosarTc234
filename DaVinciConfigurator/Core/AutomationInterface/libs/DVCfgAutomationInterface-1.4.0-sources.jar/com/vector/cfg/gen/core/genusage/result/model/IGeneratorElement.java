package com.vector.cfg.gen.core.genusage.result.model;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.gencore.generators.IGeneratorPackageRef;
import com.vector.cfg.gen.core.moduleinterface.IGenerator;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;

/**
 * This interface represents a generator.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGeneratorElement extends IGenerationItem {

    /**
     * Gets the generator.
     *
     * @return the generator
     */
    @PublishedMethod
    IGenerator getGenerator();

    /**
     * Gets the generator package.
     *
     * @return the generator package
     */
    @KeepSecretFromPublishedApi
    IGeneratorPackageRef getGeneratorPackage();

    /**
     * Gets the module config list.
     *
     * @return the module config list
     */
    @PublishedMethod
    ImmutableList<MIModuleConfiguration> getModuleConfigList();
}
