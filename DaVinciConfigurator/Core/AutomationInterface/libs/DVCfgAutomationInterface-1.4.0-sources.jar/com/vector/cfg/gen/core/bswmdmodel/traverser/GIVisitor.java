package com.vector.cfg.gen.core.bswmdmodel.traverser;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
// CHECKSTYLE:OFF Class Naming problem
public interface GIVisitor {
    // CHECKSTYLE:ON

    /**
     * Starts the traverse operation on the passed {@link GIModelObject}, by calling the {@link GIVisitor} visit methods for the element.
     *
     * @param modelElement the entry point for the traverse operation.
     */
    @PublishedMethod
    void accept(GIModelObject modelElement);
}
