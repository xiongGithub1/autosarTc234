package com.vector.cfg.consistency.groovy.api;

import java.util.function.Function;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.ui.ISolvingActionUI;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * This interface is used to select a solving action within a validation result.<br/>
 * See documentation of the complete fluent API in {@link ISolver#solve(Closure)}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface ISolvingActionSelect {

    /**
     * Pass a function-closure to this method that receives an {@link IValidationResultForSolvingActionSelect} and returns an {@link ISolvingActionUI} or null.<br/>
     * See documentation of the complete fluent API in {@link ISolver#solve(Closure)}.
     *
     * @param result2Action a function closure that maps from {@link IValidationResultForSolvingActionSelect} to an {@link ISolvingActionUI} or null
     */
    @PublishedMethod
    void withAction(@VDelegatesToWithClosureParam(IValidationResultForSolvingActionSelect.class) Closure<ISolvingActionUI> result2Action);

    /**
     * Pass a {@link Function} to this method that receives an {@link IValidationResultForSolvingActionSelect} and uses that to return an {@link ISolvingActionUI} or null.<br/>
     * See documentation of the complete fluent API in {@link ISolver#solve(Closure)}.
     *
     * @param result2Action a {@link Function} that maps from {@link IValidationResultForSolvingActionSelect} to an {@link ISolvingActionUI} or null
     */
    @PublishedMethod
    void withAction(Function<IValidationResultForSolvingActionSelect, ISolvingActionUI> result2Action);
}
