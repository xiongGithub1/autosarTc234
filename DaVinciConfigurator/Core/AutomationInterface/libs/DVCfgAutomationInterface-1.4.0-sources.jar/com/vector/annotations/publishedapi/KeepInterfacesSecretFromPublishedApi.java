package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link KeepInterfacesSecretFromPublishedApi} hides the the defined interfaces of the annotated type from the {@link PublishedApi}. The {@link #value()} Classes, will be
 * removed from the classes interface and signature bytecode.
 *
 * <p>
 * A change of an element marked with {@link KeepInterfacesSecretFromPublishedApi} will not lead to a breaking change or any other API change.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see PublishedApi
 */
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.TYPE })
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public @interface KeepInterfacesSecretFromPublishedApi {

    /**
     * The interfaces which shall be hidden from the {@link PublishedApi} of the annotated class or interface.
     *
     * @return the classes to hide
     */
    Class<?>[] value();
}
