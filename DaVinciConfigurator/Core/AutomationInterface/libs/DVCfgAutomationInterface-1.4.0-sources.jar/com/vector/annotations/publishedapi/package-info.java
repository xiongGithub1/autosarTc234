/**
 * Annotations to provide {@link com.vector.annotations.publishedapi.PublishedApi} classes for external usage.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.annotations.publishedapi;