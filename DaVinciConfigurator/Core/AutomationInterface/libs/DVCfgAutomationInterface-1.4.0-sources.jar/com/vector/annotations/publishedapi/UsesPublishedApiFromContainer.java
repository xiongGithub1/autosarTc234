package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link UsesPublishedApiFromContainer} defined the container for {@link UsesPublishedApiFrom} multiple times at one element.
 * <p>
 * It is not allowed to specify multiple {@link UsesPublishedApiFrom} with the same {@link DomainType} at the same element.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.TYPE, ElementType.CONSTRUCTOR, ElementType.METHOD, ElementType.ANNOTATION_TYPE })
public @interface UsesPublishedApiFromContainer {

    /**
     * The contained {@link UsesPublishedApiFrom} annotations.
     *
     * @return the annotations.
     */
    @PublishedMethod
    UsesPublishedApiFrom[]value();
}
