package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <div class="extdoc" id="PublishedMethod"> Indicates that the annotated method is part of an published type (see {@link PublishedApi} <!--LaTeX: or chapter
 * \vref{sec:PublishedApi}--> for more details), which must not be changed in the development without an approval for the breaking change! </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see PublishedApi
 */
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.METHOD, ElementType.CONSTRUCTOR })
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public @interface PublishedMethod {

}
