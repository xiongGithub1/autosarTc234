package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * The {@link PublishedApi} annotation indicates that the annotated type is part of an published API.
 *
 * <div class="extdoc" id="PublishedApi"> <!--LaTeX: or chapter \label{sec:PublishedApi}--> The {@link PublishedApi} annotation indicates that the annotated type is part of an
 * published API, which must not be changed in the development without an approval for changes! You have to mark all methods/fields in a type marked by this annotation with
 * {@link PublishedMethod}/ {@link PublishedField}. The annotation needs a {@link ChangePolicy} to determine which change is a breaking change.
 * <ul>
 * <li>{@link ChangePolicy#CHANGES_FORBIDDEN} - Indicates that any change of the class is a breaking change!</li>
 * <li>{@link ChangePolicy#ADDITIONS_ALLOWED} - Indicates that only changes to existing elements of the class are breaking changes! Additions to the class are allowed, but lead
 * to a minor API change.</li>
 * <li>{@link ChangePolicy#CLASS_DEPENDENCY} - Indicates that the class is only needed for compilation dependency. You this {@link ChangePolicy} with caution!</li>
 * </ul>
 *
 * <p>
 * To hide a method from the {@link PublishedApi}, you can annotate it with {@link KeepSecretFromPublishedApi}. This will prevent all client from the API to use this method.
 * This feature is ensured during compile time of the client code. A change/deletion of {@link KeepSecretFromPublishedApi} methods are no changes of the {@link PublishedApi}.
 * </p>
 * <p>
 * Every class could be additional annotated with {@link PublishedApiDomain} to limit the visibility of the class. For example a class with {@link PublishedApiDomain}
 * {@link DomainType#GENERATORS} is only visible in the generators, not in the other domains.
 * </p>
 *
 * <p>
 * Usage example:
 *
 * <pre>
 * <code class="Java" id="PublishedApi annotation example">
 * &#64;PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
 * &#64;PublishedApiDomain({ DomainType.AUTOMATION_IF, DomainType.GENERATORS})
 * public interface PublishedApi {
 *
 *   &#64;PublishedMethod
 *   void method();
 * }
 * </code>
 * </pre>
 *
 * </p>
 *
 * The {@link PublishedApi} annotation <b>shall not be used by clients</b> using the published API. This is only for the export and tracking of the published API. So a client
 * shall not annotate any class or interface with the {@link PublishedApi} annotation.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see ChangePolicy
 * @see PublishedApiDomain
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@Documented
@Retention(RetentionPolicy.CLASS)
@Target(ElementType.TYPE)
public @interface PublishedApi {

    /**
     * ChangePolicy for this class. This determines, if a change is a minor change or a breaking change.
     *
     * @return the change policy
     */
    @PublishedMethod
    ChangePolicy value();
}
