package com.vector.annotations.publishedapi;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <div class="extdoc" id="PublishedBeta"> The {@link PublishedBeta} annotations signifies that a public API (public class, interface, method or field) annotated with
 * {@link PublishedApi} is subject to incompatible changes, or even removal, in a future release. An API bearing this annotation is exempt from any compatibility guarantees made
 * by its containing library. Note that the presence of this annotation implies nothing about the quality or performance of the API in question, only the fact that it is not
 * "API-frozen".
 *
 * <p>
 * It is generally safe for <b>clients</b> to depend on beta APIs, at the cost of some extra work during upgrades. Note that the client which uses this API must upgrade to each
 * DaVinci Configurator release, to guarantee, that the used API is still available.
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @see PublishedApi
 *
 */
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.ANNOTATION_TYPE, ElementType.CONSTRUCTOR, ElementType.METHOD, ElementType.TYPE })
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public @interface PublishedBeta {
}
